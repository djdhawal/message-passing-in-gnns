"""Stream selected saved test predictions into CPU-only diagnostic plots.

This is optional: graph-growth analysis can complete without predictions.
The prediction CSV schema was not included in the uploaded results archive.
Consequently, ambiguous fields are reported rather than silently interpreted.
"""
from __future__ import annotations

import json
import re
from pathlib import Path


# Pairs deliberately keep observed and predicted quantities together.
VALUE_PAIRS = [
    ("y_true", "y_pred"), ("observed", "predicted"),
    ("target", "prediction"), ("actual", "prediction"),
    ("q_obs", "q_pred"), ("q_true", "q_pred"),
    ("obs", "pred"), ("observed_flow", "predicted_flow"),
    ("discharge_obs", "discharge_pred"),
]
ALIASES = {
    "graph": ["graph_id", "outlet_id", "gauge_id", "station_id"],
    "horizon": ["horizon", "horizon_days", "lead_days", "lead_time_days"],
    "split": ["split", "temporal_split", "data_split"],
    "run": ["run_id"],
    "seed": ["seed", "random_seed"],
    "radius": ["context_radius", "radius"],
    "target_date": ["target_date", "valid_date", "verification_date"],
    "issue_date": ["issue_date", "forecast_origin", "forecast_date", "origin_date"],
}


def _safe_name(value):
    return re.sub(r"[^A-Za-z0-9_.-]", "_", str(value))


def _id(value):
    # Preserve string identifiers, including leading zeroes.
    value = str(value).strip()
    return value[:-2] if re.fullmatch(r"[0-9]+\.0", value) else value


def _write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def make_prediction_diagnostics(work, outdir, graph_ids, run_ids, start=None, end=None):
    """Plot saved full-context, seed-42 test predictions for selected outlets.

    At most four explicitly named runs are scanned. CSV files are read in
    100,000-row chunks, and only selected outlet/horizon rows are retained.
    With no explicit dates, each run/outlet/horizon retains its final 365 days.
    Date bounds are inclusive. Metrics describe the plotted period only.
    Missing files or unfamiliar schemas return a diagnostic status, not an
    exception that stops the main analysis. No model or GPU is used.
    """
    work, outdir = Path(work), Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    report = {
        "status": "pending", "requested_graph_ids": list(map(str, graph_ids)),
        "requested_run_ids": list(map(str, run_ids)), "files": [],
        "warnings": [], "plots": [], "metrics_scope": "plotted period only",
        "prediction_units": "native saved CSV units; no unit conversion assumed",
        "seed": 42, "split": "test", "context_radius": "full",
        "default_period": "last 365 days separately for each run/outlet/horizon",
        "start": start, "end": end,
    }

    def finish(status):
        report["status"] = status
        _write_json(outdir / "prediction_diagnostics.json", report)
        return report

    try:
        import numpy as np
        import pandas as pd
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as exc:
        report["warnings"].append(f"Optional plotting dependency missing: {exc}")
        return finish("missing_dependencies")

    selected_runs = list(dict.fromkeys(map(str, run_ids)))
    if not selected_runs or len(selected_runs) > 4:
        report["warnings"].append("Supply between one and four exact run IDs.")
        return finish("invalid_request")
    if any(not re.search(r"__s42__rfull$", run) for run in selected_runs):
        report["warnings"].append("Every requested run ID must end with __s42__rfull.")
        return finish("invalid_request")
    selected_graphs = {_id(x) for x in graph_ids}
    if not selected_graphs:
        report["warnings"].append("No outlet IDs requested.")
        return finish("invalid_request")
    try:
        lower = pd.Timestamp(start, tz="UTC") if start else None
        upper = pd.Timestamp(end, tz="UTC") if end else None
        if lower is not None and upper is not None and lower > upper:
            raise ValueError("start is later than end")
    except (ValueError, TypeError) as exc:
        report["warnings"].append(f"Invalid date bounds: {exc}")
        return finish("invalid_request")
    # Daily targets: inclusive end date also includes any timestamp on that day.
    upper_exclusive = upper + pd.Timedelta(days=1) if upper is not None else None

    runs_dir = work / "runs"
    candidates = sorted(
        p for p in runs_dir.rglob("*")
        if p.is_file() and "predict" in p.name.lower()
        and (p.name.lower().endswith(".csv") or p.name.lower().endswith(".csv.gz"))
    ) if runs_dir.is_dir() else []
    if not candidates:
        report["warnings"].append(
            "No *predict*.csv or *predict*.csv.gz files found below work/runs. "
            "Keep the full original experiment directory; the review ZIP omits predictions."
        )
        return finish("no_prediction_files")

    retained = {}  # (run_id, graph_id, horizon) -> small selected DataFrame
    bad_keys = set()
    for path in candidates:
        # Skip known run directories outside the explicitly requested models.
        path_runs = [part for part in path.parts if re.search(r"__s\d+__r[^/]+$", part)]
        inferred = next((run for run in selected_runs if run in path.parts
                         or path.name.startswith(run + "__")
                         or path.name.startswith(run + "_pred")), None)
        if path_runs and not inferred:
            continue
        record = {"source": str(path.relative_to(work)), "status": "pending"}
        report["files"].append(record)
        touched_keys = set()
        try:
            columns = list(pd.read_csv(path, nrows=0).columns)
            lookup = {str(c).strip().lower(): c for c in columns}
            fields = {key: next((lookup[a] for a in aliases if a in lookup), None)
                      for key, aliases in ALIASES.items()}
            pair = next(((lookup[a], lookup[b]) for a, b in VALUE_PAIRS
                         if a in lookup and b in lookup), None)
            explicit_test_file = bool(re.search(r"(?:^|[_\-.])test(?:[_\-.]|$)", path.name.lower()))
            missing = [key for key in ("graph", "horizon") if not fields[key]]
            if pair is None:
                missing.append("observed/predicted value pair")
            if not fields["run"] and inferred is None:
                missing.append("run_id or exact run-ID parent folder")
            if not fields["split"] and not explicit_test_file:
                missing.append("test split column or explicit test filename")
            if not fields["target_date"] and not fields["issue_date"]:
                missing.append("explicit target_date or issue_date (plain date is ambiguous)")
            if missing:
                record.update(status="unsupported_schema", missing=missing, available_columns=columns)
                continue
            obs_col, pred_col = pair
            date_col = fields["target_date"] or fields["issue_date"]
            date_basis = "target date" if fields["target_date"] else "issue date + horizon days"
            record.update(fields={**fields, "observed": obs_col, "predicted": pred_col},
                          date_basis=date_basis, scanned_rows=0, matching_rows=0,
                          invalid_value_or_date_rows=0)
            usecols = list(dict.fromkeys([c for c in fields.values() if c] + list(pair)))
            for frame in pd.read_csv(path, usecols=usecols, dtype=str, chunksize=100_000):
                record["scanned_rows"] += len(frame)
                run = frame[fields["run"]].str.strip() if fields["run"] else pd.Series(inferred, index=frame.index)
                graph = frame[fields["graph"]].map(_id)
                horizon = pd.to_numeric(frame[fields["horizon"]], errors="coerce")
                mask = run.isin(selected_runs) & graph.isin(selected_graphs) & horizon.isin([1, 3, 7])
                if inferred is not None:
                    mask &= run.eq(inferred)
                if fields["split"]:
                    mask &= frame[fields["split"]].str.strip().str.lower().eq("test")
                if fields["seed"]:
                    mask &= pd.to_numeric(frame[fields["seed"]], errors="coerce").eq(42)
                if fields["radius"]:
                    radii = frame[fields["radius"]].str.strip().str.lower()
                    mask &= radii.isin(["full", "rfull", "-1", "-1.0"])
                frame = frame.loc[mask]
                if frame.empty:
                    continue
                sub = pd.DataFrame({"run_id": run.loc[mask], "graph_id": graph.loc[mask],
                                    "horizon": horizon.loc[mask].astype(int)})
                sub["date"] = pd.to_datetime(frame[date_col], errors="coerce", utc=True)
                if not fields["target_date"]:
                    sub["date"] += pd.to_timedelta(sub["horizon"], unit="D")
                sub["observed"] = pd.to_numeric(frame[obs_col], errors="coerce")
                sub["predicted"] = pd.to_numeric(frame[pred_col], errors="coerce")
                valid = sub["date"].notna() & np.isfinite(sub["observed"]) & np.isfinite(sub["predicted"])
                record["invalid_value_or_date_rows"] += int((~valid).sum())
                sub = sub.loc[valid]
                if lower is not None:
                    sub = sub.loc[sub["date"] >= lower]
                if upper_exclusive is not None:
                    sub = sub.loc[sub["date"] < upper_exclusive]
                record["matching_rows"] += len(sub)
                for key, group in sub.groupby(["run_id", "graph_id", "horizon"], sort=False):
                    touched_keys.add(key)
                    if key in bad_keys:
                        continue
                    combined = pd.concat([retained[key], group], ignore_index=True) if key in retained else group.copy()
                    if lower is None:
                        # If only --end was supplied, show the 365 days ending at --end.
                        latest = upper if upper is not None else combined["date"].max()
                        combined = combined.loc[combined["date"] >= latest - pd.Timedelta(days=364)]
                    # Duplicate forecasts indicate multiple contexts/splits or duplicate files.
                    # Even identical duplicates are rejected to avoid counting them twice.
                    if combined["date"].duplicated().any():
                        bad_keys.add(key)
                        retained.pop(key, None)
                        report["warnings"].append(
                            f"Skipped {key}: duplicate target dates; inspect overlapping files or mixed contexts."
                        )
                        continue
                    retained[key] = combined
            record["status"] = "read"
        except Exception as exc:
            record.update(status="read_error", error=f"{type(exc).__name__}: {exc}")
            # Do not report a partial series after a failure mid-file.
            for key in touched_keys:
                retained.pop(key, None)
                bad_keys.add(key)

    summary = []
    plotted_rows = []
    for (run, graph, horizon), frame in sorted(retained.items()):
        frame = frame.sort_values("date")
        if frame.empty:
            continue
        observed, predicted = frame["observed"].to_numpy(), frame["predicted"].to_numpy()
        residual = predicted - observed
        denominator = float(np.square(observed - observed.mean()).sum())
        nse = 1.0 - float(np.square(residual).sum()) / denominator if denominator > 0 else None
        metrics = {"run_id": run, "graph_id": graph, "horizon": int(horizon),
                   "seed": 42, "split": "test", "context_radius": "full",
                   "start": frame["date"].min().date().isoformat(),
                   "end": frame["date"].max().date().isoformat(), "n": int(len(frame)),
                   "mae": float(np.abs(residual).mean()),
                   "bias_pred_minus_obs": float(residual.mean()),
                   "rmse": float(np.sqrt(np.square(residual).mean())), "nse": nse}
        summary.append(metrics)
        plotted_rows.append(frame)
        name = f"outlet_{_safe_name(graph)}__{_safe_name(run)}__h{int(horizon)}.png"
        fig, ax = plt.subplots(figsize=(11, 3.7), constrained_layout=True)
        ax.plot(frame["date"], observed, label="Observed", color="#25364c", linewidth=1.1)
        ax.plot(frame["date"], predicted, label="Predicted", color="#d45f24", linewidth=1.0, alpha=.85)
        ax.set_title(f"Outlet {graph} · {horizon}-day forecast · {run}\n"
                     f"Test period {metrics['start']} to {metrics['end']} · seed 42")
        ax.set_xlabel("Target date")
        ax.set_ylabel("Native prediction CSV units")
        ax.legend(loc="upper right")
        ax.grid(alpha=.2)
        fig.savefig(outdir / name, dpi=150)
        plt.close(fig)
        report["plots"].append(name)
    if summary:
        pd.DataFrame(summary).to_csv(outdir / "prediction_diagnostics_metrics.csv", index=False)
        pd.concat(plotted_rows, ignore_index=True).to_csv(outdir / "plotted_predictions.csv", index=False)
    report["plotted_series"] = len(summary)
    report["retained_rows"] = sum(row["n"] for row in summary)
    present = {(row["run_id"], row["graph_id"], row["horizon"]) for row in summary}
    missing = [(run, graph, horizon) for run in selected_runs
               for graph in sorted(selected_graphs) for horizon in [1, 3, 7]
               if (run, graph, horizon) not in present]
    report["missing_requested_series"] = [
        {"run_id": run, "graph_id": graph, "horizon": horizon}
        for run, graph, horizon in missing
    ]
    if summary and missing:
        report["warnings"].append(f"{len(missing)} requested outlet/run/horizon series had no usable rows.")
    if summary:
        status = "completed_with_warnings" if report["warnings"] or any(
            file["status"] != "read" for file in report["files"]
        ) else "completed"
    else:
        status = "no_usable_predictions"
        report["warnings"].append(
            "No plots were made. Check requested IDs, source headers, split labels, and date fields in this report."
        )
    return finish(status)
