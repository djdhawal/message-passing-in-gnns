"""Read small graph artifacts safely; never unpickle saved model/data files.

Explicit JSON schema (IDs, not node positions)::

    [{"graph_id": "499", "outlet_id": "499", "node_ids": ["1", "2", "499"],
      "edges": [["1", "499"], ["2", "499"]]}]

JSON/JSONL files may also contain a ``graphs`` list or dictionary. ``edge_index``
means a 2-by-E array of zero-based node positions. Auto-discovered ``edges`` are
E-by-2 rows: when IDs and node positions give different interpretations, require
``edge_format: "ids"`` or ``edge_format: "indices"``. Known outlet/root metadata
is required. Direction may be reversed only after validating the complete tree.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import zipfile


MAX_FILE_BYTES = 24 * 1024 * 1024
MAX_ARRAY_BYTES = 64 * 1024 * 1024
MAX_FILES = 1500
NPZ_GRAPH_FIELDS = {"graph_id", "outlet_id", "root_id", "outlet_node_id",
                    "outlet_index", "root_index", "node_ids", "nodes", "edges",
                    "edge_index", "edge_format", "sources", "targets", "source",
                    "target", "distances_to_outlet", "upstream_hops",
                    "outlet_area_km2", "ancestor_dist", "upstream_area"}
SKIP_DIRS = {"runs", "analysis", "predictions", "raw", "raw_data", "downloads",
             ".venv", "venv", ".git", "node_modules", "__pycache__",
             "volume_growth", "growth_analysis", "river_growth_tools"}


class GraphFormatError(ValueError):
    pass


def _id(value):
    if hasattr(value, "item"):
        value = value.item()
    if isinstance(value, bool) or value is None:
        raise GraphFormatError("A node/graph ID is missing or boolean")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise GraphFormatError("Numeric IDs must be finite integers")
        value = int(value)
    if not isinstance(value, (str, int)) or not str(value).strip():
        raise GraphFormatError("IDs must be nonempty strings or integers")
    return str(value).strip()


def _list(value):
    if hasattr(value, "tolist"):
        value = value.tolist()
    return value


def _position(value, size):
    if hasattr(value, "item"):
        value = value.item()
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise GraphFormatError("Node positions must be integers")
    if not math.isfinite(value) or int(value) != value or not 0 <= int(value) < size:
        raise GraphFormatError("Node position lies outside node_ids")
    return int(value)


def _nodes(record):
    raw = _list(record.get("node_ids", record.get("nodes")))
    if not isinstance(raw, list) or not raw:
        raise GraphFormatError("Missing nonempty node_ids (or nodes) list")
    ids = []
    for item in raw:
        if isinstance(item, dict):
            keys = [key for key in ("id", "node_id", "gauge_id") if key in item]
            if not keys:
                raise GraphFormatError("Node dictionaries need id/node_id/gauge_id")
            values = {_id(item[key]) for key in keys}
            if len(values) != 1:
                raise GraphFormatError("Conflicting IDs in node dictionary")
            ids.append(values.pop())
        else:
            ids.append(_id(item))
    if len(set(ids)) != len(ids):
        raise GraphFormatError("Duplicate node IDs")
    return ids


def _root(record, ids):
    roots = []
    for key in ("outlet_index", "root_index"):
        if key in record:
            roots.append(_position(record[key], len(ids)))
    for key in ("outlet_id", "root_id", "outlet_node_id"):
        if key in record:
            value = _id(record[key])
            if value not in ids:
                raise GraphFormatError(f"{key} is not present in node_ids")
            roots.append(ids.index(value))
    if not roots:
        raise GraphFormatError("Missing outlet_id/root_id or outlet_index/root_index; root not guessed")
    if len(set(roots)) != 1:
        raise GraphFormatError("Conflicting root/outlet metadata")
    return roots[0]


def _edge_rows(record):
    if "edge_index" in record:
        a = _list(record["edge_index"])
        if not isinstance(a, list) or len(a) != 2:
            raise GraphFormatError("edge_index must have shape 2-by-E")
        if not all(isinstance(row, list) for row in a) or len(a[0]) != len(a[1]):
            raise GraphFormatError("edge_index must have shape 2-by-E")
        return list(zip(a[0], a[1])), "indices", "edge_index"
    if "edges" in record:
        a = _list(record["edges"])
        if not isinstance(a, list):
            raise GraphFormatError("edges must be an E-by-2 list")
        rows = []
        for edge in a:
            if isinstance(edge, dict):
                if "source" not in edge or "target" not in edge:
                    raise GraphFormatError("Edge dictionaries require source and target")
                rows.append((edge["source"], edge["target"]))
            elif isinstance(edge, (list, tuple)) and len(edge) == 2:
                rows.append(tuple(edge))
            else:
                raise GraphFormatError("edges must contain pairs or source/target dictionaries")
        return rows, record.get("edge_format"), "edges"
    if "sources" in record and "targets" in record:
        a, b = _list(record["sources"]), _list(record["targets"])
        if not isinstance(a, list) or not isinstance(b, list) or len(a) != len(b):
            raise GraphFormatError("sources and targets must be equal-length arrays")
        return list(zip(a, b)), record.get("edge_format"), "sources/targets"
    if "source" in record and "target" in record:
        a, b = _list(record["source"]), _list(record["target"])
        if not isinstance(a, list) or not isinstance(b, list) or len(a) != len(b):
            raise GraphFormatError("source and target must be equal-length arrays")
        return list(zip(a, b)), record.get("edge_format"), "source/target"
    return None, None, None


def _decode_edges(rows, mode, ids, explicit, field):
    if mode not in (None, "ids", "indices"):
        raise GraphFormatError("edge_format must be ids or indices")
    if explicit and field != "edge_index":
        if mode == "indices":
            raise GraphFormatError("Explicit canonical JSON edges must contain node IDs")
        mode = "ids"
    lookup = {node: i for i, node in enumerate(ids)}
    candidates = {}
    if mode in (None, "ids"):
        try:
            candidates["ids"] = [(lookup[_id(a)], lookup[_id(b)]) for a, b in rows]
        except (KeyError, GraphFormatError):
            pass
    if mode in (None, "indices"):
        try:
            candidates["indices"] = [(_position(a, len(ids)), _position(b, len(ids))) for a, b in rows]
        except GraphFormatError:
            pass
    if not candidates:
        raise GraphFormatError("Edge endpoints cannot be resolved to node_ids")
    values = list(candidates.values())
    if len(values) > 1 and values[0] != values[1]:
        raise GraphFormatError("Ambiguous edge IDs versus positions; set edge_format explicitly")
    return values[0]


def _toward_root(edges, size, root):
    """Return distances if this is an upstream-to-downstream rooted tree."""
    if len(edges) != size - 1 or len(set(edges)) != len(edges):
        return None
    parent = {}
    for a, b in edges:
        if a == b or a in parent:
            return None
        parent[a] = b
    if root in parent or set(parent) != set(range(size)) - {root}:
        return None
    distances = [None] * size
    distances[root] = 0
    for start in range(size):
        trail, seen, node = [], set(), start
        while distances[node] is None:
            if node in seen or node not in parent:
                return None
            seen.add(node)
            trail.append(node)
            node = parent[node]
        distance = distances[node]
        for node in reversed(trail):
            distance += 1
            distances[node] = distance
    return distances


def normalize_graph(record, source="<memory>", explicit=False, fallback_id=None):
    """Validate one record and return positions oriented upstream to outlet."""
    if not isinstance(record, dict):
        raise GraphFormatError("A graph record must be a dictionary")
    graph_id = _id(record.get("graph_id", record.get("outlet_id", fallback_id)))
    ids = _nodes(record)
    root = _root(record, ids)
    result = {"graph_id": graph_id, "node_ids": ids, "root_index": root,
              "outlet_id": ids[root], "source": str(source)}
    if "outlet_area_km2" in record:
        area = float(record["outlet_area_km2"])
        if not math.isfinite(area) or area <= 0:
            raise GraphFormatError("outlet_area_km2 must be finite and positive")
        result["outlet_area_km2"] = area
    rows, mode, field = _edge_rows(record)
    if rows is None:
        present = [key for key in ("distances_to_outlet", "upstream_hops") if key in record]
        if not present:
            raise GraphFormatError("No edges or explicitly named distances_to_outlet/upstream_hops")
        distances = _list(record[present[0]])
        if not isinstance(distances, list) or len(distances) != len(ids):
            raise GraphFormatError("Distance vector must align with node_ids")
        for d in distances:
            if isinstance(d, bool) or not isinstance(d, (int, float)) or not math.isfinite(d) or d < 0 or int(d) != d:
                raise GraphFormatError("Upstream hop distances must be nonnegative integers")
        distances = [int(d) for d in distances]
        if distances.count(0) != 1 or distances[root] != 0:
            raise GraphFormatError("Distance vector must have a unique zero at the known outlet")
        if set(distances) != set(range(max(distances) + 1)):
            raise GraphFormatError("Distance levels have gaps inconsistent with a connected tree")
        for key in present[1:]:
            if _list(record[key]) != distances:
                raise GraphFormatError("Conflicting distance vectors")
        result.update(edges=None, orientation="distance_only_topology_unverified",
                      distances_to_outlet=distances, topology_verified=False)
        return result
    edges = _decode_edges(rows, mode, ids, explicit, field)
    dropped = sum(a == b for a, b in edges)
    # Self loops are common in message-passing storage; remove and report them.
    edges = [(a, b) for a, b in edges if a != b]
    distances = _toward_root(edges, len(ids), root)
    reversed_edges = [(b, a) for a, b in edges]
    reversed_distances = _toward_root(reversed_edges, len(ids), root)
    if distances is None and reversed_distances is None:
        raise GraphFormatError("Edges do not form a directed tree reaching the known outlet (cycles, duplicates, bidirectional edges, or disconnected nodes)")
    orientation = "upstream_to_outlet"
    if distances is None:
        edges, distances = reversed_edges, reversed_distances
        orientation = "reversed_to_upstream_to_outlet"
    for key in ("distances_to_outlet", "upstream_hops"):
        if key in record and _list(record[key]) != distances:
            raise GraphFormatError(f"{key} disagrees with distances computed from edges")
    result.update(edges=edges, distances_to_outlet=distances, orientation=orientation,
                  topology_verified=True, self_loops_removed=dropped)
    return result


def _records(value, expected, fallback_id=None, depth=0):
    if depth > 10:
        return
    if isinstance(value, list):
        for item in value:
            if isinstance(item, (list, dict)):
                yield from _records(item, expected, fallback_id, depth + 1)
    elif isinstance(value, dict):
        if "node_ids" in value or "nodes" in value:
            yield value, fallback_id
            return
        for key, item in value.items():
            if isinstance(item, (list, dict)):
                hint = str(key) if str(key) in expected else fallback_id
                yield from _records(item, expected, hint, depth + 1)


def _read(path):
    if path.suffix.lower() == ".npz":
        # Native files also store decades of weather/flow arrays. Only inspect
        # the small topology arrays, never unpack the complete training data.
        with zipfile.ZipFile(path) as archive:
            selected = [info for info in archive.infolist()
                        if info.filename.endswith(".npy") and info.filename[:-4] in NPZ_GRAPH_FIELDS]
            if sum(info.file_size for info in selected) > MAX_ARRAY_BYTES:
                raise GraphFormatError("NPZ topology arrays exceed safe array-reader limit")
        try:
            import numpy as np
        except ImportError as exc:
            raise GraphFormatError("Reading NPZ requires numpy in the existing experiment environment") from exc
        with np.load(path, allow_pickle=False) as arrays:
            return [{key: arrays[key].tolist() for key in arrays.files if key in NPZ_GRAPH_FIELDS}]
    if path.stat().st_size > MAX_FILE_BYTES:
        raise GraphFormatError(f"File exceeds {MAX_FILE_BYTES // 1024**2} MiB graph-reader limit")
    if path.suffix.lower() == ".jsonl":
        with path.open(encoding="utf-8-sig") as handle:
            return [json.loads(line) for line in handle if line.strip()]
    with path.open(encoding="utf-8-sig") as handle:
        return json.load(handle)


def _native_record(path, record, manifest_cache):
    """Resolve the exact river_hybrid/data.py format from processed/graphs.

    data.py writes no graph_id into NPZ. The ID is node_ids[outlet_index];
    manifest IDs and the filename must independently agree. upstream_area is
    the sum of intermediate areas upstream of each node (km²), so its outlet
    entry is comparable to manifest drainage_area_km2.
    """
    if not (path.suffix.lower() == ".npz" and path.parent.name == "graphs"
            and path.parent.parent.name == "processed"):
        return record, None
    ids = _nodes(record)
    if "outlet_index" not in record or "edge_index" not in record:
        raise GraphFormatError("Native graph needs outlet_index and edge_index")
    root = _position(record["outlet_index"], len(ids))
    outlet = ids[root]
    if _id(path.stem) != outlet:
        raise GraphFormatError("Native NPZ filename disagrees with node_ids[outlet_index]")
    enriched = dict(record)
    for key in ("graph_id", "outlet_id"):
        if key in record and _id(record[key]) != outlet:
            raise GraphFormatError(f"Native {key} disagrees with node_ids[outlet_index]")
        enriched[key] = outlet
    manifest_path = path.parent.parent / "manifest.json"
    metadata = None
    if manifest_path.is_file():
        cache_key = str(manifest_path)
        if cache_key not in manifest_cache:
            manifest_cache[cache_key] = _read(manifest_path)
        manifest = manifest_cache[cache_key]
        if not isinstance(manifest, dict) or not isinstance(manifest.get("graphs"), list):
            raise GraphFormatError("Native manifest must contain a graphs list")
        matches = [item for item in manifest["graphs"] if isinstance(item, dict)
                   and isinstance(item.get("file"), str)
                   and (manifest_path.parent / item["file"]).resolve() == path.resolve()]
        if len(matches) != 1:
            raise GraphFormatError("Native NPZ must have exactly one matching manifest file entry")
        metadata = matches[0]
        for key in ("graph_id", "outlet_id"):
            if _id(metadata.get(key)) != outlet:
                raise GraphFormatError(f"Manifest {key} disagrees with NPZ outlet and filename")
        if _position(metadata.get("outlet_index"), len(ids)) != root:
            raise GraphFormatError("Manifest outlet_index disagrees with NPZ outlet_index")
        if metadata.get("n_nodes") != len(ids):
            raise GraphFormatError("Manifest n_nodes disagrees with NPZ node_ids")
        area = float(metadata.get("drainage_area_km2", float("nan")))
        if not math.isfinite(area) or area <= 0:
            raise GraphFormatError("Manifest drainage_area_km2 must be finite and positive")
        enriched["outlet_area_km2"] = area
    if "upstream_area" in record:
        areas = record["upstream_area"]
        if not isinstance(areas, list) or len(areas) != len(ids):
            raise GraphFormatError("Native upstream_area must align with node_ids")
        area = float(areas[root])
        if not math.isfinite(area) or area <= 0:
            raise GraphFormatError("Native outlet upstream_area must be finite and positive")
        if metadata is not None and not math.isclose(area, enriched["outlet_area_km2"], rel_tol=1e-5, abs_tol=1e-3):
            raise GraphFormatError("Manifest drainage_area_km2 disagrees with outlet upstream_area")
        enriched.setdefault("outlet_area_km2", area)
    return enriched, {"manifest": str(manifest_path) if metadata is not None else None,
                      "metadata": metadata,
                      "id_source": "node_ids[outlet_index], checked against filename and available manifest"}


def _validate_native(graph, record, native):
    if native is None:
        return
    if "ancestor_dist" not in record:
        raise GraphFormatError("Native graph is missing ancestor_dist")
    matrix = record["ancestor_dist"]
    size, root = len(graph["node_ids"]), graph["root_index"]
    if not isinstance(matrix, list) or len(matrix) != size or any(not isinstance(row, list) or len(row) != size for row in matrix):
        raise GraphFormatError("Native ancestor_dist must be an n_nodes-by-n_nodes matrix")
    if matrix[root] != graph["distances_to_outlet"]:
        raise GraphFormatError("Native ancestor_dist[outlet_index] disagrees with tree hop distances")
    metadata = native["metadata"]
    if metadata is not None and metadata.get("depth") != max(graph["distances_to_outlet"]):
        raise GraphFormatError("Manifest depth disagrees with tree hop distances")
    graph["format"] = "river_hybrid_native_v1"
    graph["id_source"] = native["id_source"]
    graph["ancestor_dist_verified"] = True
    graph["manifest_source"] = native["manifest"]
    if "outlet_area_km2" in graph:
        graph["outlet_area_source"] = ("manifest drainage_area_km2, checked against NPZ upstream_area[outlet_index]"
                                       if metadata is not None and "upstream_area" in record else
                                       "manifest drainage_area_km2" if metadata is not None else
                                       "NPZ upstream_area[outlet_index]; native data.py defines upstream catchment sum in km²")
    if metadata is not None:
        graph["metadata"] = dict(metadata)
        for key in ("basin_id", "spatial_split", "terminal_basin_id", "river_length_km"):
            if key in metadata:
                graph[key] = metadata[key]


def _sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def discover_graphs(work, expected_ids, explicit=None):
    """Return ``(graphs, diagnostics)``; missing/conflicting graphs are omitted.

    ``diagnostics`` is a list of JSON-serializable dictionaries, including a
    final summary. Callers must check coverage before drawing conclusions.
    Explicit exports are read exclusively, never mixed with auto-discovery.
    """
    expected = {_id(value) for value in expected_ids}
    diagnostics, paths, candidates = [], [], {}
    manifest_cache = {}
    if explicit:
        paths = [Path(explicit).expanduser().resolve()]
    else:
        base = Path(work).expanduser().resolve()
        if not base.is_dir():
            return [], [{"status": "error", "message": f"Work directory does not exist: {base}"}]
        limit_reached = False
        for directory, dirs, names in os.walk(base, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("growth_analysis_") and not Path(directory, d).is_symlink())
            for name in sorted(names):
                path = Path(directory, name)
                if path.suffix.lower() in {".json", ".jsonl", ".npz"} and not path.is_symlink():
                    paths.append(path)
                    if len(paths) >= MAX_FILES:
                        limit_reached = True
                        break
            if limit_reached:
                diagnostics.append({"status": "warning", "message": f"Stopped discovery at {MAX_FILES} candidates; use --graphs for an explicit export"})
                break
    for path in paths:
        if path.suffix.lower() not in {".json", ".jsonl", ".npz"}:
            diagnostics.append({"source": str(path), "status": "error", "message": "Only JSON, JSONL, NPZ supported; pickle/PT files are never loaded"})
            continue
        try:
            value = _read(path)
            records = list(_records(value, expected))
            if not records:
                continue
            digest = _sha256(path)
            for record, fallback in records:
                try:
                    record, native = _native_record(path, record, manifest_cache)
                except (GraphFormatError, TypeError, ValueError, OSError) as exc:
                    diagnostics.append({"source": str(path), "status": "rejected_record", "message": str(exc)})
                    continue
                try:
                    gid = _id(record.get("graph_id", record.get("outlet_id", fallback)))
                except GraphFormatError:
                    gid = None
                if gid is not None and gid not in expected:
                    continue
                try:
                    graph = normalize_graph(record, path, bool(explicit), fallback)
                    _validate_native(graph, record, native)
                    graph["source_sha256"] = digest
                    candidates.setdefault(graph["graph_id"], []).append(graph)
                    diagnostics.append({"source": str(path), "graph_id": graph["graph_id"], "status": "accepted_candidate", "orientation": graph["orientation"], "sha256": digest})
                except (GraphFormatError, TypeError, ValueError) as exc:
                    diagnostics.append({"source": str(path), "graph_id": gid, "status": "rejected_record", "message": str(exc)})
        except (OSError, ValueError, TypeError, zipfile.BadZipFile) as exc:
            diagnostics.append({"source": str(path), "status": "unreadable", "message": str(exc)})
    graphs = []
    for gid, options in sorted(candidates.items()):
        signatures = set()
        for graph in options:
            ids = graph["node_ids"]
            if graph["edges"] is None:
                shape = ("distance_only", tuple(sorted(zip(ids, graph["distances_to_outlet"]))))
            else:
                shape = ("tree", tuple(sorted((ids[a], ids[b]) for a, b in graph["edges"])))
            signatures.add((graph["outlet_id"], tuple(sorted(ids)), shape))
        if len(signatures) != 1:
            diagnostics.append({"graph_id": gid, "status": "conflict", "message": "Multiple nonidentical graph artifacts found; choose an explicit --graphs export"})
        else:
            graphs.append(options[0])
    missing = sorted(expected - {graph["graph_id"] for graph in graphs})
    diagnostics.append({"status": "summary", "candidate_files": len(paths), "expected_graphs": len(expected), "matched_graphs": len(graphs), "missing_graph_ids": missing, "explicit_source": str(explicit) if explicit else None})
    return graphs, diagnostics
