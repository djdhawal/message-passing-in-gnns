# River graph-growth analysis, version 2

CPU-only postprocessing for the completed `river_hybrid` experiment. It reads saved scores and graph artifacts, and optionally streams saved predictions. It does not train, use CUDA, change checkpoints, or overwrite the existing experiment analysis.

## Run on Ubuntu

Download `river_growth_analysis_v2.zip` to `~/Downloads`. In a terminal:

```bash
cd ~/Downloads/river_hybrid_lab
source .venv/bin/activate
python -m zipfile -e ~/Downloads/river_growth_analysis_v2.zip .
python river_growth_tools/analyze.py --work river_experiment
```

Dependencies are NumPy, pandas and Matplotlib, which should already be present in the experiment environment. If an import is missing, install only this script's requirements in the activated environment:

```bash
python -m pip install -r river_growth_tools/requirements.txt
```

The script prints the absolute path of a new `river_growth_review_<timestamp>.zip`. Upload that ZIP for interpretation. It also leaves a timestamped output folder inside `river_experiment`. Existing result files stay unchanged. The analysis normally takes minutes, depending on graph discovery and prediction-file reading; it is not another training sweep.

## What it computes

- Upstream volume `V(r)`: unique nodes at directed distance at most `r` from the outlet, including the outlet itself. Radii default to 0–8.
- Shell counts at exactly `r`, fraction `V(r)/N`, saturation flags, fixed-radius log growth `log(V(r)/V(r-1))`, node count, depth and branching measurements where edges are available.
- Same-outlet, same-task, same-seed NRMSE gains for **every fixed interior alpha 0.25, 0.50 and 0.75** against message passing, attention, pooling and the outlet GRU. Positive gain favors the hybrid. No alpha is selected using test outcomes.
- A conservative diagnostic against the better observed endpoint **within each seed**, averaged afterward. This is not a deployable model-selection policy.
- Separate exploratory Spearman correlations by spatial split, temporal split, input regime, horizon, alpha and comparator. Seeds are averaged within outlet before correlation.
- Optional descriptive adjusted rank correlations controlling node count and depth, plus explicitly supplied outlet area when available. Adjusted estimates are skipped for tiny or degenerate samples, including the five held-out outlets. Leave-one-basin-out ranges are sensitivity checks, not confidence intervals.
- Forecast diagnostics for outlets 499 and 609 using weather alpha 0.75 and weather+flow alpha 0, seed 42, full context, horizons 1/3/7. These declared examples are for diagnosis, not test-based selection.

The main files are `graph_growth_features.csv`, `paired_outlet_gains.csv`, `growth_and_gains.csv`, `exploratory_correlations.csv`, `model_summary.csv`, and `analysis_status.json`. Version 2 also includes a compact, portable `graphs_used.json` export and `graph_metadata.csv` in the review ZIP so the actual graph profiles can be checked alongside the scores. Read `READ_ME_FIRST.txt` with the results. Plots are saved as PNG files.

## Graph format checking

**Version 2 supports your verified native format:** `processed/graphs/<outlet>.npz` together with `processed/manifest.json`. Your returned diagnostic bundle supplied the original package source, which showed that the NPZ files omit `graph_id`. The reader now obtains the ID from `node_ids[outlet_index]` and checks it against the filename and manifest. It validates node count, depth, directed edges and the outlet row of `ancestor_dist`, and checks outlet area against the manifest. Only topology arrays are loaded, not the large weather/flow arrays. Generic JSON/JSONL/numeric NPZ exports remain supported. The script rejects ambiguous node indexing, unknown outlets, cycles, disconnected graphs, and conflicting artifacts instead of inventing a growth profile.

Discovery scans the experiment directory while skipping runs, raw data and analysis outputs. It understands `graphs` lists/dictionaries and records with:

- `graph_id`, `node_ids` (or `nodes`), and an explicit `outlet_id`/`root_id` or `outlet_index`/`root_index`;
- `edge_index` as a **2 by E** array of zero-based node positions; or
- `edges` as **E by 2** pairs of node IDs/positions. For automatic discovery, specify `edge_format: "ids"` or `edge_format: "indices"` if both interpretations are possible.

It validates that the edges form a tree reaching the known outlet. A reversed orientation is accepted only when reversing every edge produces that validated tree, and this is recorded. Self-loops are removed and reported. Bidirectional storage is not silently collapsed. Distance-only records with aligned `distances_to_outlet` or `upstream_hops` vectors can produce volume profiles, but are explicitly labelled as topology unverified; they cannot supply branching measurements.

If automatic discovery is incomplete, the script still completes score comparisons and writes `input_file_inventory.json`, graph parsing diagnostics and, when available, the small local `river_hybrid/*.py` package sources into the review ZIP. It does not include checkpoints, the raw dataset or complete prediction files. Upload this ZIP so the reader can be adapted to the actual format. Partial graph coverage never silently becomes a correlation result.

### Explicit portable graph export

If you already know how to export the saved graph objects, this schema avoids discovery. IDs below are illustrations, not your experimental data:

```json
{
  "graphs": [
    {
      "graph_id": "OUTLET",
      "outlet_id": "OUTLET",
      "node_ids": ["OUTLET", "UPSTREAM_A", "UPSTREAM_B"],
      "edges": [["UPSTREAM_A", "OUTLET"], ["UPSTREAM_B", "OUTLET"]],
      "outlet_area_km2": 125.0
    }
  ]
}
```

Use the actual graph ID matching `analysis/metrics.csv`, actual node IDs and actual directed river edges. `outlet_area_km2` is optional: omit it if unknown; do not sum nested gauge drainage areas. Include all experimental graphs in the export.

```bash
python river_growth_tools/analyze.py --work river_experiment --graphs my_graphs.json
```

Explicit `edges` exports contain **node IDs**, not positions. An explicit `edge_index` field still means zero-based positions. The script does not load pickle/PT files or execute project source to discover graphs.

## Forecast plot options

By default the last 365 days of each selected test series are plotted. Metrics in `forecast_diagnostics/prediction_diagnostics_metrics.csv` describe only that plotted period, not the complete test period. Values are labelled in native saved CSV units; units are not inferred from numerical magnitudes.

```bash
python river_growth_tools/analyze.py --work river_experiment --start 2016-01-01 --end 2017-12-31
```

To skip prediction-file scanning:

```bash
python river_growth_tools/analyze.py --work river_experiment --skip-predictions
```

The prediction reader requires explicit observed/predicted columns, outlet ID, horizon, test split and target date (or issue date from which horizon days are added). It accepts exact run identity from a column or enclosing run directory. Unknown schemas, including ambiguous plain `date` fields, generate diagnostics instead of misleading plots. A review ZIP alone omits prediction files: run in the original experiment directory on your laptop.

## Interpretation limits

This is exploratory analysis of an already-inspected experiment. There are three independent development basin groups and four held-out groups in the supplied results. Seeds are repetitions of model fitting, not independent rivers. Many radii and comparisons are reported; do not choose only the largest correlation. Graph growth, graph size, task information and hydrologic conditions can be confounded. These results do not establish oversquashing, a causal mechanism, or an optimal percentage of attention. Any redesigned selector or model requires fresh independent evaluation.

## Validation performed

The score analysis was checked against your uploaded `metrics.csv`, including exact reproduction of the held-out weather alpha 0.75 and message-passing means. Graph calculations were checked on chains, branching trees, reversed edges and invalid graphs. The version 2 reader was tested on the exact native NPZ/manifest layout, including a nonzero outlet position and missing NPZ graph ID. The full pipeline was exercised on explicitly synthetic graph fixtures, never treated as experimental graph data. Your first diagnostic bundle confirmed all 12 requested prediction series were read and plotted correctly. The actual native graph arrays are still on your laptop; the next run must confirm all 32 load successfully.
