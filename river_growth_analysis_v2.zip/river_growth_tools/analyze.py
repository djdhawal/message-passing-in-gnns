#!/usr/bin/env python3
"""Read-only, CPU postprocessing of completed river_hybrid experiments.

Run from the original project directory:
    python river_growth_tools/analyze.py --work river_experiment
"""
from __future__ import annotations

import argparse
from collections import deque
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import zipfile

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from graph_io import discover_graphs
from prediction_plots import make_prediction_diagnostics


def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, default=str, allow_nan=False) + "\n")


def load_metrics(path):
    df = pd.read_csv(path, dtype={"graph_id": str, "basin_id": str, "run_id": str})
    required = {"graph_id", "basin_id", "spatial_split", "split", "input_regime",
                "model", "alpha", "seed", "horizon", "context_radius", "nrmse", "nse"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"metrics.csv is missing columns: {sorted(missing)}")
    for col in ["alpha", "seed", "horizon", "context_radius", "nrmse", "nse"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    if df[["graph_id", "basin_id", "seed", "horizon", "context_radius", "nrmse"]].isna().any().any():
        raise ValueError("Missing IDs, seeds, horizons, context radii or NRMSE in metrics.csv.")
    if not np.isfinite(df.nrmse).all() or (df.nrmse < 0).any():
        raise ValueError("NRMSE must be finite and nonnegative.")
    df["configuration"] = df["model"]
    hybrid = df.model.eq("hybrid")
    if df.loc[hybrid, "alpha"].isna().any():
        raise ValueError("Hybrid rows have missing alpha values.")
    df.loc[hybrid, "configuration"] = df.loc[hybrid, "alpha"].map(lambda a: f"alpha_{a:g}")
    identity = ["graph_id", "spatial_split", "split", "input_regime", "configuration",
                "context_radius", "horizon", "seed"]
    if df.duplicated(identity).any():
        raise ValueError("Duplicate metric rows for one graph/configuration/horizon/seed. Resolve duplicate runs first.")
    if df.groupby("graph_id").basin_id.nunique().gt(1).any():
        raise ValueError("A graph_id maps to multiple basin_id values.")
    return df


def paired_gains(metrics, alphas):
    """Pair within outlet, task and seed BEFORE averaging any loss differences."""
    full = metrics.loc[metrics.context_radius.eq(-1)].copy()
    keys = ["graph_id", "basin_id", "spatial_split", "split", "input_regime", "horizon", "seed"]
    index = keys[:-1]
    reference_map = {"message_passing": "alpha_0", "attention": "alpha_1",
                     "pooled": "pooled", "outlet_gru": "local"}
    rows, coverage = [], []
    for alpha in alphas:
        candidate = full.loc[full.configuration.eq(f"alpha_{alpha:g}"), keys + ["nrmse"]].rename(columns={"nrmse": "hybrid_nrmse"})
        if candidate.empty:
            raise ValueError(f"No full-context results exist for requested alpha={alpha:g}.")
        for ref, config in reference_map.items():
            baseline = full.loc[full.configuration.eq(config), keys + ["nrmse"]].rename(columns={"nrmse": "reference_nrmse"})
            merged = candidate.merge(baseline, on=keys, how="outer", indicator=True, validate="one_to_one")
            # Every task must have identical observed seed sets in the two configurations.
            for key, group in merged.groupby(index, dropna=False):
                matched = group.loc[group._merge.eq("both")]
                complete = group._merge.eq("both").all() and len(matched) > 0
                coverage.append(dict(zip(index, key), alpha=alpha, reference=ref,
                                     hybrid_seeds=','.join(map(str, sorted(group.loc[group._merge.ne("right_only"), "seed"].astype(int)))),
                                     reference_seeds=','.join(map(str, sorted(group.loc[group._merge.ne("left_only"), "seed"].astype(int)))),
                                     complete_seed_match=bool(complete)))
                if not complete:
                    continue
                for record in matched.drop(columns="_merge").to_dict("records"):
                    record.update(alpha=alpha, reference=ref)
                    record["gain_nrmse"] = record["reference_nrmse"] - record["hybrid_nrmse"]
                    record["gain_percent"] = (100 * record["gain_nrmse"] / record["reference_nrmse"]
                                                if record["reference_nrmse"] > 0 else np.nan)
                    rows.append(record)
    seed = pd.DataFrame(rows)
    if seed.empty:
        raise ValueError("No complete seed-matched hybrid/baseline pairs could be formed.")
    # Diagnostic criterion: positive means hybrid beats BOTH observed endpoints.
    # This is not a deployable test-selected baseline policy.
    endpoints = seed.loc[seed.reference.isin(["message_passing", "attention"])]
    paired = endpoints.pivot(index=keys + ["alpha", "hybrid_nrmse"], columns="reference", values="reference_nrmse")
    if {"message_passing", "attention"}.issubset(paired.columns):
        paired = paired.dropna(subset=["message_passing", "attention"]).reset_index()
        paired["reference_nrmse"] = paired[["message_passing", "attention"]].min(axis=1)
        paired["reference"] = "better_observed_endpoint_diagnostic"
        paired["gain_nrmse"] = paired.reference_nrmse - paired.hybrid_nrmse
        paired["gain_percent"] = 100 * paired.gain_nrmse / paired.reference_nrmse.replace(0, np.nan)
        seed = pd.concat([seed, paired[seed.columns]], ignore_index=True)
    grouped = seed.groupby(index + ["alpha", "reference"], dropna=False)
    graph = grouped.agg(hybrid_nrmse=("hybrid_nrmse", "mean"), reference_nrmse=("reference_nrmse", "mean"),
                        gain_nrmse=("gain_nrmse", "mean"), gain_percent=("gain_percent", "mean"),
                        paired_seed_sd=("gain_nrmse", "std"), n_paired_seeds=("seed", "nunique")).reset_index()
    return seed, graph, pd.DataFrame(coverage)


def growth_features(graph, max_radius):
    """Directed shortest-path upstream balls around the outlet, including self."""
    n = len(graph["node_ids"])
    root = int(graph["root_index"])
    distance_only = graph.get("edges") is None
    if distance_only:
        distance = np.asarray(graph["distances_to_outlet"], dtype=int)
        child_counts = None
    else:
        upstream = [[] for _ in range(n)]
        for source, target in graph["edges"]:
            upstream[int(target)].append(int(source))
        distance = np.full(n, -1, dtype=int)
        distance[root] = 0
        queue = deque([root])
        while queue:
            target = queue.popleft()
            for source in upstream[target]:
                if distance[source] < 0:
                    distance[source] = distance[target] + 1
                    queue.append(source)
        if (distance < 0).any():
            raise ValueError(f"Graph {graph['graph_id']} has nodes with no upstream path to the outlet.")
        child_counts = np.array([len(v) for v in upstream])
    if len(distance) != n or np.sum(distance == 0) != 1 or distance[root] != 0 or (distance < 0).any():
        raise ValueError(f"Invalid distances for graph {graph['graph_id']}.")
    depth = int(distance.max())
    result = {"graph_id": str(graph["graph_id"]), "n_nodes": n, "depth": depth,
              "log_n_nodes": float(np.log(n)), "mean_upstream_hops": float(distance.mean()),
              "source": graph.get("source", ""), "orientation": graph.get("orientation", ""),
              "profile_source": "provided_distances" if distance_only else "directed_edges",
              "topology_verified": bool(graph.get("topology_verified", False)),
              "source_sha256": graph.get("source_sha256", "")}
    if child_counts is not None:
        result.update(max_branching=int(child_counts.max()),
                      mean_branching_nonleaf=float(child_counts[child_counts > 0].mean()) if (child_counts > 0).any() else 0.,
                      leaf_fraction=float((child_counts == 0).mean()))
    for radius in range(max_radius + 1):
        volume = int(np.sum(distance <= radius))
        result[f"volume_r{radius}"] = volume
        result[f"shell_r{radius}"] = int(np.sum(distance == radius))
        result[f"fraction_r{radius}"] = volume / n
        result[f"saturated_r{radius}"] = radius >= depth
        if radius > 0:
            previous = int(np.sum(distance <= radius - 1))
            result[f"log_growth_r{radius}"] = float(np.log(volume / previous))
    # Area is included only if the loader has explicitly identified outlet area.
    area = graph.get("outlet_area_km2")
    if area is not None and np.isfinite(float(area)) and float(area) > 0:
        result["outlet_area_km2"] = float(area)
        result["log_outlet_area_km2"] = float(np.log(float(area)))
    return result


def spearman(x, y):
    x, y = pd.Series(x).rank(method="average"), pd.Series(y).rank(method="average")
    if len(x) < 3 or x.nunique() < 2 or y.nunique() < 2:
        return np.nan
    return float(np.corrcoef(x, y)[0, 1])


def adjusted_rank_correlation(df, feature, controls):
    """Pearson of residual ranks; skip underdetermined, tiny or collinear fits."""
    usable = [c for c in controls if c != feature and c in df and df[c].notna().all() and df[c].nunique() > 1]
    complete = df[[feature, "gain_nrmse"] + usable].dropna()
    if len(complete) < max(10, 2 * (len(usable) + 2)):
        return np.nan, "too_few_outlets_for_adjustment", ','.join(usable)
    if not usable:
        return np.nan, "no_nonconstant_controls", ""
    ranked = complete.rank(method="average")
    design = np.column_stack([np.ones(len(ranked)), ranked[usable].to_numpy()])
    if np.linalg.matrix_rank(design) < design.shape[1]:
        return np.nan, "collinear_controls", ','.join(usable)
    residuals = []
    for variable in [feature, "gain_nrmse"]:
        value = ranked[variable].to_numpy()
        residuals.append(value - design @ np.linalg.lstsq(design, value, rcond=None)[0])
    if any(np.linalg.norm(r) < 1e-8 for r in residuals):
        return np.nan, "no_residual_variation", ','.join(usable)
    return float(np.corrcoef(*residuals)[0, 1]), "descriptive_only", ','.join(usable)


def correlations(joined, max_radius):
    groups = ["spatial_split", "split", "input_regime", "horizon", "alpha", "reference"]
    features = [f"{kind}_r{r}" for kind in ["volume", "shell", "fraction", "log_growth"] for r in range(1, max_radius + 1)]
    features += ["mean_upstream_hops", "max_branching", "mean_branching_nonleaf", "leaf_fraction"]
    rows = []
    for values, group in joined.groupby(groups):
        if group.graph_id.duplicated().any():
            raise ValueError("Correlations must have only one seed-averaged row per outlet/task.")
        for feature in features:
            if feature not in group:
                continue
            usable = group.dropna(subset=[feature, "gain_nrmse"])
            basin_count = usable.basin_id.nunique()
            rho = spearman(usable[feature], usable.gain_nrmse)
            adjusted, reason, controls = adjusted_rank_correlation(usable, feature, ["log_n_nodes", "depth", "log_outlet_area_km2"])
            leave_out = []
            if basin_count >= 4:
                for basin in usable.basin_id.unique():
                    sub = usable.loc[usable.basin_id.ne(basin)]
                    if sub.basin_id.nunique() >= 3:
                        value = spearman(sub[feature], sub.gain_nrmse)
                        if np.isfinite(value):
                            leave_out.append(value)
            rows.append(dict(zip(groups, values), feature=feature, n_outlets=len(usable),
                             n_independent_basins=basin_count, spearman_rho=rho,
                             adjusted_rank_rho=adjusted, adjustment_status=reason, controls=controls,
                             leave_one_basin_out_min=min(leave_out) if leave_out else np.nan,
                             leave_one_basin_out_max=max(leave_out) if leave_out else np.nan,
                             leave_one_basin_out_valid=len(leave_out),
                             n_paired_seeds_min=usable.n_paired_seeds.min() if len(usable) else 0,
                             n_paired_seeds_max=usable.n_paired_seeds.max() if len(usable) else 0,
                             interpretation="exploratory_association_no_p_value_no_causal_claim"))
    return pd.DataFrame(rows)


def plot_growth(profiles, joined, out, radius):
    out.mkdir(parents=True, exist_ok=True)
    radii = list(range(radius + 1))
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    for _, row in profiles.iterrows():
        axes[0].plot(radii, [row[f"volume_r{r}"] for r in radii], alpha=.6)
        axes[1].plot(radii, [row[f"fraction_r{r}"] for r in radii], alpha=.6)
    axes[0].set_ylabel("Upstream nodes including outlet, V(r)")
    axes[1].set_ylabel("Fraction of graph within radius, V(r)/N")
    for ax in axes:
        ax.set_xlabel("Upstream hop radius r")
        ax.grid(alpha=.2)
    fig.suptitle("Upstream volume growth: one line per outlet graph")
    fig.tight_layout()
    fig.savefig(out / "upstream_growth_profiles.png", dpi=160)
    plt.close(fig)
    # A declared fixed radius and all requested alphas: no selection by correlation.
    r = min(2, radius)
    feature = f"volume_r{r}"
    test = joined.loc[joined.split.eq("test")]
    refs = ["message_passing", "attention", "pooled"]
    for (spatial, regime, alpha), group in test.groupby(["spatial_split", "input_regime", "alpha"]):
        horizons = sorted(group.horizon.unique())
        fig, axes = plt.subplots(len(horizons), len(refs), figsize=(12, 3.1 * len(horizons)), squeeze=False)
        basins = sorted(group.basin_id.unique())
        for i, h in enumerate(horizons):
            for j, ref in enumerate(refs):
                ax = axes[i, j]
                sub = group.loc[group.horizon.eq(h) & group.reference.eq(ref)]
                for k, basin in enumerate(basins):
                    part = sub.loc[sub.basin_id.eq(basin)]
                    ax.scatter(part[feature], part.gain_nrmse, color=plt.get_cmap("tab10")(k % 10), label=str(basin), s=35)
                    if spatial == "heldout":
                        for _, row in part.iterrows():
                            ax.annotate(row.graph_id, (row[feature], row.gain_nrmse), fontsize=7, xytext=(3, 3 + 5 * k), textcoords="offset points")
                ax.axhline(0, color="black", linewidth=.7)
                ax.set_title(f"{h:g} day; versus {ref.replace('_', ' ')}")
                ax.set_xlabel(f"V({r}): upstream nodes within {r} hops")
                ax.set_ylabel("Reference NRMSE − hybrid NRMSE")
                ax.margins(x=.12, y=.20)
                ax.grid(alpha=.2)
        handles, labels = axes[0, 0].get_legend_handles_labels()
        if handles:
            fig.legend(handles, labels, title="Basin group", loc="upper center", bbox_to_anchor=(.5, .96), ncol=min(7, len(labels)), fontsize=7)
        fig.suptitle(f"{spatial}; {regime}; α={alpha:g}. Positive gain favors hybrid.", y=.995)
        fig.tight_layout(rect=(0, 0, 1, .90))
        fig.savefig(out / f"growth_gain_{spatial}_{regime}_alpha{alpha:g}.png", dpi=140, bbox_inches="tight")
        plt.close(fig)


def save_input_inventory(work, out):
    """Small schema report for adapting unsupported original package formats."""
    records = []
    for p in sorted(work.rglob("*")):
        if not p.is_file() or p.is_symlink():
            continue
        rel = p.relative_to(work)
        if any(part in {"runs", "raw", "downloads", "analysis", ".venv"} or part.startswith("growth_analysis_") for part in rel.parts):
            continue
        if p.suffix.lower() not in {".json", ".jsonl", ".npz", ".npy", ".pt", ".pkl", ".csv"}:
            continue
        row = {"path": str(rel), "bytes": p.stat().st_size}
        try:
            if p.suffix == ".json" and p.stat().st_size < 5_000_000:
                obj = json.loads(p.read_text())
                row["top_level_type"] = type(obj).__name__
                if isinstance(obj, dict):
                    row["top_level_keys"] = list(obj)[:100]
                    row["value_types"] = {k: type(v).__name__ for k, v in list(obj.items())[:30]}
                elif isinstance(obj, list):
                    row["length"] = len(obj)
                    row["first_item_keys"] = list(obj[0])[:100] if obj and isinstance(obj[0], dict) else []
            elif p.suffix == ".npz" and p.stat().st_size < 20_000_000:
                with np.load(p, allow_pickle=False) as arrays:
                    row["array_names"] = list(arrays.files)
            elif p.suffix == ".csv":
                with p.open() as stream:
                    row["header"] = stream.readline().strip()[:3000]
        except Exception as exc:
            row["inspection_error"] = str(exc)
        records.append(row)
    write_json(out / "input_file_inventory.json", records)
    # Include only local project Python source, never environments, raw data or checkpoints.
    source = work.parent / "river_hybrid"
    if source.is_dir():
        target = out / "source_schema_reference"
        budget = 0
        for p in sorted(source.rglob("*.py")):
            if p.is_symlink() or p.stat().st_size > 500_000:
                continue
            budget += p.stat().st_size
            if budget > 2_000_000:
                break
            dest = target / p.relative_to(source)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(p.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--work", type=Path, default=Path("river_experiment"))
    parser.add_argument("--graphs", type=Path, help="Optional explicit graph JSON/JSONL/NPZ file; see README.")
    parser.add_argument("--alphas", type=float, nargs="+", default=[.25, .5, .75])
    parser.add_argument("--max-radius", type=int, default=8)
    parser.add_argument("--diagnostic-outlets", nargs="+", default=["499", "609"])
    parser.add_argument("--start", help="Optional first target date for forecast plots (YYYY-MM-DD).")
    parser.add_argument("--end", help="Optional last target date for forecast plots (YYYY-MM-DD).")
    parser.add_argument("--skip-predictions", action="store_true", help="Skip the optional streamed prediction CSV pass.")
    args = parser.parse_args()
    if args.max_radius < 1 or any(not 0 < a < 1 for a in args.alphas):
        parser.error("Use max-radius >=1 and interior alpha values strictly between 0 and 1.")
    work = args.work.resolve()
    metrics_file = work / "analysis" / "metrics.csv"
    if not metrics_file.is_file():
        parser.error(f"Cannot find {metrics_file}. Run from the original river_hybrid_lab folder.")
    metrics = load_metrics(metrics_file)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    out = work / f"growth_analysis_{stamp}"
    out.mkdir()
    print(f"Reading saved metrics; outputs: {out}", flush=True)
    seed, gains, coverage = paired_gains(metrics, args.alphas)
    seed.to_csv(out / "paired_seed_gains.csv", index=False)
    gains.to_csv(out / "paired_outlet_gains.csv", index=False)
    coverage.to_csv(out / "seed_pairing_audit.csv", index=False)
    groups = ["spatial_split", "split", "input_regime", "configuration", "context_radius", "horizon"]
    per_outlet = metrics.groupby(groups + ["graph_id"], dropna=False)[["nrmse", "nse"]].mean().reset_index()
    per_outlet.groupby(groups, dropna=False).agg(n_outlets=("graph_id", "nunique"), nrmse=("nrmse", "mean"), nse=("nse", "mean")).reset_index().to_csv(out / "model_summary.csv", index=False)
    metrics.loc[metrics.graph_id.isin(args.diagnostic_outlets)].to_csv(out / "diagnostic_outlet_metrics.csv", index=False)
    expected = sorted(metrics.graph_id.unique())
    print(f"Checking saved graph structures for {len(expected)} outlets...", flush=True)
    graphs, discovery = discover_graphs(work, expected, explicit=args.graphs)
    write_json(out / "graph_discovery.json", discovery)
    print(f"Loaded {len(graphs)}/{len(expected)} graphs.", flush=True)
    metadata_rows = []
    exported_graphs = []
    for graph in graphs:
        meta = graph.get("metadata", {})
        expected_rows = metrics.loc[metrics.graph_id.eq(str(graph["graph_id"]))]
        for key in ["basin_id", "spatial_split"]:
            if key in meta and not expected_rows[key].astype(str).eq(str(meta[key])).all():
                raise ValueError(f"Graph {graph['graph_id']}: manifest {key} disagrees with saved metrics.")
        if meta:
            metadata_rows.append(meta)
        export = {"graph_id": graph["graph_id"], "outlet_id": graph["node_ids"][graph["root_index"]],
                  "node_ids": graph["node_ids"], "source_sha256": graph.get("source_sha256", "")}
        if graph.get("edges") is None:
            export["distances_to_outlet"] = graph["distances_to_outlet"]
        else:
            export["edges"] = [[graph["node_ids"][a], graph["node_ids"][b]] for a, b in graph["edges"]]
        if "outlet_area_km2" in graph:
            export["outlet_area_km2"] = graph["outlet_area_km2"]
        exported_graphs.append(export)
    if exported_graphs:
        write_json(out / "graphs_used.json", {"graphs": exported_graphs})
    if metadata_rows:
        pd.DataFrame(metadata_rows).to_csv(out / "graph_metadata.csv", index=False)
    profiles = pd.DataFrame([growth_features(g, args.max_radius) for g in graphs])
    found = set(profiles.graph_id) if not profiles.empty else set()
    missing = sorted(set(expected) - found)
    status = {"analysis_tool_version": "2.0", "expected_graphs": len(expected), "loaded_graphs": len(found), "missing_graph_ids": missing,
              "distance_only_graph_ids": [g["graph_id"] for g in graphs if not g.get("topology_verified", False)],
              "analysis_is_exploratory": True, "alpha_selection": "all_requested_interior_alphas_reported; no_test_best_selection",
              "n_metric_rows": len(metrics), "seed_pairing_incomplete_tasks": int((~coverage.complete_seed_match).sum()),
              "independent_groups": metrics.groupby("spatial_split").basin_id.nunique().to_dict()}
    if not profiles.empty:
        profiles.to_csv(out / "graph_growth_features.csv", index=False)
        joined = gains.merge(profiles, on="graph_id", how="left", validate="many_to_one")
        joined.to_csv(out / "growth_and_gains.csv", index=False)
        if not missing:
            assoc = correlations(joined, args.max_radius)
            assoc.to_csv(out / "exploratory_correlations.csv", index=False)
            plot_growth(profiles, joined, out / "plots", args.max_radius)
            status["growth_analysis"] = "complete"
        else:
            status["growth_analysis"] = "partial_profiles_only; correlations_skipped_to_avoid_selective_graph_coverage"
    else:
        status["growth_analysis"] = "graph_schema_unrecognized; score_analysis_complete"
    if missing:
        print(f"Graph format needs adaptation for {len(missing)} outlets. Writing a small compatibility report.", flush=True)
        save_input_inventory(work, out)
    if args.skip_predictions:
        status["prediction_diagnostics"] = {"status": "skipped_by_user"}
    else:
        # Fixed declared illustrative models; never select runs by held-out performance.
        runs = ["hybrid__weather__a0p75__s42__rfull", "hybrid__weather_flow__a0__s42__rfull"]
        print("Streaming optional forecast diagnostics for outlets " + ', '.join(args.diagnostic_outlets) + "...", flush=True)
        status["prediction_diagnostics"] = make_prediction_diagnostics(work, out / "forecast_diagnostics", args.diagnostic_outlets, runs, start=args.start, end=args.end)
    write_json(out / "analysis_status.json", status)
    notes = """READ THIS BEFORE INTERPRETING CORRELATIONS

Positive gain = reference NRMSE minus hybrid NRMSE: positive favors the hybrid.
Models are paired at the same outlet, split, input regime, horizon and seed, then
the paired gains are averaged across seeds. Different tasks remain separate.
The better-observed-endpoint comparison takes the better endpoint separately for
each seed before averaging. It is a conservative descriptive requirement to beat
both endpoints, not a baseline selected for deployment. No test-best alpha is selected.

V(r) counts unique upstream nodes at directed hop distance <=r, including the
outlet. Shell(r) counts nodes at exactly r. Profiles plateau at finite graph size;
saturation flags and V(r)/N help expose this. Fixed-radius log growth is reported;
we do not use mean log growth over variable depth (which telescopes to log N/depth).

Correlations are exploratory. Outlet count is not independent basin count, and
seeds are not additional rivers. No p-values or causal claims are produced.
Leave-one-basin-out ranges are sensitivity checks, not confidence intervals.
Adjusted rank correlations residualize ranks on log node count and depth, plus
explicit outlet area when available. Tiny samples, collinearity or no residual
variation cause these estimates to be skipped. These controls do not remove all
hydrologic or sampling confounding. Inspect all declared alphas/radii, not just the
largest correlation. Many correlated comparisons are included for transparency.

These scores have already been inspected. Any hypotheses or models developed
from them need fresh independent evaluation. Growth correlations do not diagnose
oversquashing or prove that alpha is a percentage of useful attention.

Forecast plots use one declared seed and two declared configurations to diagnose
errors. They are not uncertainty bands or an unbiased model selection procedure.
Units follow the source columns; raw physical units are not inferred from numbers.

No training files, predictions or checkpoints were modified. If graph discovery
was incomplete, upload this review ZIP: it includes a file/schema inventory and
small local package Python sources where available, not checkpoints or raw data.
"""
    (out / "READ_ME_FIRST.txt").write_text(notes)
    archive = work.parent / f"river_growth_review_{stamp}.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(out))
    print("\nDone. Growth status:", status["growth_analysis"])
    print(f"Upload this file for review: {archive}")
    print(f"Archive size: {archive.stat().st_size / 1024 ** 2:.2f} MB")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, FileNotFoundError) as exc:
        raise SystemExit(f"Analysis stopped: {exc}")
