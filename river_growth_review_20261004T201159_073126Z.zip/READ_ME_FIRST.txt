READ THIS BEFORE INTERPRETING CORRELATIONS

Positive gain = reference NRMSE minus hybrid NRMSE: positive favors the hybrid.
Models are paired at the same outlet, split, input regime, horizon and seed, then
the paired gains are averaged across seeds. Different tasks remain separate.
The better-observed-endpoint comparison takes the better endpoint separately for
each seed before averaging. It is a conservative descriptive requirement to beat
both endpoints, not a baseline selected for deployment. No test-best alpha is selected.

V(r) counts unique upstream nodes at directed hop distance <=r, including the
outlet. Shell(r) counts nodes at exactly r. Profiles plateau at finite graph size;
saturation flags and V(r)/N help expose this. Fixed-radius log growth is reported;
we do not use mean log growth over variable depth (which telescopes to log N/depth).

Correlations are exploratory. Outlet count is not independent basin count, and
seeds are not additional rivers. No p-values or causal claims are produced.
Leave-one-basin-out ranges are sensitivity checks, not confidence intervals.
Adjusted rank correlations residualize ranks on log node count and depth, plus
explicit outlet area when available. Tiny samples, collinearity or no residual
variation cause these estimates to be skipped. These controls do not remove all
hydrologic or sampling confounding. Inspect all declared alphas/radii, not just the
largest correlation. Many correlated comparisons are included for transparency.

These scores have already been inspected. Any hypotheses or models developed
from them need fresh independent evaluation. Growth correlations do not diagnose
oversquashing or prove that alpha is a percentage of useful attention.

Forecast plots use one declared seed and two declared configurations to diagnose
errors. They are not uncertainty bands or an unbiased model selection procedure.
Units follow the source columns; raw physical units are not inferred from numbers.

No training files, predictions or checkpoints were modified. If graph discovery
was incomplete, upload this review ZIP: it includes a file/schema inventory and
small local package Python sources where available, not checkpoints or raw data.
