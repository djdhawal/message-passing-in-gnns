"""Controlled tree-growth experiments using the river model architecture."""

__version__ = "1.0.0"
