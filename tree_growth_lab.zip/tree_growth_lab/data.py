"""Controlled rooted trees and paired local/distant retrieval examples.

Only NumPy is required. Edges point from an upstream child to its parent.
The same values and marked nodes are used for the two queries in each pair.
No depth or shell-membership feature is exposed to the model.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


PROFILES = ("early", "uniform", "late")
CHANNELS = ("value", "marked", "root", "query")
DEFAULT_CONFIG = {
    "sizes": [63, 127],
    "depths": [4, 8],
    "profiles": list(PROFILES),
    "graphs_per_split": {"train": 2, "val": 1, "test": 2},
    "graph_seed": 20261004,
    "source_count": 4,
    "max_branching": 4,
}


def _configuration(config: dict | None) -> dict:
    result = {**DEFAULT_CONFIG, **(config or {})}
    result["graphs_per_split"] = dict(result["graphs_per_split"])
    for key in ("sizes", "depths", "profiles"):
        result[key] = list(result[key])
    if not result["sizes"] or not result["depths"] or not result["profiles"]:
        raise ValueError("Sizes, depths and profiles must be nonempty.")
    for key in ("sizes", "depths", "profiles"):
        if len(result[key]) != len(set(result[key])):
            raise ValueError(f"Duplicate entries in {key} are not allowed.")
    if any(p not in PROFILES for p in result["profiles"]):
        raise ValueError(f"Unknown growth profile; use {PROFILES}.")
    k = result["source_count"]
    if isinstance(k, bool) or not isinstance(k, (int, np.integer)) or k < 1:
        raise ValueError("source_count must be a positive integer.")
    if not result["graphs_per_split"] or any(
        name not in ("train", "val", "test") for name in result["graphs_per_split"]
    ):
        raise ValueError("Split names must be train, val or test.")
    for name, count in result["graphs_per_split"].items():
        if isinstance(count, bool) or not isinstance(count, (int, np.integer)) or count < 1:
            raise ValueError(f"Graph count for {name} must be a positive integer.")
    if k != 4 or result["max_branching"] != 4:
        raise ValueError("This controlled protocol fixes source_count and max_branching to 4.")
    for depth in result["depths"]:
        if isinstance(depth, bool) or not isinstance(depth, (int, np.integer)) or depth < 4:
            raise ValueError("Every depth must be an integer >= 4.")
        for n in result["sizes"]:
            # Root and four disjoint length-D chains, before extra branches.
            minimum = 1 + k * depth
            maximum = sum(k ** d for d in range(depth + 1))
            if isinstance(n, bool) or not isinstance(n, (int, np.integer)) or not minimum < n < maximum:
                raise ValueError(f"N={n}, depth={depth} must be strictly between {minimum} and {maximum}.")
    return result


def _distances(n: int, edges: np.ndarray, root: int) -> np.ndarray:
    """Build ancestor_dist[target, source], with -1 for unreachable pairs."""
    parent = np.full(n, -1, dtype=np.int64)
    for source, target in edges.T:
        if parent[source] != -1:
            raise ValueError("A non-root node has more than one downstream parent.")
        parent[source] = target
    if parent[root] != -1 or np.count_nonzero(parent == -1) != 1:
        raise ValueError("The tree must have exactly one root with no downstream parent.")
    distances = np.full((n, n), -1, dtype=np.int64)
    for source in range(n):
        target, hops = source, 0
        seen = set()
        while target != -1:
            if target in seen:
                raise ValueError("Cycle detected in directed tree.")
            seen.add(target)
            distances[target, source] = hops
            target = int(parent[target])
            hops += 1
        if root not in seen:
            raise ValueError("A node cannot reach the designated root.")
    return distances


def topology_hash(n: int, edges: np.ndarray, root: int) -> str:
    """Canonical rooted-tree isomorphism hash, invariant to node permutation."""
    children = [[] for _ in range(n)]
    for source, target in np.asarray(edges, dtype=np.int64).T:
        children[int(target)].append(int(source))

    def canonical(node: int) -> str:
        return "(" + "".join(sorted(canonical(child) for child in children[node])) + ")"

    return hashlib.sha256(canonical(int(root)).encode("ascii")).hexdigest()


def _one_graph(n: int, depth: int, profile: str, seed: int, k: int) -> dict:
    rng = np.random.default_rng(seed)
    # Four length-D chains fix root degree, ensure exactly depth D, and
    # provide at least four candidates at every source distance.
    parent = [-1]
    node_depth = [0]
    child_count = [0]
    for branch in range(k):
        previous = 0
        for hops in range(1, depth + 1):
            parent.append(previous)
            node_depth.append(hops)
            child_count.append(0)
            child_count[previous] += 1
            previous = len(parent) - 1
    for new_node in range(len(parent), n):
        eligible = np.array([
            node for node in range(1, len(parent))
            if node_depth[node] < depth and child_count[node] < 4
        ], dtype=np.int64)
        if not len(eligible):
            raise ValueError("No eligible parent remains under fixed degree/depth constraints.")
        position = (np.asarray(node_depth)[eligible] - 1) / max(1, depth - 2)
        if profile == "early":
            weights = np.exp(-6.0 * position)
        elif profile == "late":
            weights = np.exp(6.0 * position)
        else:
            weights = np.ones(len(eligible))
        selected = int(rng.choice(eligible, p=weights / weights.sum()))
        parent.append(selected)
        node_depth.append(node_depth[selected] + 1)
        child_count.append(0)
        child_count[selected] += 1
    sources = list(range(1, n))
    targets = parent[1:]
    shell_sizes = np.bincount(node_depth, minlength=depth + 1)[1:]
    # The original root is 0 only during construction. All arrays use shuffled IDs.
    permutation = rng.permutation(n)
    edges = permutation[np.array([sources, targets], dtype=np.int64)]
    edges = edges[:, rng.permutation(n - 1)]
    root = int(permutation[0])
    distances = _distances(n, edges, root)
    root_distances = distances[root]
    graph = {
        "n_nodes": int(n),
        "depth": int(depth),
        "profile": profile,
        "seed": int(seed),
        "root": root,
        "outlet_index": root,
        "edge_index": edges.tolist(),
        "ancestor_dist": distances.tolist(),
        "topology_hash": topology_hash(n, edges, root),
        "source_count": int(k),
        "root_degree": int(child_count[0]),
        "max_branching": int(max(child_count)),
        "max_branching_limit": 4,
        "generation_method": "four_depth_D_chains_then_degree_capped_parent_allocation",
        "profile_log_weight_span": 6.0,
        "local_source_hops": 1,
        "distant_source_hops": 4,
        "shell_sizes": [1] + shell_sizes.tolist(),
        "local_available": int(np.sum(root_distances == 1)),
        "distant_available": int(np.sum(root_distances == 4)),
        "min_source_reach_verified": bool(np.sum(root_distances == 1) >= k and np.sum(root_distances == 4) >= k),
        "feature_channels": list(CHANNELS),
        "dynamic_steps": 1,
        "static_dim": 0,
        "edge_attr_dim": 2,
        "pair_attr_dim": 2,
    }
    for radius in range(max(8, depth) + 1):
        graph[f"V{radius}"] = int(np.sum(root_distances <= radius))
    return graph


def generate_graphs(config: dict | None = None) -> list[dict]:
    """Generate deterministic, globally isomorphism-disjoint topology splits.

    Cells cross size, exact maximum depth, and parent-depth allocation profile.
    All trees have root degree 4 and at most 4 children per node. Profile groups
    share a generation seed; distinct groups and splits receive independent seeds. Rooted
    isomorphic duplicates are rejected across *all* cells and splits, including
    duplicates with different randomized labels or growth-profile names.
    """
    config = _configuration(config)
    master = np.random.default_rng(config["graph_seed"])
    used, graphs = set(), []
    for n in config["sizes"]:
        for depth in config["depths"]:
            for split in ("train", "val", "test"):
                for replicate in range(config["graphs_per_split"].get(split, 0)):
                    # The profiles in one matched group receive the same RNG seed.
                    # Redraw the entire group only for topology duplication or to
                    # enforce the prespecified, observable early/late V2 contrast.
                    for attempt in range(10000):
                        seed = int(master.integers(0, np.iinfo(np.int64).max))
                        group = [_one_graph(n, depth, profile, seed, config["source_count"])
                                 for profile in config["profiles"]]
                        group_hashes = [graph["topology_hash"] for graph in group]
                        if len(set(group_hashes)) != len(group_hashes) or any(h in used for h in group_hashes):
                            continue
                        by_profile = {graph["profile"]: graph for graph in group}
                        if "early" in by_profile and "late" in by_profile:
                            if by_profile["early"]["V2"] <= by_profile["late"]["V2"]:
                                continue
                        break
                    else:
                        raise ValueError(
                            f"Could not find a unique, distinct profile group for N={n}, D={depth}. "
                            "Increase graph size or reduce requested topology counts."
                        )
                    pairing_id = f"n{n}_d{depth}_{split}_{replicate:03d}"
                    for graph in group:
                        used.add(graph["topology_hash"])
                        graph.update({
                            "graph_id": f"n{n}_d{depth}_{graph['profile']}_{split}_{replicate:03d}",
                            "split": split,
                            "replicate": replicate,
                            "pairing_id": pairing_id,
                            "generation_attempts": attempt + 1,
                            "graph_seed": int(config["graph_seed"]),
                            "matched_profile_seed": seed,
                        })
                        graphs.append(graph)
    validate_graphs(graphs)
    return graphs


def validate_graph(graph: dict) -> None:
    """Raise ValueError for malformed, disconnected or inconsistent topology."""
    n, root, depth = int(graph["n_nodes"]), int(graph["root"]), int(graph["depth"])
    if n < 2 or not 0 <= root < n:
        raise ValueError("Invalid node count or root index.")
    edges = np.asarray(graph["edge_index"])
    if edges.shape != (2, n - 1) or edges.dtype.kind not in "iu":
        raise ValueError("edge_index must be an integer [2,N-1] array.")
    if np.any(edges < 0) or np.any(edges >= n) or np.any(edges[0] == edges[1]):
        raise ValueError("Invalid edge endpoint or self loop.")
    if len(set(map(tuple, edges.T.tolist()))) != n - 1:
        raise ValueError("Duplicate edges.")
    distances = _distances(n, edges, root)
    if not np.array_equal(distances, np.asarray(graph["ancestor_dist"])):
        raise ValueError("Stored ancestor distances disagree with directed edges.")
    root_distances = distances[root]
    if int(root_distances.max()) != depth:
        raise ValueError("Stored depth disagrees with actual maximum root distance.")
    k = int(graph.get("source_count", 4))
    if np.sum(root_distances == 1) < k or np.sum(root_distances == 4) < k:
        raise ValueError("Insufficient nodes at shell 1 or shell 4 for marked sources.")
    children = np.bincount(edges[1], minlength=n)
    if children[root] != 4 or children.max() > 4:
        raise ValueError("Root degree must equal 4 and every branching factor must be <= 4.")
    if int(graph.get("root_degree", 4)) != int(children[root]):
        raise ValueError("Stored root degree is inconsistent.")
    if int(graph.get("max_branching", children.max())) != int(children.max()):
        raise ValueError("Stored maximum branching factor is inconsistent.")
    if "shell_sizes" in graph and not np.array_equal(
        np.bincount(root_distances, minlength=depth + 1), graph["shell_sizes"]
    ):
        raise ValueError("Stored shell sizes are inconsistent.")
    if topology_hash(n, edges, root) != graph["topology_hash"]:
        raise ValueError("Stored topology hash is invalid.")
    for radius in range(max(8, depth) + 1):
        if int(graph[f"V{radius}"]) != int(np.sum(root_distances <= radius)):
            raise ValueError(f"Volume V{radius} is inconsistent.")


def validate_graphs(graphs: list[dict]) -> None:
    """Validate topology and prohibit any graph-ID or rooted-isomorphism overlap."""
    ids, hashes, paired = set(), set(), {}
    for graph in graphs:
        validate_graph(graph)
        if graph["graph_id"] in ids:
            raise ValueError(f"Duplicate graph_id: {graph['graph_id']}")
        if graph["topology_hash"] in hashes:
            raise ValueError("Rooted-isomorphic graph duplicates occur within or across splits.")
        ids.add(graph["graph_id"])
        hashes.add(graph["topology_hash"])
        if "pairing_id" in graph:
            paired.setdefault(graph["pairing_id"], []).append(graph)
    for group in paired.values():
        identities = {
            (g["n_nodes"], g["depth"], g["split"], g["replicate"], g["seed"])
            for g in group
        }
        if len(identities) != 1 or len({g["profile"] for g in group}) != len(group):
            raise ValueError("A matched profile group has inconsistent identity or repeated profiles.")
        profiles = {g["profile"]: g for g in group}
        if "early" in profiles and "late" in profiles and profiles["early"]["V2"] <= profiles["late"]["V2"]:
            raise ValueError("Matched early growth must have strictly larger V2 than late growth.")


def _feature_array(dynamic: np.ndarray) -> tuple[np.ndarray, bool]:
    x = np.asarray(dynamic, dtype=np.float32)
    single = x.ndim == 3
    if single:
        x = x[None]
    if x.ndim != 4 or x.shape[2:] != (1, 4):
        raise ValueError("dynamic must have shape [batch,N,1,4] or [N,1,4].")
    if not np.all(np.isfinite(x)):
        raise ValueError("All dynamic features must be finite.")
    return x, single


def exact_oracle(graph: dict, dynamic: np.ndarray, k: int = 4) -> np.ndarray:
    """Read marked shell 1 or 4 values using the root query; return [batch,1]."""
    x, _ = _feature_array(dynamic)
    root = int(graph["root"])
    if x.shape[1] != int(graph["n_nodes"]):
        raise ValueError("Feature node count disagrees with graph.")
    query = x[:, root, 0, 3]
    if not np.all(np.isin(query, [-1, 1])):
        raise ValueError("Root query must be -1 (local) or +1 (distant).")
    distances = np.asarray(graph["ancestor_dist"])[root]
    radius = np.where(query == -1, 1, 4)
    selected = (distances[None, :] == radius[:, None]) & (x[:, :, 0, 1] == 1)
    if not np.all(selected.sum(axis=1) == k):
        raise ValueError("Each requested shell must contain exactly K marked sources.")
    return (np.sum(x[:, :, 0, 0] * selected, axis=1) / np.sqrt(k)).astype(np.float32)[:, None]


def blind_oracle(dynamic: np.ndarray, k: int = 4) -> np.ndarray:
    """Bayes conditional mean for graph-blind, permutation-invariant features.

    All 2K marked values are visible but their local/distant group membership is
    hidden. Each value has probability 1/2 of belonging to the queried group.
    Under the generator its expected MSE is 0.5, while the zero predictor has
    expected MSE 1.0. This is not an oracle for a model that receives topology.
    """
    x, _ = _feature_array(dynamic)
    marked = x[:, :, 0, 1]
    if not np.all(np.isin(marked, [0, 1])) or not np.all(marked.sum(axis=1) == 2 * k):
        raise ValueError("Features must contain exactly 2K binary marked sources.")
    return (np.sum(x[:, :, 0, 0] * marked, axis=1) / (2 * np.sqrt(k))).astype(np.float32)[:, None]


def make_examples(graph: dict, n_pairs: int, seed: int, k: int = 4) -> dict:
    """Create 2*n_pairs examples with alternating local/distant query targets.

    Dynamic features are float32 [2*n_pairs,N,1,4]. Every node receives an iid
    standard-normal value, including unmarked nodes and the root. Four sources
    at shell 1 and four at shell 4 are marked (for default K=4). Values and marks
    are identical within a pair; only the root query changes. Labels have unit
    marginal variance for either task. Independent seeds must be used for train,
    validation and test examples; the runner controls these seeds.

    Static features have shape [N,0]; edge/pair features are zero arrays with
    shapes [E,2] and [N,N,2], matching the existing river spatial model inputs.
    """
    if isinstance(n_pairs, bool) or not isinstance(n_pairs, (int, np.integer)) or n_pairs < 1:
        raise ValueError("n_pairs must be a positive integer.")
    if isinstance(k, bool) or not isinstance(k, (int, np.integer)) or k < 1:
        raise ValueError("k must be a positive integer.")
    n, root = int(graph["n_nodes"]), int(graph["root"])
    distances = np.asarray(graph["ancestor_dist"])[root]
    local, distant = np.flatnonzero(distances == 1), np.flatnonzero(distances == 4)
    if min(len(local), len(distant)) < k:
        raise ValueError("This graph has too few nodes in a required source shell.")
    rng = np.random.default_rng(seed)
    base = np.zeros((n_pairs, n, 1, 4), dtype=np.float32)
    base[:, :, 0, 0] = rng.standard_normal((n_pairs, n)).astype(np.float32)
    base[:, root, 0, 2] = 1.0
    for index in range(n_pairs):
        selected = np.concatenate((rng.choice(local, k, replace=False), rng.choice(distant, k, replace=False)))
        base[index, selected, 0, 1] = 1.0
    dynamic = np.repeat(base, 2, axis=0)
    dynamic[0::2, root, 0, 3] = -1.0
    dynamic[1::2, root, 0, 3] = 1.0
    target = exact_oracle(graph, dynamic, k)
    return {
        "dynamic": dynamic,
        "target": target,
        "zero_pred": np.zeros_like(target),
        "blind_pred": blind_oracle(dynamic, k),
        "oracle_pred": target.copy(),
        "task": np.tile(np.array([0, 1], dtype=np.int64), n_pairs),
        "pair_id": np.repeat(np.arange(n_pairs, dtype=np.int64), 2),
        "static": np.empty((n, 0), dtype=np.float32),
        "edge_attr": np.zeros((n - 1, 2), dtype=np.float32),
        "pair_attr": np.zeros((n, n, 2), dtype=np.float32),
    }


def serialize_graphs(work: str | Path, graphs: list[dict], config: dict | None = None) -> dict:
    """Write auditable graphs.json and manifest.json beneath a work directory."""
    validate_graphs(graphs)
    work = Path(work)
    work.mkdir(parents=True, exist_ok=True)
    paths = {"graphs": work / "graphs.json", "manifest": work / "manifest.json"}
    paths["graphs"].write_text(json.dumps(graphs, indent=2) + "\n", encoding="utf-8")
    manifest = {
        "format_version": 1,
        "synthetic_fixture": True,
        "description": "Controlled rooted-tree local/distant paired retrieval benchmark",
        "config": _configuration(config),
        "graph_count": len(graphs),
        "feature_channels": list(CHANNELS),
        "source_shells": [1, 4],
        "split_isomorphism_overlap": 0,
        "graphs": [{key: value for key, value in graph.items() if key not in ("edge_index", "ancestor_dist")} for graph in graphs],
    }
    paths["manifest"].write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return {key: str(path) for key, path in paths.items()}
