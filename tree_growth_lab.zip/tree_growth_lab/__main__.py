"""Ubuntu entry point: python -m tree_growth_lab --help."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

from .config import merge_config, preset_config, validate_config


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def initialize(work, preset=None, config_path=None):
    from .data import generate_graphs, serialize_graphs, validate_graphs
    work = Path(work).resolve()
    work.mkdir(parents=True, exist_ok=True)
    saved = work / "config.json"
    cfg = json.loads(saved.read_text()) if saved.exists() and not preset else preset_config(preset or "main")
    if config_path:
        merge_config(cfg, json.loads(Path(config_path).read_text()))
    validate_config(cfg)
    if saved.exists() and json.loads(saved.read_text()) != cfg:
        raise ValueError("This directory has a different frozen configuration. Use a new --work directory.")
    source = Path(__file__).parent
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.glob("*.py"))}
    provenance = {"source_sha256": hashes, "protocol": "paired_shell_query_v1"}
    prov_path = work / "provenance.json"
    if prov_path.exists() and json.loads(prov_path.read_text()) != provenance:
        raise ValueError("Experiment code changed. Use a new --work directory to avoid mixing versions.")
    if not saved.exists():
        dump(saved, cfg)
    if not prov_path.exists():
        dump(prov_path, provenance)
    graph_path = work / "graphs.json"
    if graph_path.exists():
        obj = json.loads(graph_path.read_text())
        graphs = obj["graphs"] if isinstance(obj, dict) else obj
        validate_graphs(graphs)
    else:
        graphs = generate_graphs(cfg["data"])
        serialize_graphs(work, graphs, cfg["data"])
    print(f"Preset: {cfg['preset']}; graphs: {len(graphs)}; paired local/distant tasks.", flush=True)
    return work, cfg, graphs


def main(argv=None):
    parser = argparse.ArgumentParser(description="Controlled volume-growth study; no river data or training files are changed.")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("run", "smoke", "benchmark", "prepare"):
        p = sub.add_parser(name)
        p.add_argument("--work", required=True, type=Path)
        p.add_argument("--preset", choices=["main", "pilot", "smoke"])
        p.add_argument("--config", type=Path, help="JSON overrides for a new experiment directory")
        p.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
        if name == "run":
            p.add_argument("--max-runs", type=int, help="Stop after this many additional fits; rerun to resume")
    p = sub.add_parser("analyze")
    p.add_argument("--work", required=True, type=Path)
    p = sub.add_parser("check")
    p.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    p = sub.add_parser("census", help="Find structurally eligible fresh LamaH dependency groups, without reading discharge")
    p.add_argument("--raw", required=True, type=Path)
    p.add_argument("--seen", required=True, type=Path)
    p.add_argument("--out", default=Path("tree_fresh_river_census"), type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == "census":
            from .real_census import census
            result = census(args.raw, args.seen, args.out)
            print(json.dumps(result, indent=2))
        elif args.command == "analyze":
            from .analyze import analyze
            print(f"Upload for review: {analyze(args.work)}")
        elif args.command == "check":
            from .checks import run_checks
            run_checks(args.device)
        else:
            preset = "smoke" if args.command == "smoke" else args.preset
            work, cfg, graphs = initialize(args.work, preset, args.config)
            if args.command == "prepare":
                print(f"Frozen protocol and graph splits: {work}")
            elif args.command == "benchmark":
                from .runner import benchmark
                benchmark(work, cfg, graphs, device=args.device)
            else:
                from .runner import run_sweep
                max_runs = getattr(args, "max_runs", None)
                if max_runs is not None and max_runs < 0:
                    raise ValueError("--max-runs must be zero or positive")
                # Ubuntu advisory lock prevents concurrent checkpoint writers.
                import fcntl
                with (work / ".training.lock").open("w") as lock:
                    try:
                        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError:
                        raise ValueError("Another training process is using this work directory") from None
                    run_sweep(work, cfg, graphs, device=args.device, max_runs=max_runs)
                from .analyze import analyze
                print(f"Upload for review: {analyze(work, bootstrap=cfg['experiment']['bootstrap_samples'])}")
    except KeyboardInterrupt:
        print("\nStopped. Rerun the same command to resume from the last saved epoch.", file=sys.stderr)
        return 130
    except (ValueError, FileNotFoundError, ImportError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
