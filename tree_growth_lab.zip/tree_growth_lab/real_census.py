"""Find unused river dependency groups using topology only.

This is deliberately a census, not a dataset preparation or evaluation command.
It calls the user's original ``river_hybrid.data`` topology reader, and never
opens discharge/weather time series, downloads data, or changes existing runs.
"""
from __future__ import annotations

import csv
import hashlib
import importlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


def _identifier(value: Any, label: str) -> int:
    if isinstance(value, bool) or value is None:
        raise ValueError(f"Missing or invalid {label}: {value!r}")
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid integer {label}: {value!r}") from exc
    if not math.isfinite(number) or not number.is_integer() or number <= 0:
        raise ValueError(f"Expected a positive integer {label}, got {value!r}")
    return int(number)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _seen_records(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        raise FileNotFoundError(
            f"Seen-graph metadata not found: {path}. Use the manifest from the "
            "completed river experiment, or its exported graph_metadata.csv."
        )
    if path.suffix.lower() == ".csv":
        with path.open(newline="", encoding="utf-8-sig") as handle:
            records = list(csv.DictReader(handle))
    elif path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("graphs"), list):
            raise ValueError("Expected an original manifest object with a graphs list.")
        if data.get("synthetic_fixture"):
            raise ValueError("A synthetic fixture manifest cannot define seen real rivers.")
        if "format_version" in data and data["format_version"] != 1:
            raise ValueError("Unsupported manifest version; expected original format_version=1.")
        records = data["graphs"]
    else:
        raise ValueError("--seen must be manifest.json or graph_metadata.csv.")
    if not records or any(not isinstance(row, dict) for row in records):
        raise ValueError("Seen metadata must contain at least one graph record.")
    used = set()
    for row in records:
        graph_id = _identifier(row.get("graph_id"), "seen graph_id")
        _identifier(row.get("basin_id"), "seen basin_id (transfer dependency group)")
        if graph_id in used:
            raise ValueError(f"Duplicate graph_id {graph_id} in seen metadata.")
        used.add(graph_id)
    return records


def _write_csv(path: Path, records: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="raise")
        writer.writeheader()
        writer.writerows(records)


def census(
    raw: Path,
    seen_manifest: Path,
    out: Path,
    *,
    min_nodes: int = 5,
    max_nodes: int = 127,
    min_depth: int = 1,
    max_depth: int = 8,
) -> dict[str, Any]:
    """Inventory complete upstream trees outside all previously inspected groups.

    Fresh means absent from the supplied seen metadata and disconnected from its
    groups under the original hierarchy and *known* transfer records. It is not
    a guarantee of physical/statistical independence. The caller must supply all
    previously inspected groups, including both development and heldout graphs.
    Structural candidates have not passed training-period availability checks.
    """
    bounds = (min_nodes, max_nodes, min_depth, max_depth)
    if any(isinstance(x, bool) or not isinstance(x, int) for x in bounds):
        raise ValueError("Node and depth bounds must be integers.")
    if not (1 <= min_nodes <= max_nodes and 0 <= min_depth <= max_depth):
        raise ValueError("Require 1 <= min_nodes <= max_nodes and 0 <= min_depth <= max_depth.")
    try:
        reader = importlib.import_module("river_hybrid.data")
    except ModuleNotFoundError as exc:
        if exc.name not in {"river_hybrid", "river_hybrid.data"}:
            raise RuntimeError(
                f"The existing river_hybrid reader needs dependency {exc.name!r}; "
                "activate the existing river_hybrid_lab .venv and retry."
            ) from exc
        raise RuntimeError(
            "Cannot import river_hybrid.data. Run this command from "
            "~/Downloads/river_hybrid_lab with its .venv activated and put "
            "tree_growth_lab beside river_hybrid. No data download is needed."
        ) from exc
    required = ("resolve_root", "_indexed", "_network", "read_table", "_transfer_groups", "_upstream_nodes", "BASIN")
    absent = [name for name in required if not hasattr(reader, name)]
    if absent or reader.BASIN != "B_basins_intermediate_all":
        raise ValueError(f"Unsupported river_hybrid.data reader; missing/incompatible API: {absent}.")

    raw, seen_manifest, out = Path(raw), Path(seen_manifest), Path(out)
    try:
        root = Path(reader.resolve_root(raw)).resolve()
    except FileNotFoundError as exc:
        raise FileNotFoundError(
            f"{exc}\nSet --raw to the existing extracted LamaH-CE directory, or its "
            "parent. It must contain B_basins_intermediate_all and D_gauges. "
            "The census will not download or extract anything."
        ) from exc
    out = out.resolve()
    if out == root or out.is_relative_to(root):
        raise ValueError("Choose --out outside the raw-data directory; raw data remain read-only.")
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise FileExistsError(f"Output is not an empty directory: {out}. Choose a new --out.")
    records = _seen_records(seen_manifest)
    attributes = root / reader.BASIN / "1_attributes"
    hierarchy_path = attributes / "Gauge_hierarchy.csv"
    transfers_path = attributes / "Crossbasin_water_transfers.csv"
    if not transfers_path.is_file():
        raise FileNotFoundError(
            f"Required transfer table missing: {transfers_path}. Refusing to treat "
            "unknown cross-basin connections as independent groups."
        )
    hierarchy = reader._indexed(hierarchy_path, ["NEXTDOWNID"])
    downstream, upstream, parents = reader._network(hierarchy)
    transfers = reader.read_table(transfers_path, ["ID", "To_ID"])
    # The original helper ignores unknown endpoints. For a fresh-group claim we
    # fail closed instead: such links may connect apparently separate groups.
    unresolved = []
    for row_number, (source, target) in enumerate(zip(transfers.ID, transfers.To_ID), start=2):
        source_id = _identifier(source, f"transfer source on CSV row {row_number}")
        target_id = _identifier(target, f"transfer target on CSV row {row_number}")
        missing = [node for node in (source_id, target_id) if node not in parents]
        if missing:
            unresolved.append({"row": row_number, "source": source_id, "target": target_id, "unknown": missing})
    if unresolved:
        raise ValueError(
            "Cannot certify unused transfer-connected groups: transfer endpoints "
            f"are absent from the hierarchy. First records: {unresolved[:5]}. "
            "Resolve the source topology/version before making a new split."
        )
    dependency_groups = reader._transfer_groups(parents, transfers)
    if set(dependency_groups) != set(downstream):
        raise ValueError("Reader returned incomplete dependency groups.")

    seen_groups: set[int] = set()
    seen_nodes: set[int] = set()
    validated = []
    for row in records:
        outlet = _identifier(row["graph_id"], "seen graph_id")
        supplied_group = _identifier(row["basin_id"], "seen basin_id")
        if outlet not in dependency_groups:
            raise ValueError(f"Previously seen outlet {outlet} is absent from this source hierarchy.")
        computed_group = int(dependency_groups[outlet])
        if supplied_group != computed_group:
            raise ValueError(
                f"Dependency group mismatch for seen outlet {outlet}: metadata={supplied_group}, "
                f"source={computed_group}. Refusing a split across inconsistent source versions."
            )
        if row.get("outlet_id") not in (None, "") and _identifier(row["outlet_id"], "outlet_id") != outlet:
            raise ValueError(f"graph_id/outlet_id mismatch in seen metadata at {outlet}.")
        if row.get("terminal_basin_id") not in (None, ""):
            if _identifier(row["terminal_basin_id"], "terminal_basin_id") != int(parents[outlet]):
                raise ValueError(f"Terminal basin mismatch for seen outlet {outlet}.")
        nodes, depths = reader._upstream_nodes(outlet, upstream)
        actual_depth = max(depths.values())
        for key, actual in (("n_nodes", len(nodes)), ("depth", actual_depth)):
            if row.get(key) not in (None, ""):
                try:
                    number = float(row[key])
                except (ValueError, TypeError) as exc:
                    raise ValueError(f"Invalid seen {key} for outlet {outlet}.") from exc
                if not math.isfinite(number) or number != actual:
                    raise ValueError(f"Seen outlet {outlet} {key} mismatch: metadata={row[key]}, source={actual}.")
        seen_groups.add(computed_group)
        seen_nodes.update(nodes)
        validated.append({"graph_id": outlet, "basin_id": computed_group,
                          "terminal_basin_id": int(parents[outlet]), "n_nodes": len(nodes),
                          "depth": actual_depth, "validation": "matched_source"})

    candidate_rows = []
    for outlet in sorted(downstream):
        nodes, depths = reader._upstream_nodes(outlet, upstream)
        n_nodes, depth = len(nodes), max(depths.values())
        if not (min_nodes <= n_nodes <= max_nodes and min_depth <= depth <= max_depth):
            continue
        group = int(dependency_groups[outlet])
        seen_group = group in seen_groups
        overlap = len(set(nodes) & seen_nodes)
        if not seen_group and overlap:
            raise ValueError(f"Topology inconsistency: purported fresh outlet {outlet} overlaps seen nodes.")
        branches = [len(upstream[node]) for node in nodes]
        nonzero = [count for count in branches if count]
        candidate_rows.append({
            "graph_id": outlet, "basin_id": group, "terminal_basin_id": int(parents[outlet]),
            "n_nodes": n_nodes, "depth": depth, "max_branching": max(branches),
            "mean_branching_nonleaf": sum(nonzero) / len(nonzero) if nonzero else 0.0,
            "mean_upstream_distance": sum(depths.values()) / n_nodes,
            **{f"volume_r{radius}": sum(distance <= radius for distance in depths.values()) for radius in (1, 2, 3, 4, 8)},
            "seen_dependency_group": seen_group, "overlap_with_seen_nodes": overlap,
            "status": "excluded_seen_group" if seen_group else "structural_candidate_unqualified",
            "node_ids": json.dumps(sorted(nodes), separators=(",", ":")),
        })
    fresh = [row for row in candidate_rows if not row["seen_dependency_group"]]
    all_groups = sorted(set(int(group) for group in dependency_groups.values()))
    candidate_counts = Counter(row["basin_id"] for row in candidate_rows)
    candidates_by_group: dict[int, list[int]] = defaultdict(list)
    for row in candidate_rows:
        candidates_by_group[row["basin_id"]].append(row["graph_id"])
    group_rows = []
    for group in all_groups:
        group_rows.append({
            "basin_id": group,
            "seen_dependency_group": group in seen_groups,
            "hierarchy_gauges": sum(int(value) == group for value in dependency_groups.values()),
            "terminal_river_count": len({int(parents[node]) for node, value in dependency_groups.items() if int(value) == group}),
            "structural_candidate_outlets": candidate_counts[group],
            "fresh_structural_candidate_outlets": 0 if group in seen_groups else candidate_counts[group],
            "candidate_outlet_ids": json.dumps(candidates_by_group[group], separators=(",", ":")),
        })
    fresh_groups = sorted({row["basin_id"] for row in fresh})
    warnings = [
        "Candidates have NOT passed training-period weather, discharge or attribute availability checks.",
        "Candidate trees can be nested or overlap within a group; outlet count is not independent sample size.",
        "Group isolation uses known transfers only; shared climate, regulation and unrecorded transfers can still induce dependence.",
        "Freshness is relative to the supplied seen metadata. Include every previously inspected development and heldout group.",
    ]
    if len(fresh_groups) < 5:
        warnings.append(
            f"Only {len(fresh_groups)} unused groups contain structurally eligible trees. "
            "This leaves weak support for new group-level correlation claims; do not reuse seen groups to inflate the count."
        )
    if not fresh:
        warnings.append("No fresh structural candidates remain under these bounds. A different source or explicitly exploratory design is needed.")
    sources = {"hierarchy": {"path": str(hierarchy_path), "sha256": _sha256(hierarchy_path)},
               "transfers": {"path": str(transfers_path), "sha256": _sha256(transfers_path)},
               "seen_metadata": {"path": str(seen_manifest.resolve()), "sha256": _sha256(seen_manifest)}}
    summary = {
        "status": "structural_census_complete_not_evaluated", "format_version": 1,
        "raw_root": str(root), "source_files": sources,
        "bounds": dict(zip(("min_nodes", "max_nodes", "min_depth", "max_depth"), bounds)),
        "seen_graphs_validated": len(validated), "seen_dependency_groups": sorted(seen_groups),
        "source_dependency_groups": len(all_groups), "source_transfer_records": len(transfers),
        "all_structural_candidate_outlets": len(candidate_rows), "fresh_candidate_outlets": len(fresh),
        "fresh_candidate_dependency_groups": fresh_groups,
        "fresh_candidate_group_count": len(fresh_groups),
        "structural_definitions": {
            "volume_rK": "Number of gauges within K upstream edges of the outlet, including the outlet; not water volume.",
            "depth": "Maximum upstream hop distance to the outlet in the complete upstream tree.",
            "basin_id": "Transfer-connected dependency group, recomputed with the original river reader.",
            "terminal_basin_id": "Natural downstream terminal river before joining known artificial transfer links.",
        },
        "training_availability_screened": False, "test_time_series_read": False,
        "any_time_series_read": False, "models_trained": False, "test_evaluation_performed": False,
        "warnings": warnings,
        "next_action": "Qualify availability using training dates only, then freeze the graph list and confirmatory analysis before reading new heldout outcomes.",
    }
    protocol = {
        "status": "candidate_list_frozen_pending_training_only_qualification",
        "not_a_final_test_set": True, "source_files": sources,
        "excluded_seen_dependency_groups": sorted(seen_groups),
        "candidate_outlet_ids": [row["graph_id"] for row in fresh],
        "candidate_dependency_groups": fresh_groups,
        "required_next_steps": [
            "Verify all previously inspected groups are included in the seen manifest.",
            "Screen complete upstream trees using only prespecified training-period input/target availability and static/edge validity; do not screen on validation or test outcomes.",
            "Keep each transfer-connected group together; either select disjoint trees or model within-group dependence explicitly.",
            "Freeze qualified outlet IDs, horizons, seeds, models, metrics, alpha selection and group-level uncertainty analysis before new heldout results are opened.",
            "Use the existing development groups for fitting and tuning; do not fit scalers or choose alpha using the new heldout groups.",
            "Evaluate a predeclared volume-growth hypothesis with the fixed model and all endpoint/pooling baselines; report every eligible group and all failed availability checks.",
        ],
    }
    fields = ["graph_id", "basin_id", "terminal_basin_id", "n_nodes", "depth", "max_branching",
              "mean_branching_nonleaf", "mean_upstream_distance", "volume_r1", "volume_r2", "volume_r3", "volume_r4", "volume_r8",
              "seen_dependency_group", "overlap_with_seen_nodes", "status", "node_ids"]
    out.mkdir(parents=True, exist_ok=True)
    _write_csv(out / "fresh_candidates.csv", fresh, fields)
    _write_csv(out / "all_structural_candidates.csv", candidate_rows, fields)
    _write_csv(out / "dependency_groups.csv", group_rows,
               ["basin_id", "seen_dependency_group", "hierarchy_gauges", "terminal_river_count",
                "structural_candidate_outlets", "fresh_structural_candidate_outlets", "candidate_outlet_ids"])
    _write_csv(out / "seen_graph_validation.csv", validated,
               ["graph_id", "basin_id", "terminal_basin_id", "n_nodes", "depth", "validation"])
    for filename, data in (("census_summary.json", summary), ("candidate_protocol.json", protocol)):
        (out / filename).write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return summary
