"""Fast validity checks for the controlled-tree experiment.

These checks use generated fixtures only. They verify the contrast being tested,
not whether one model wins. No river data or saved experiment is modified.
"""
from __future__ import annotations

import numpy as np

from .data import (blind_oracle, exact_oracle, generate_graphs, make_examples,
                   topology_hash, validate_graphs)


def _require(condition, message):
    if not bool(condition):
        raise AssertionError(message)


def _graph_checks():
    graphs = generate_graphs({
        "sizes": [63, 127], "depths": [4, 8],
        "profiles": ["early", "uniform", "late"],
        "graphs_per_split": {"train": 1, "val": 1, "test": 1},
        "source_count": 4, "graph_seed": 20261004,
    })
    validate_graphs(graphs)
    _require(len({g["topology_hash"] for g in graphs}) == len(graphs),
             "Rooted-isomorphic topologies overlap within/across splits")
    matched = {}
    for graph in graphs:
        n, root = graph["n_nodes"], graph["root"]
        edges = np.asarray(graph["edge_index"])
        distance = np.asarray(graph["ancestor_dist"])[root]
        child_count = np.bincount(edges[1], minlength=n)
        _require(edges.shape == (2, n - 1), "Tree edge count disagrees with N")
        _require(distance.max() == graph["depth"], "Actual depth differs from D")
        _require(child_count[root] == 4, "Root degree is not held fixed at four")
        _require(child_count.max() <= 4, "A node has more than four children")
        _require(np.sum(distance == 1) >= 4 and np.sum(distance == 4) >= 4,
                 "The task lacks four available sources in a required shell")
        key = (n, graph["depth"], graph["split"], graph["replicate"])
        matched.setdefault(key, {})[graph["profile"]] = graph
    for cell in matched.values():
        _require(cell["early"]["V2"] > cell["late"]["V2"],
                 "The matched early-growth graph does not have larger V2")
    print(f"PASS topology: {len(graphs)} unique rooted trees; matched N/D; "
          "four root children; max four children; early V2 > late V2")
    return next(g for g in graphs if g["n_nodes"] == 63 and g["depth"] == 8)


def _task_checks(graph):
    # Hand-computable check independent of the generated-label implementation:
    # 1+2+3+4 divided by sqrt(4) is 5; 5+6+7+8 divided by sqrt(4) is 13.
    # Large unmarked values must not enter either answer.
    root = graph["root"]
    distance = np.asarray(graph["ancestor_dist"])[root]
    hand = np.zeros((2, graph["n_nodes"], 1, 4), dtype=np.float32)
    hand[:, :, 0, 0] = 1000
    hand[:, root, 0, 2] = 1
    hand[:, root, 0, 3] = [-1, 1]
    for radius, values in ((1, [1, 2, 3, 4]), (4, [5, 6, 7, 8])):
        sources = np.flatnonzero(distance == radius)[:4]
        hand[:, sources, 0, 1] = 1
        hand[:, sources, 0, 0] = values
    _require(np.array_equal(exact_oracle(graph, hand), [[5], [13]]),
             "Exact oracle failed a hand-calculated local/distant example")
    _require(np.array_equal(blind_oracle(hand), [[9], [9]]),
             "Graph-blind oracle failed a hand-calculated example")
    examples = make_examples(graph, 10000, seed=781)
    x, y = examples["dynamic"], examples["target"]
    marks = x[:, :, 0, 1]
    for radius in (1, 4):
        _require(np.all(marks[:, distance == radius].sum(1) == 4),
                 f"Expected exactly four marked sources at shell {radius}")
    _require(np.all(marks.sum(1) == 8), "Marks appear outside source shells")
    _require(np.array_equal(x[0::2, :, :, :3], x[1::2, :, :, :3]),
             "Local/distant examples must share values, marks and root marker")
    _require(np.all(x[0::2, graph["root"], 0, 3] == -1)
             and np.all(x[1::2, graph["root"], 0, 3] == 1),
             "Paired queries are not local=-1/distant=+1")
    _require(np.count_nonzero(x[:, :, 0, 3]) == len(x),
             "Query features should be present only at the root")
    _require(np.array_equal(y, exact_oracle(graph, x)),
             "Generated targets disagree with the exact topology oracle")
    blind = blind_oracle(x)
    for task, label in ((0, "local"), (1, "distant")):
        yt = y[task::2, 0]
        variance = float(np.var(yt))
        blind_mse = float(np.mean((yt - blind[task::2, 0]) ** 2))
        _require(abs(variance - 1.0) < 0.08,
                 f"{label} target variance {variance:.3f} is inconsistent with one")
        _require(abs(blind_mse - 0.5) < 0.05,
                 f"{label} blind oracle MSE {blind_mse:.3f} is inconsistent with 0.5")
        print(f"PASS task {label}: target variance={variance:.4f}, "
              f"graph-blind oracle MSE={blind_mse:.4f} (expected 1 and 0.5)")
    fresh = make_examples(graph, 2, seed=782)
    _require(not np.array_equal(fresh["dynamic"], x[:4]),
             "Different feature seeds generated identical examples")
    return {key: (value[:4].copy() if key in ("dynamic", "target", "task", "pair_id") else value)
            for key, value in examples.items()}


def _model_checks(graph, examples, device):
    import torch
    from .river_models import ModelConfig, RiverForecaster

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    target_device = torch.device(device)
    if target_device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable; use --device cpu or fix PyTorch CUDA first")
    previous_threads = torch.get_num_threads()
    torch.set_num_threads(min(2, previous_threads))
    try:
        def tensor(array, dtype=torch.float32):
            return torch.as_tensor(array, dtype=dtype, device=target_device)

        dynamic = tensor(examples["dynamic"])
        target = tensor(examples["target"])
        inputs = {
            "static": tensor(examples["static"]),
            "edge_index": tensor(graph["edge_index"], torch.long),
            "edge_attr": tensor(examples["edge_attr"]),
            "ancestor_dist": tensor(graph["ancestor_dist"], torch.long),
            "outlet_index": graph["root"],
            "pair_attr": tensor(examples["pair_attr"]),
        }
        # perm[new index] = old index; inverse maps the original edge endpoints.
        perm = np.random.default_rng(412).permutation(graph["n_nodes"])
        inverse = np.argsort(perm)
        perm_t = tensor(perm, torch.long)
        permuted_edges = inverse[np.asarray(graph["edge_index"])]
        permuted_root = int(inverse[graph["root"]])
        permuted_dist = np.asarray(graph["ancestor_dist"])[perm][:, perm]
        permuted = {
            **inputs,
            "static": inputs["static"][perm_t],
            "edge_index": tensor(permuted_edges, torch.long),
            "ancestor_dist": tensor(permuted_dist, torch.long),
            "outlet_index": permuted_root,
            "pair_attr": inputs["pair_attr"][perm_t][:, perm_t],
        }
        graph_permuted = {**graph, "root": permuted_root,
                          "outlet_index": permuted_root,
                          "edge_index": permuted_edges.tolist(),
                          "ancestor_dist": permuted_dist.tolist()}
        _require(topology_hash(graph["n_nodes"], permuted_edges, permuted_root)
                 == graph["topology_hash"], "Canonical topology hash changes under relabeling")
        _require(np.allclose(exact_oracle(graph_permuted, examples["dynamic"][:, perm]),
                            examples["target"], atol=1e-6),
                 "Oracle prediction changes under consistent node permutation")

        counts = {}
        for kind, alpha in (("hybrid", 0.0), ("hybrid", 0.5), ("hybrid", 1.0),
                            ("local", 0.0), ("pooled", 0.0)):
            torch.manual_seed(211)
            cfg = ModelConfig(dynamic_dim=4, static_dim=0, edge_dim=2,
                              hidden_dim=16, heads=2, layers=8, horizons=(1,),
                              alpha=alpha, dropout=0.0, kind=kind, max_distance=8)
            model = RiverForecaster(cfg).to(target_device).eval()
            prediction = model(dynamic, **inputs)
            _require(prediction.shape == target.shape and torch.isfinite(prediction).all(),
                     f"{kind} alpha={alpha}: invalid forward output")
            with torch.no_grad():
                moved = model(dynamic[:, perm_t], **permuted)
            _require(torch.allclose(prediction, moved, atol=2e-5, rtol=2e-5),
                     f"{kind} alpha={alpha}: node permutation changes output")
            loss = (prediction - target).square().mean()
            loss.backward()
            gradients = [p.grad for p in model.parameters() if p.grad is not None]
            _require(gradients and all(torch.isfinite(g).all() for g in gradients),
                     f"{kind} alpha={alpha}: invalid backward gradients")
            count = model.parameter_counts()
            _require(count["total"] == count["active"] + count["inactive"],
                     "Parameter accounting is inconsistent")
            if kind == "hybrid":
                counts[alpha] = count
                for layer in model.layers:
                    local_used = any(p.grad is not None for p in layer.local.parameters())
                    attention_used = any(p.grad is not None for p in layer.global_attention.parameters())
                    _require(local_used == (alpha < 1) and attention_used == (alpha > 0),
                             "Endpoint forward/backward unexpectedly uses an inactive branch")
            print(f"PASS model {kind} alpha={alpha:g} on {target_device}: "
                  f"permutation invariant; finite forward/backward; "
                  f"active={count['active']}, registered={count['total']}")
        _require(len({value["total"] for value in counts.values()}) == 1,
                 "Hybrid registered parameter counts change with alpha")
        _require(counts[0.5]["inactive"] == 0
                 and counts[0.0]["inactive"] > 0 and counts[1.0]["inactive"] > 0,
                 "Hybrid endpoint/in-between parameter accounting is incorrect")

        distances = inputs["ancestor_dist"][graph["root"]]
        for layers in (1, 8):
            torch.manual_seed(934)
            model = RiverForecaster(ModelConfig(
                dynamic_dim=4, static_dim=0, edge_dim=2, hidden_dim=16,
                heads=2, layers=layers, horizons=(1,), alpha=0.0,
                dropout=0.0, max_distance=8,
            )).to(target_device).eval()
            x = dynamic.detach().clone().requires_grad_(True)
            gradient = torch.autograd.grad(model(x, **inputs).sum(), x)[0]
            # Exactly zero tests the computational graph, independent of magnitude.
            if layers == 1:
                beyond = gradient[:, distances > 1]
                _require(torch.count_nonzero(beyond).item() == 0,
                         "One message-passing layer receives information beyond one hop")
                print("PASS reach negative control: one MP layer has exactly zero input gradient beyond one hop")
            else:
                shell4 = gradient[:, distances == 4, :, 0]
                _require(torch.isfinite(shell4).all() and torch.count_nonzero(shell4).item() > 0,
                         "Eight message-passing layers have no computational path from shell four")
                print("PASS reach: eight MP layers have a nonzero value gradient from shell four "
                      "(this verifies access, not successful learning or absence of oversquashing)")
    finally:
        torch.set_num_threads(previous_threads)


def run_checks(device="auto") -> None:
    """Run fixed-fixture science/integration checks; raise on any violation."""
    graph = _graph_checks()
    examples = _task_checks(graph)
    _model_checks(graph, examples, device)
    print("All controlled-tree validity checks passed. No experiment scores were produced.")
