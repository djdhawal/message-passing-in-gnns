"""Paired, validation-selected analysis for the controlled tree experiment.

Only completed runs are read. Training seeds are repeated fits, not independent
graph observations. Confidence intervals resample matched early/late graph pairs
after averaging the paired contrast across training seeds.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

REQUIRED = {
    "seed", "configuration", "alpha", "kind", "graph_id", "split", "task",
    "n_nodes", "depth", "profile", "replicate", "mse", "n_examples",
    "zero_mse", "blind_oracle_mse", "oracle_mse",
}
KEY = ["seed", "graph_id", "split", "task"]
STRATA = ["split", "task", "n_nodes", "depth", "profile"]
METHOD = ["configuration", "kind", "alpha"]
MATCH = ["split", "task", "n_nodes", "depth", "replicate", "seed"]


def _json(path: Path):
    return json.loads(path.read_text())


def _save_json(path: Path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False, default=str) + "\n")


def _write(frame: pd.DataFrame, path: Path):
    frame.to_csv(path, index=False)


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_runs(work: Path):
    frames, runs, provenance, skipped = [], [], [], []
    for folder in sorted((work / "runs").glob("*")):
        if not folder.is_dir():
            continue
        marker, metric_file = folder / "result.json", folder / "metrics.csv"
        if not marker.exists():
            skipped.append({"run": folder.name, "reason": "no completion marker"})
            continue
        result = _json(marker)
        if result.get("status") not in {"complete", "completed"}:
            skipped.append({"run": folder.name, "reason": "status is not complete"})
            continue
        if not metric_file.exists():
            raise ValueError(f"Completed run has no metrics.csv: {folder}")
        frame = pd.read_csv(metric_file, dtype={"graph_id": str})
        missing = REQUIRED.difference(frame.columns)
        if missing:
            raise ValueError(f"{metric_file}: missing columns {sorted(missing)}")
        if frame.empty:
            raise ValueError(f"Completed run has empty metrics: {folder}")
        frame["split"] = frame["split"].replace({"val": "validation", "dev_val": "validation"})
        if not set(frame["split"]).issubset({"validation", "test"}):
            raise ValueError(f"Unexpected evaluation splits in {folder}")
        if not set(frame["task"]).issubset({"local", "distant"}):
            raise ValueError(f"Unexpected tasks in {folder}")
        numeric = ["mse", "zero_mse", "blind_oracle_mse", "oracle_mse", "n_examples", "seed", "n_nodes", "depth", "replicate"]
        for column in numeric:
            frame[column] = pd.to_numeric(frame[column], errors="raise")
            if not np.isfinite(frame[column]).all():
                raise ValueError(f"Non-finite {column} in {folder}")
        if (frame[["mse", "zero_mse", "blind_oracle_mse", "oracle_mse"]] < 0).any().any():
            raise ValueError(f"Negative squared error in {folder}")
        if (frame["n_examples"] <= 0).any():
            raise ValueError(f"No evaluation examples in {folder}")
        frame["alpha"] = pd.to_numeric(frame["alpha"], errors="raise")
        frame["run_id"] = folder.name
        frames.append(frame)
        row = {"run_id": folder.name}
        row.update({k: v for k, v in result.items() if isinstance(v, (str, int, float, bool)) or v is None})
        runs.append(row)
        provenance.append({"run_id": folder.name, "metrics_sha256": _hash(metric_file),
                           "result_sha256": _hash(marker)})
    if not frames:
        raise ValueError(f"No completed runs found in {work / 'runs'}")
    metrics = pd.concat(frames, ignore_index=True)
    if metrics.duplicated(["configuration"] + KEY).any():
        raise ValueError("Duplicate configuration/seed/graph/split/task metrics; cannot pair safely")
    if metrics.groupby("configuration", dropna=False)["kind"].nunique().max() != 1:
        raise ValueError("Configuration has multiple model kinds")
    # All methods must evaluate exactly the same targets, and graph metadata must
    # not change between methods, seeds, or tasks.
    for column in ["n_nodes", "depth", "profile", "replicate"]:
        if metrics.groupby(["graph_id", "split"])[column].nunique().max() != 1:
            raise ValueError(f"Conflicting graph metadata: {column}")
    for column in ["n_examples", "zero_mse", "blind_oracle_mse", "oracle_mse"]:
        span = metrics.groupby(["graph_id", "split", "task"])[column].agg(["min", "max"])
        if not np.allclose(span["min"], span["max"], rtol=1e-7, atol=1e-10):
            raise ValueError(f"Evaluation targets differ across methods/seeds: {column}")
    return metrics, pd.DataFrame(runs), provenance, skipped


def _summaries(metrics: pd.DataFrame, out: Path):
    group = STRATA + METHOD + ["seed"]
    seed = metrics.groupby(group, dropna=False).agg(
        mse=("mse", "mean"), n_graphs=("graph_id", "nunique"),
        zero_mse=("zero_mse", "mean"), blind_oracle_mse=("blind_oracle_mse", "mean"),
        oracle_mse=("oracle_mse", "mean"), n_examples=("n_examples", "sum"),
    ).reset_index()
    _write(seed, out / "stratum_seed_metrics.csv")
    summary = seed.groupby(STRATA + METHOD, dropna=False).agg(
        mse_mean=("mse", "mean"), mse_seed_std=("mse", "std"),
        n_seeds=("seed", "nunique"), n_graphs_per_seed_min=("n_graphs", "min"),
        n_graphs_per_seed_max=("n_graphs", "max"),
        zero_mse=("zero_mse", "mean"), blind_oracle_mse=("blind_oracle_mse", "mean"),
        oracle_mse=("oracle_mse", "mean"),
    ).reset_index()
    _write(summary, out / "stratum_summary.csv")
    # Equal weight for each size/depth/profile/task stratum, then each seed.
    balanced_seed = seed.groupby(["split"] + METHOD + ["seed"], dropna=False).agg(
        mse=("mse", "mean"), n_strata=("mse", "size")
    ).reset_index()
    _write(balanced_seed, out / "balanced_seed_metrics.csv")
    balanced = balanced_seed.groupby(["split"] + METHOD, dropna=False).agg(
        mse_mean=("mse", "mean"), mse_seed_std=("mse", "std"),
        n_seeds=("seed", "nunique"), n_strata_min=("n_strata", "min"),
        n_strata_max=("n_strata", "max"),
    ).reset_index()
    _write(balanced, out / "balanced_summary.csv")
    return summary, seed


def _hybrids(metrics: pd.DataFrame) -> pd.DataFrame:
    methods = metrics[METHOD].drop_duplicates()
    return methods[methods["alpha"].notna() & methods["alpha"].between(0, 1)].copy()


def _paired_gains(metrics: pd.DataFrame, out: Path):
    hybrids = _hybrids(metrics)
    references = {}
    for name, alpha in [("message_passing", 0.0), ("attention", 1.0)]:
        candidates = hybrids[np.isclose(hybrids["alpha"], alpha)]["configuration"].unique()
        if len(candidates) == 1:
            references[name] = candidates[0]
        elif len(candidates) > 1:
            raise ValueError(f"Multiple {name} endpoint configurations")
    pool = metrics.loc[metrics["kind"].eq("pooled"), "configuration"].unique()
    if len(pool) == 1:
        references["pooled"] = pool[0]
    elif len(pool) > 1:
        raise ValueError("Multiple pooled reference configurations")
    result, audit = [], []
    for method in hybrids.itertuples(index=False):
        left = metrics[metrics["configuration"].eq(method.configuration)].copy()
        for label, reference in references.items():
            right = metrics[metrics["configuration"].eq(reference)][KEY + ["mse"]].rename(columns={"mse": "reference_mse"})
            pairs = left.merge(right, on=KEY, how="outer", indicator=True, validate="one_to_one")
            counts = pairs["_merge"].value_counts()
            audit.append({"configuration": method.configuration, "reference": label,
                          "reference_configuration": reference, "matched": int(counts.get("both", 0)),
                          "hybrid_only": int(counts.get("left_only", 0)),
                          "reference_only": int(counts.get("right_only", 0))})
            pairs = pairs[pairs["_merge"].eq("both")].drop(columns="_merge")
            pairs["reference"] = label
            pairs["reference_configuration"] = reference
            pairs["gain"] = pairs["reference_mse"] - pairs["mse"]
            pairs["relative_gain_pct"] = np.where(pairs["reference_mse"] > 0,
                                                    100 * pairs["gain"] / pairs["reference_mse"], np.nan)
            result.append(pairs)
    audit = pd.DataFrame(audit)
    _write(audit, out / "baseline_pairing_audit.csv")
    gains = pd.concat(result, ignore_index=True) if result else pd.DataFrame()
    _write(gains, out / "paired_graph_seed_gains.csv")
    if not gains.empty:
        seed = gains.groupby(STRATA + ["configuration", "alpha", "reference", "seed"], dropna=False).agg(
            gain=("gain", "mean"), reference_mse=("reference_mse", "mean"),
            hybrid_mse=("mse", "mean"), n_graphs=("graph_id", "nunique")
        ).reset_index()
        # Percentage from aggregate MSE, not the mean of graph-level ratios.
        seed["relative_gain_pct"] = 100 * seed["gain"] / seed["reference_mse"].replace(0, np.nan)
        _write(seed, out / "stratum_seed_gains.csv")
    return gains, audit, references


def _bootstrap(values: np.ndarray, samples: int, rng):
    if len(values) < 2 or samples == 0:
        return np.nan, np.nan
    # Chunking bounds memory when the full experiment has many graph pairs.
    means = []
    for start in range(0, samples, 250):
        indices = rng.integers(0, len(values), size=(min(250, samples - start), len(values)))
        means.extend(values[indices].mean(axis=1))
    return tuple(np.quantile(means, [.025, .975]))


def _contrasts(gains: pd.DataFrame, out: Path, bootstrap: int):
    if gains.empty:
        return pd.DataFrame(), pd.DataFrame()
    keys = MATCH + ["configuration", "alpha", "reference"]
    early = gains[gains["profile"].eq("early")][keys + ["gain", "graph_id"]].rename(
        columns={"gain": "early_gain", "graph_id": "early_graph_id"})
    late = gains[gains["profile"].eq("late")][keys + ["gain", "graph_id"]].rename(
        columns={"gain": "late_gain", "graph_id": "late_graph_id"})
    pairs = early.merge(late, on=keys, how="outer", validate="one_to_one", indicator=True)
    bad = pairs[~pairs["_merge"].eq("both")]
    _write(bad, out / "growth_pairing_mismatches.csv")
    pairs = pairs[pairs["_merge"].eq("both")].drop(columns="_merge")
    pairs["contrast"] = pairs["early_gain"] - pairs["late_gain"]
    _write(pairs, out / "early_late_seed_contrasts.csv")
    grouping = ["split", "task", "n_nodes", "depth", "configuration", "alpha", "reference"]
    output, graph_rows = [], []
    rng = np.random.default_rng(20261004)
    for group_key, block in pairs.groupby(grouping, dropna=False, sort=True):
        meta = dict(zip(grouping, group_key))
        # Every paired graph must have the same seed set. Missing seeds never
        # silently receive less weight or masquerade as additional graph pairs.
        seed_sets = block.groupby("replicate")["seed"].apply(lambda v: tuple(sorted(v)))
        all_seeds = tuple(sorted(block["seed"].unique()))
        eligible = seed_sets[seed_sets.map(lambda values: values == all_seeds)].index
        block = block[block["replicate"].isin(eligible)]
        graph_means = block.groupby("replicate").agg(
            contrast=("contrast", "mean"), early_gain=("early_gain", "mean"),
            late_gain=("late_gain", "mean"), n_seeds=("seed", "nunique"),
            early_graph_id=("early_graph_id", "first"), late_graph_id=("late_graph_id", "first"),
        ).reset_index()
        for row in graph_means.to_dict("records"):
            graph_rows.append(dict(meta, **row))
        values = graph_means["contrast"].to_numpy()
        low, high = _bootstrap(values, bootstrap, rng)
        per_seed = block.groupby("seed")["contrast"].mean()
        output.append(dict(meta, early_minus_late_gain=float(values.mean()) if len(values) else np.nan,
                           ci025=low, ci975=high, n_pairs=len(values), n_seeds=len(all_seeds),
                           seed_std=float(per_seed.std()) if len(per_seed) > 1 else np.nan,
                           excluded_pairs_missing_seeds=int(len(seed_sets) - len(eligible)),
                           bootstrap_samples=bootstrap, small_n_pairs=bool(len(values) < 20),
                           interval_scope="descriptive_graph_pair_bootstrap_conditional_on_trained_models"))
    result = pd.DataFrame(output)
    _write(pd.DataFrame(graph_rows), out / "early_late_graph_pair_contrasts.csv")
    _write(result, out / "early_late_summary.csv")
    return result, bad


def _selection(metrics: pd.DataFrame, gains: pd.DataFrame, out: Path, references: dict, sweep_complete: bool):
    hybrids = _hybrids(metrics)
    validation = metrics[metrics["split"].eq("validation")]
    candidates = hybrids["configuration"].tolist()
    expected_seeds = sorted(metrics["seed"].unique().tolist())
    keysets = {}
    for config in candidates:
        part = validation[validation["configuration"].eq(config)]
        keysets[config] = set(map(tuple, part[KEY].to_numpy()))
    complete = len(candidates) >= 2 and all(keysets.values()) and len({frozenset(v) for v in keysets.values()}) == 1
    has_endpoints = {"message_passing", "attention"}.issubset(references)
    has_seeds = all(sorted(validation.loc[validation["configuration"].eq(c), "seed"].unique()) == expected_seeds for c in candidates)
    selection = {"status": "blocked", "selection_data": "validation only",
                 "weighting": "equal task/size/depth/profile strata; equal graph replicates and training seeds within strata",
                 "test_used_for_selection": False, "training": "one jointly trained local/distant model per configuration and seed"}
    if not complete or not has_endpoints or not has_seeds or not sweep_complete:
        selection["reason"] = "Scheduled sweep is incomplete, hybrid validation rows/seeds do not match, or an endpoint is absent"
        _save_json(out / "validation_selection.json", selection)
        return selection
    seed_strata = validation[validation["configuration"].isin(candidates)].groupby(
        ["configuration", "alpha", "seed", "task", "n_nodes", "depth", "profile"], dropna=False)["mse"].mean().reset_index()
    scores = seed_strata.groupby(["configuration", "alpha"], dropna=False)["mse"].mean().reset_index()
    scores = scores.sort_values(["mse", "alpha", "configuration"], kind="stable")
    winner = scores.iloc[0]
    selection.update(status="selected", selected_configuration=str(winner["configuration"]),
                     selected_alpha=float(winner["alpha"]), validation_mse=float(winner["mse"]),
                     tie_rule="lowest alpha, then configuration name, for exact score ties",
                     candidates=scores.to_dict("records"))
    # This is a routing diagnostic on jointly trained models, not evidence that
    # independently trained task-specific models have been compared.
    per_task = seed_strata.groupby(["task", "configuration", "alpha"], dropna=False)["mse"].mean().reset_index()
    per_task = per_task.sort_values(["task", "mse", "alpha", "configuration"], kind="stable").groupby("task").head(1)
    selection["per_task_validation_choice_diagnostic"] = per_task.to_dict("records")
    # Persist the validation decision before forming a heldout comparison.
    _save_json(out / "validation_selection.json", selection)
    if not gains.empty:
        chosen = gains[gains["configuration"].eq(winner["configuration"]) & gains["split"].eq("test")]
        _write(chosen, out / "selected_test_graph_seed_gains.csv")
        if not chosen.empty:
            seed = chosen.groupby(["reference", "seed", "task", "n_nodes", "depth", "profile"], dropna=False).agg(
                gain=("gain", "mean"), hybrid_mse=("mse", "mean"), reference_mse=("reference_mse", "mean")
            ).reset_index()
            task_seed = seed.groupby(["reference", "task", "seed"])[["gain", "hybrid_mse", "reference_mse"]].mean().reset_index()
            task_summary = task_seed.groupby(["reference", "task"]).agg(
                gain_mean=("gain", "mean"), gain_seed_std=("gain", "std"),
                hybrid_mse=("hybrid_mse", "mean"), reference_mse=("reference_mse", "mean"),
                n_seeds=("seed", "nunique"),
            ).reset_index()
            task_summary["relative_gain_pct"] = 100 * task_summary["gain_mean"] / task_summary["reference_mse"].replace(0, np.nan)
            task_summary["selected_configuration"] = winner["configuration"]
            _write(task_summary, out / "selected_test_task_comparison.csv")
            seed = seed.groupby(["reference", "seed"])[["gain", "hybrid_mse", "reference_mse"]].mean().reset_index()
            seed["relative_gain_pct"] = 100 * seed["gain"] / seed["reference_mse"].replace(0, np.nan)
            _write(seed, out / "selected_test_balanced_seed_gains.csv")
            summary = seed.groupby("reference").agg(
                gain_mean=("gain", "mean"), gain_seed_std=("gain", "std"),
                hybrid_mse=("hybrid_mse", "mean"), reference_mse=("reference_mse", "mean"),
                n_seeds=("seed", "nunique"),
            ).reset_index()
            summary["relative_gain_pct"] = 100 * summary["gain_mean"] / summary["reference_mse"].replace(0, np.nan)
            summary["selected_configuration"] = winner["configuration"]
            _write(summary, out / "selected_test_comparison.csv")
    return selection


def _plots(summary: pd.DataFrame, contrasts: pd.DataFrame, metrics: pd.DataFrame, out: Path):
    plots = out / "plots"
    plots.mkdir()
    colors = {"early": "#d05b31", "uniform": "#807aa3", "late": "#207c99"}
    for (split, task, n, depth), block in summary.groupby(["split", "task", "n_nodes", "depth"]):
        fig, ax = plt.subplots(figsize=(7.4, 4.8))
        hybrid = block[block["alpha"].notna()]
        for profile, rows in hybrid.groupby("profile"):
            rows = rows.sort_values("alpha")
            err = rows["mse_seed_std"].fillna(0).to_numpy()
            ax.errorbar(rows["alpha"], rows["mse_mean"], yerr=err, marker="o", capsize=3,
                        label=profile, color=colors.get(profile))
        for kind, linestyle in [("pooled", "--"), ("local", ":")]:
            baseline = block[block["kind"].eq(kind)]
            for profile, row in baseline.groupby("profile"):
                ax.axhline(row["mse_mean"].mean(), linestyle=linestyle, alpha=.55,
                           color=colors.get(profile), label=f"{profile}: {kind}")
        ax.set(xlabel="Alpha (branch mixing coefficient)", ylabel="Mean squared error",
               title=f"{split}: {task} task | N={n}, depth={depth}")
        ax.text(.01, -.23, "Points: graph-averaged MSE, then seed mean. Bars: training-seed SD; not confidence intervals.",
                transform=ax.transAxes, fontsize=8)
        ax.grid(alpha=.18)
        ax.legend(fontsize=8, ncol=3)
        fig.tight_layout()
        fig.savefig(plots / f"alpha_{split}_{task}_n{n}_d{depth}.png", dpi=160, bbox_inches="tight")
        plt.close(fig)
    if not contrasts.empty:
        for (split, task, n, depth), block in contrasts.groupby(["split", "task", "n_nodes", "depth"]):
            fig, ax = plt.subplots(figsize=(7.4, 4.8))
            for idx, (reference, rows) in enumerate(block.groupby("reference")):
                rows = rows.sort_values("alpha")
                x = rows["alpha"].to_numpy() + (idx - 1) * .012
                y = rows["early_minus_late_gain"].to_numpy()
                low, high = rows["ci025"].to_numpy(), rows["ci975"].to_numpy()
                ax.plot(x, y, marker="o", label=reference)
                # Draw percentile endpoints directly; they need not bracket the
                # point estimate for very skewed finite bootstrap distributions.
                finite = np.isfinite(low) & np.isfinite(high)
                ax.vlines(x[finite], low[finite], high[finite], alpha=.6)
            ax.axhline(0, color="black", linewidth=.8)
            ax.set(xlabel="Alpha", ylabel="Early gain minus late gain (MSE)",
                   title=f"{split}: {task} | N={n}, depth={depth}")
            ax.text(.01, -.23, "Positive: hybrid improves more on early-growth trees. 95% descriptive graph-pair bootstrap intervals.",
                    transform=ax.transAxes, fontsize=8)
            ax.grid(alpha=.18)
            ax.legend(fontsize=8)
            fig.tight_layout()
            fig.savefig(plots / f"contrast_{split}_{task}_n{n}_d{depth}.png", dpi=160, bbox_inches="tight")
            plt.close(fig)


def _graph_metadata(work: Path, metrics: pd.DataFrame, out: Path):
    columns = ["graph_id", "split", "n_nodes", "depth", "profile", "replicate"]
    _write(metrics[columns].drop_duplicates().sort_values(columns), out / "evaluated_graph_metadata.csv")
    source = work / "graphs.json"
    if not source.exists():
        return 0
    payload = _json(source)
    if isinstance(payload, list):
        graphs = payload
    elif isinstance(payload, dict) and isinstance(payload.get("graphs"), list):
        graphs = payload["graphs"]
    else:
        return 0
    records = []
    for graph in graphs:
        metadata = dict(graph.get("metadata", {}), **graph)
        volume = next((metadata[k] for k in ("volume", "volumes", "volume_profile", "cumulative_volume", "V")
                       if isinstance(metadata.get(k), list)), None)
        if volume is None and "V0" in metadata:
            volume = [metadata[f"V{radius}"] for radius in range(int(metadata["depth"]) + 1)]
        if volume is None and isinstance(metadata.get("distances"), list):
            distances = np.asarray(metadata["distances"])
            volume = [int((distances <= radius).sum()) for radius in range(int(distances.max()) + 1)]
        if volume is None:
            continue
        for radius, count in enumerate(volume):
            records.append({"graph_id": str(metadata.get("graph_id", "")),
                            "split": "validation" if metadata.get("split") == "val" else metadata.get("split", ""),
                            "n_nodes": metadata.get("n_nodes", volume[-1]), "depth": metadata.get("depth", len(volume) - 1),
                            "profile": metadata.get("profile", ""), "replicate": metadata.get("replicate", ""),
                            "radius": radius, "volume": count})
    if not records:
        return 0
    frame = pd.DataFrame(records)
    _write(frame, out / "graph_volume_profiles.csv")
    for (split, n, depth), block in frame.groupby(["split", "n_nodes", "depth"]):
        fig, ax = plt.subplots(figsize=(6.5, 4.2))
        for profile, rows in block.groupby("profile"):
            mean = rows.groupby("radius")["volume"].agg(["mean", "min", "max"])
            ax.plot(mean.index, mean["mean"], marker="o", label=profile)
            ax.fill_between(mean.index, mean["min"], mean["max"], alpha=.12)
        ax.set(xlabel="Upstream radius (edges)", ylabel="Nodes within radius, including root",
               title=f"{split} | N={n}, depth={depth}")
        ax.text(.01, -.23, "Line: mean across graphs. Band: minimum to maximum, not a confidence interval.",
                transform=ax.transAxes, fontsize=8)
        ax.legend()
        fig.tight_layout()
        fig.savefig(out / "plots" / f"volume_{split}_n{n}_d{depth}.png", dpi=160, bbox_inches="tight")
        plt.close(fig)
    return len(graphs)


def _sweep_audit(work: Path, runtimes: pd.DataFrame):
    """Require all scheduled fits before freezing a validation alpha choice."""
    expected = set()
    if (work / "sweep_plan.json").exists():
        plan = _json(work / "sweep_plan.json")
        runs = plan.get("runs", []) if isinstance(plan, dict) else plan
        expected = {str(run["run_id"]) for run in runs}
    elif (work / "config.json").exists():
        experiment = _json(work / "config.json").get("experiment", {})
        alphas, seeds = experiment.get("alphas", []), experiment.get("seeds", [])
        configurations = ["hybrid_a" + format(float(a), "g").replace(".", "p") for a in alphas]
        configurations += experiment.get("baselines", ["pooled", "local"])
        expected = {f"{configuration}__s{int(seed)}" for configuration in configurations for seed in seeds}
    completed = set(runtimes["run_id"])
    if "fingerprint" in runtimes and runtimes["fingerprint"].nunique() > 1:
        raise ValueError("Completed runs have different training fingerprints; do not combine experiments")
    return {"status": "complete" if expected and expected == completed else "incomplete_or_plan_unavailable",
            "expected_runs": len(expected), "completed_runs": len(completed),
            "missing_runs": sorted(expected - completed), "unexpected_runs": sorted(completed - expected)}


def _coverage_audit(work: Path, metrics: pd.DataFrame):
    source = work / "graphs.json"
    if not source.exists():
        raise ValueError("graphs.json is required to verify completed evaluation coverage")
    graphs = _json(source)
    if isinstance(graphs, dict):
        graphs = graphs.get("graphs", [])
    expected = set()
    for graph in graphs:
        split = "validation" if graph.get("split") == "val" else graph.get("split")
        if split in {"validation", "test"}:
            expected.update((str(graph["graph_id"]), split, task) for task in ("local", "distant"))
    if not expected:
        raise ValueError("No evaluation graphs found in graphs.json")
    for (run_id, seed), rows in metrics.groupby(["run_id", "seed"]):
        found = set(map(tuple, rows[["graph_id", "split", "task"]].to_numpy()))
        if found != expected:
            raise ValueError(f"Completed {run_id}, seed {seed} has incomplete evaluation coverage: "
                             f"{len(expected - found)} missing, {len(found - expected)} unexpected graph/task rows")


def analyze(work: Path, bootstrap: int = 1000) -> Path:
    """Write a timestamped review folder and ZIP; do not modify training outputs."""
    work = Path(work).resolve()
    if bootstrap < 0:
        raise ValueError("bootstrap must be nonnegative")
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    out = work / f"analysis_{timestamp}"
    out.mkdir(parents=True, exist_ok=False)
    metrics, runtimes, provenance, skipped = _load_runs(work)
    _coverage_audit(work, metrics)
    sweep = _sweep_audit(work, runtimes)
    _save_json(out / "sweep_completion_audit.json", sweep)
    _write(metrics, out / "all_graph_metrics.csv")
    _write(runtimes, out / "run_summary.csv")
    summary, _ = _summaries(metrics, out)
    gains, audit, references = _paired_gains(metrics, out)
    contrasts, mismatches = _contrasts(gains, out, bootstrap)
    selection = _selection(metrics, gains, out, references, sweep["status"] == "complete")
    _plots(summary, contrasts, metrics, out)
    n_graphs = _graph_metadata(work, metrics, out)
    for name in ("config.json", "graphs.json", "manifest.json", "training_manifest.json", "sweep_plan.json", "dataset_status.json", "dataset_audit.json", "provenance.json", "plan.json"):
        source = work / name
        if source.exists():
            shutil.copy2(source, out / name)
    _save_json(out / "analysis_provenance.json", {"metrics": provenance, "bootstrap_seed": 20261004,
                                                 "created_utc": timestamp, "analysis_version": "1.0"})
    unmatched = int(audit[["hybrid_only", "reference_only"]].sum().sum()) if not audit.empty else 0
    missing_seeds = int(contrasts["excluded_pairs_missing_seeds"].sum()) if not contrasts.empty else 0
    status_name = "complete" if not unmatched and len(mismatches) == 0 and not missing_seeds else "pairing_warnings"
    if sweep["status"] != "complete":
        status_name = "provisional_incomplete_sweep"
    status = {"status": status_name,
              "completed_runs": len(runtimes), "seeds": sorted(int(v) for v in metrics["seed"].unique()),
              "evaluated_graphs": int(metrics[["graph_id", "split"]].drop_duplicates().shape[0]),
              "graphs_with_volume_metadata": n_graphs,
              "skipped_runs": skipped, "unmatched_baseline_rows": unmatched,
              "unmatched_growth_pairs": len(mismatches), "excluded_pairs_missing_seeds": missing_seeds,
              "validation_selection_status": selection["status"],
              "sweep_completion_status": sweep["status"],
              "bootstrap_samples": bootstrap, "independent_resampling_unit": "matched early/late graph pair, within fixed N and depth",
              "interpretation": "Controlled synthetic experiment; not independent real-river validation or proof of oversquashing"}
    _save_json(out / "analysis_status.json", status)
    (out / "READ_ME_FIRST.txt").write_text(
        "CONTROLLED TREE GROWTH EXPERIMENT\n\n"
        "Start with analysis_status.json and validation_selection.json. Inspect pairing warnings before drawing conclusions.\n"
        "The same model is trained jointly on local and distant tasks. Task-specific rows evaluate that shared model.\n"
        "stratum_summary.csv: graph-averaged MSE, then mean and standard deviation across training seeds.\n"
        "balanced_summary.csv: equal weight for each task, size, depth, and growth-profile stratum.\n"
        "paired_graph_seed_gains.csv: reference MSE minus hybrid MSE; positive means hybrid is better.\n"
        "early_late_summary.csv: early-growth gain minus late-growth gain within fixed size, depth, task, and reference.\n"
        "Positive contrast means hybrid improvement is larger on early-growth trees; it does not require either gain to be positive.\n"
        "Intervals resample matched graph pairs AFTER averaging seed-paired contrasts. Seeds are not independent graph samples.\n"
        "Bootstrap intervals are descriptive, conditional on the trained models; shared training induces dependencies.\n"
        "Small graph samples give unstable intervals. No p-values are computed and no multiplicity-adjusted discovery is claimed.\n"
        "Alpha is a branch mixing coefficient, not a measured percentage of information flow or model responsibility.\n"
        "The global alpha choice uses validation only. Per-task choices are explicitly diagnostic on jointly trained models.\n"
        "selected_test_comparison.csv compares the validation-selected alpha against both endpoints and pooling on test graphs.\n"
        "All task inputs and targets are synthetic. Tree topology, training optimization, capacity, and task accessibility remain distinct issues.\n"
        "An error difference alone cannot diagnose oversquashing. Do not select a favorable alpha, task, or graph stratum from test results.\n"
        "An exact graph-aware oracle should have MSE zero; the zero and topology-blind oracle errors are measured on the same samples.\n"
        "If runs are incomplete, treat every selection and summary as provisional and repeat analysis after the scheduled sweep completes.\n"
    )
    archive = work / f"tree_growth_review_{timestamp}.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file in sorted(out.rglob("*")):
            if file.is_file():
                zf.write(file, file.relative_to(out))
    print(f"Analysis: {out}\nReview ZIP: {archive}")
    return archive


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=1000)
    args = parser.parse_args()
    analyze(args.work, args.bootstrap)
