# Controlled tree growth and hybrid GNNs

This package tests whether changing upstream tree growth changes the relative
performance of message passing, attention, and their fixed-coefficient mixtures.
It generates its own data. It does not modify the completed river experiment.

## Start on your Ubuntu laptop

Download `tree_growth_lab.zip` to Downloads. Use the virtual environment where
your RTX 3080 already passed the PyTorch CUDA check:

```bash
cd ~/Downloads/river_hybrid_lab
source .venv/bin/activate
python -m zipfile -e ~/Downloads/tree_growth_lab.zip .
python -m pip install -r tree_growth_lab/requirements.txt
python -m tree_growth_lab check --device cuda
python -m tree_growth_lab smoke --work tree_growth_smoke --device cuda
```

The requirements deliberately omit PyTorch. Keep the working CUDA installation.
The `check` command validates targets, graph splits, permutation invariance, and
message-passing reach. The five-fit smoke run checks training and report creation;
its small width and two epochs are not research results.

Run the main experiment, with an optional short timing check first:

```bash
python -m tree_growth_lab benchmark \
  --work tree_growth_experiment --preset main --device cuda

systemd-inhibit --what=sleep:idle --mode=block \
  --why="Controlled tree GNN experiment" \
  python -u -m tree_growth_lab run \
  --work tree_growth_experiment --device cuda
```

The timing check measures the largest graph with an interior hybrid. It reports
training-step time, not a promised sweep duration. Validation and report writing
add time. The first epoch of each fit also prints a timing estimate.

Keep the laptop plugged in and its lid open. A lock screen does not stop training;
suspend does. The inhibitor is active only while its command runs, and it cannot
protect against shutdown, power loss, or every forced suspend action. If the
inhibitor command is unavailable or denied, disable automatic suspend in Ubuntu
Settings and run the Python command directly. An inhibitor does not keep a process
alive after its terminal is closed; use your existing tmux session if desired.

To resume after interruption, repeat the same `run` command. Completed fits are
skipped; interrupted fits resume from the last completed epoch. An interrupted
epoch is repeated. Checkpoints include optimizer, RNG, best model, and patience
state. Avoid launching two copies against the same work directory.

For a smaller preliminary run, use a separate directory:

```bash
python -m tree_growth_lab run \
  --work tree_growth_pilot --preset pilot --device cuda
```

The pilot has seven fits and one training seed. Its results are exploratory. If
you change the scientific protocol after inspecting pilot outcomes, use a new
graph seed and fresh work directory for confirmation; merely increasing the
training seed count does not create a new test set.

The default smoke, pilot and main presets use different graph seeds and were
checked to have no shared rooted-isomorphic trees. The main seed was chosen using
only this structural non-overlap check, without inspecting model scores.

The final console line names a `tree_growth_review_....zip` file. Upload that ZIP
for interpretation. It contains metrics, topology metadata, settings and plots,
without model checkpoints. Analysis can be rerun without training:

```bash
python -m tree_growth_lab analyze --work tree_growth_experiment
```

## What stays fixed, and what varies

The main preset contains 96 distinct rooted trees:

| Factor | Values |
| --- | --- |
| Number of nodes | 63, 127 |
| Maximum root distance | 4, 8 hops |
| Growth profile | early, uniform, late |
| Graphs in each size/depth/profile cell | 2 train, 2 validation, 4 test |
| Root's immediate upstream neighbors | exactly 4 |
| Maximum upstream children of any node | 4 |
| Spatial message-passing layers | 8 |
| Relevant marked nodes per query | 4 |
| Marked distractor nodes per query | 4 |

Every tree starts with four disjoint root-to-depth-D chains. Additional nodes
attach below the root with shallow, uniform, or deep attachment bias. Matched
early/late trees share a construction seed and have the same N and D. The generator
requires the realized two-hop volume of the early tree to exceed the late tree's.
This is conditioning on a declared structural contrast, never on model outcomes.

Node indices are permuted, including the root. Canonical rooted-tree hashes reject
isomorphic duplicates within and across train/validation/test splits. A relabeled
copy of a training tree cannot count as a new test tree.

Here V(r) counts nodes within r upstream hops, including the root. It is not water
volume. V(1) is fixed at 5. The primary contrast is V(2), within matched N,D strata.
Large-radius volumes eventually equal N and are not independent measures of growth.

## Two paired tasks on every graph

Each example assigns an independent standard-normal value to every node and marks
four nodes exactly one hop from the root and four exactly four hops from the root.
A query at the root asks for either the nearby or distant marked values:

`target = sum(the four requested values) / sqrt(4)`

Both tasks have population target mean zero and variance one. A paired local and
distant example uses the same graph, values and marks; only the root query changes.
The model sees four channels: value, marked-node flag, root flag, and root query.
There are no node-ID or node-depth features. The original attention mechanism
retains its graph distance bias, and message passing receives the original edges.

The model must use graph structure to tell which four marked values answer the
query. Increasing tree volume does not increase the number of relevant values.
This is a selective information-routing task with controlled distractors.

Exact controls are included:

- Graph-aware target oracle: MSE 0, up to floating-point precision.
- Always predict zero: population MSE 1.
- Topology-blind analytic predictor: half the normalized sum of all eight marked
  values, with population MSE 0.5. This is the conditional mean available to a
  permutation-invariant model without topology or shell membership. Finite test
  samples fluctuate around the population value.

Both source distances are inside the eight-layer message-passing receptive field.
A poor distant-task score therefore cannot be explained merely by using fewer
layers than the source distance. It still need not imply oversquashing: optimization,
expressivity, aggregation, and parameter budget can also affect performance.

## Models and training

`river_models.py` is copied unchanged from the river model source supplied in your
previous review ZIP. The message-passing, attention, residual blocks and normalization
are preserved. This experiment trains new weights; river forecasting checkpoints
are not loaded.

The input/output adapter uses one time step with four synthetic channels, no static
features, zero edge/pair attributes, and one scalar target. This changes the task
interface, while preserving the spatial architecture. Main and pilot settings use
width 64, eight layers, four heads, and dropout 0.1.

The main sweep uses seeds 42, 43 and 44 for seven configurations:

- alpha = 0: message-passing endpoint;
- alpha = 0.25, 0.5, 0.75: fixed hybrids;
- alpha = 1: attention endpoint;
- pooled: topology-blind upstream pooling control;
- local: outlet-only control.

That is 21 fits. Every fit trains jointly on balanced local and distant queries.
Scores are reported separately by task. Thus the curves describe conditional
performance of jointly trained models, not two separately optimized task-specific
architectures. Alpha is a branch coefficient, not the measured percentage of useful
attention, information, or computation.

All models see identical generated signals for a given graph and epoch; these
signals are independent of the model training seed. Signals change each training
epoch. Validation/test signals remain fixed and separate. Hybrid endpoints retain
inactive branches to preserve common initialization of the active modules. Active
and total parameter counts are reported: the configurations are not parameter-matched.

Training uses AdamW, learning rate 0.001, gradient norm clipping at 1, maximum 30
epochs, and early stopping after six epochs without validation improvement. The
best checkpoint minimizes validation MSE averaged equally across graphs and tasks.
This first study fixes the same training recipe; it is not an exhaustive tuning
comparison or a state-of-the-art claim.

## Reading the results

Positive gain means `reference MSE - hybrid MSE`. Reference models are evaluated
on the same graph, task, signals and seed. Compare against message passing,
attention, and pooling, not only the weakest endpoint.

The primary structural contrast is:

`gain on early-growth tree - gain on its matched late-growth tree`

Compute it separately for each N, D, task, alpha and baseline. A positive value
means the hybrid's relative benefit is larger in the early-growth condition.
Report all declared alphas and both tasks. Do not select whichever radius or
coefficient produces the largest test correlation.

The report separates seed variation from graph variation. Matched graph pairs are
the resampling units after seed averaging; seeds are not additional graph samples.
Four test pairs per N,D stratum are a small exploratory sample, so bootstrap
intervals are descriptive and should not be treated as precise population inference.

Any alpha choice uses validation scores only. Test-best alphas may not be used to
claim an out-of-sample selector. These experiments alone do not produce a calibrated
graph-to-alpha predictor or a mechanistic demonstration of oversquashing.

Interpret growth comparisons within fixed depth. At depth 4, the four-hop sources
are leaves; at depth 8 they may be internal. Early/late construction changes graph
shape and the distance distribution of irrelevant nodes together. It is a
controlled graph-family intervention, not proof that one scalar V(2) causes a gain.

## Locate genuinely unused real river groups

The uploaded review contains the already-inspected 32 graphs, not unused raw river
data. The package therefore includes a candidate census, rather than pretending
that an independent real-data test has already been performed.

Run this inside the existing river lab, pointing `--raw` to the location of your
extracted LamaH-CE archive:

```bash
python -m tree_growth_lab census \
  --raw river_experiment/raw \
  --seen river_experiment/processed/manifest.json \
  --out tree_fresh_river_census
```

If your raw archive was extracted elsewhere, change only `--raw`. This command
uses the installed `river_hybrid.data` reader. It reads structural attribute files,
excludes every previously inspected transfer-connected dependency group, and checks
that group definitions agree with the old manifest. It does not read discharge,
download data, fit models, or overwrite the original experiment.

The output lists structurally eligible candidates, not a qualified test set.
Training-period data availability must still be checked. First freeze the model,
alpha selection rule, task definition and metrics; then qualify new groups without
looking at their test targets. If too few fresh groups remain, the census makes
that visible instead of relabeling old outlets as independent validation.

## Reproducibility and configuration

The work directory stores the effective configuration, graph manifest, topology
hashes, source hashes, per-epoch checkpoints, seed-level scores and runtime metadata.
Changing code or configuration requires a new work directory; existing results
are preserved. GPU floating-point reductions can vary slightly across hardware or
PyTorch versions even with the same seed.

Use JSON overrides only when creating a new work directory. For example, reduce
GPU memory use by saving `small_batch.json` containing:

```json
{"training": {"batch_size": 16}}
```

Then run:

```bash
python -m tree_growth_lab run --work tree_growth_batch16 \
  --preset main --config small_batch.json --device cuda
```

To spend more computation on confirmation, predeclare a new graph seed, more
independent graph replicates, and optionally five training seeds. Keep the old
results as exploratory, and do not mix protocols in one summary.
