"""Balanced synthetic-task training with the unchanged river model.

Checkpoints are this program's own local outputs. Never replace them with files
from an untrusted source: optimizer and RNG state require torch.load with
weights_only=False. Only completed epoch boundaries are resumable.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import random
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch

from .data import blind_oracle, exact_oracle, make_examples
from .river_models import ModelConfig, RiverForecaster


TASK_NAMES = {0: "local", 1: "distant"}


def _jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(v) for v in value]
    return value


def _write_json(path: Path, values: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(_jsonable(values), indent=2, allow_nan=False) + "\n")
    os.replace(temporary, path)


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty table {path}")
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def _stable_seed(*values: Any) -> int:
    text = json.dumps(_jsonable(values), sort_keys=True, separators=(",", ":"))
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:8], "little") % (2**32)


def _split(graph: dict) -> str:
    split = str(graph["split"])
    return {"val": "validation", "valid": "validation", "dev": "validation"}.get(split, split)


def _fingerprint(cfg: dict, graphs: list[dict]) -> tuple[str, dict]:
    # Hash actual topology arrays as well as declared graph hashes. Configuring a
    # different data size, model, seed set, or code must use a new work directory.
    root = Path(__file__).parent
    code = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in ("runner.py", "data.py", "river_models.py")}
    inventory = []
    for graph in sorted(graphs, key=lambda g: str(g["graph_id"])):
        arrays = {}
        for name in ("edge_index", "ancestor_dist"):
            array = np.ascontiguousarray(graph[name], dtype=np.int64)
            arrays[name] = hashlib.sha256(array.tobytes()).hexdigest()
        inventory.append({"graph_id": str(graph["graph_id"]), "split": _split(graph),
                          "root": int(graph["root"]), "n_nodes": int(graph["n_nodes"]),
                          "depth": int(graph["depth"]), "profile": str(graph["profile"]),
                          "replicate": int(graph["replicate"]),
                          "topology_hash": str(graph["topology_hash"]), **arrays})
    description = {"config": _jsonable(cfg), "code_sha256": code, "graphs": inventory}
    digest = hashlib.sha256(json.dumps(description, sort_keys=True).encode()).hexdigest()
    return digest, description


def _prepare(work: Path, cfg: dict, graphs: list[dict]) -> str:
    ids = [str(g["graph_id"]) for g in graphs]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate graph IDs")
    splits = {_split(g) for g in graphs}
    if splits != {"train", "validation", "test"}:
        raise ValueError(f"Expected train, validation, and test graphs; got {splits}")
    if not graphs:
        raise ValueError("No graphs")
    digest, description = _fingerprint(cfg, graphs)
    work.mkdir(parents=True, exist_ok=True)
    manifest = work / "training_manifest.json"
    if manifest.exists():
        old = json.loads(manifest.read_text())
        if old.get("fingerprint") != digest:
            raise ValueError("This work directory contains different code, config, or graphs. "
                             "Use a new --work directory; previous runs are preserved.")
    else:
        if any((work / "runs").glob("*/checkpoint.pt")) or any((work / "runs").glob("*/result.json")):
            raise ValueError("Existing runs have no training manifest. Use a new work directory.")
        _write_json(manifest, {"fingerprint": digest, **description})
    return digest


def _device(request: str) -> torch.device:
    if request == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(request)
    if device.type not in {"cpu", "cuda"}:
        raise ValueError("Supported devices: auto, cpu, cuda, or cuda:<index>")
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable. Check torch.cuda.is_available().")
    if device.type == "cuda":
        torch.empty(1, device=device)  # Validate a requested index before doing any work.
    return device


def _sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _seed_model(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if torch.backends.cudnn.is_available():
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True


def _model(cfg: dict, kind: str, alpha: float, seed: int, device: torch.device) -> RiverForecaster:
    _seed_model(seed)
    values = dict(cfg["model"])
    values.update(dynamic_dim=4, static_dim=0, edge_dim=2, horizons=(1,),
                  kind=kind, alpha=alpha)
    return RiverForecaster(ModelConfig(**values)).to(device)


def _graph_tensors(graph: dict, device: torch.device) -> dict:
    nodes = int(graph["n_nodes"])
    edges = torch.as_tensor(np.asarray(graph["edge_index"]), dtype=torch.long, device=device)
    return {"static": torch.empty(nodes, 0, device=device), "edge_index": edges,
            "edge_attr": torch.zeros(edges.shape[1], 2, device=device),
            "ancestor_dist": torch.as_tensor(np.asarray(graph["ancestor_dist"]), dtype=torch.long, device=device),
            "outlet_index": int(graph["root"]),
            "pair_attr": torch.zeros(nodes, nodes, 2, device=device)}


def _examples(cfg: dict, graph: dict, pairs: int, purpose: str, epoch: int = 0) -> dict:
    # The seed intentionally omits architecture and training seed. Every model
    # sees identical signals on a given graph/epoch, including validation/test.
    seed = _stable_seed(cfg["data"].get("graph_seed", 12345), "signals", purpose,
                        str(graph["graph_id"]), epoch)
    result = make_examples(graph, n_pairs=pairs, seed=seed, k=int(cfg["data"].get("source_count", 4)))
    if len(result["target"]) != 2 * pairs:
        raise ValueError("make_examples must return equal paired local/distant examples")
    tasks = np.asarray(result["task"])
    if not np.array_equal(tasks, np.tile(np.asarray([0, 1]), pairs)):
        raise ValueError("Expected alternating paired local/distant tasks")
    return result


def _balanced_batches(count: int, batch_size: int, rng: np.random.Generator) -> list[np.ndarray]:
    # Shuffle pairs together. A full batch always contains equal task counts;
    # an even batch size also keeps the last batch balanced.
    if batch_size < 2 or batch_size % 2:
        raise ValueError("batch_size must be a positive even number")
    pairs = rng.permutation(count // 2)
    indices = np.column_stack((2 * pairs, 2 * pairs + 1)).reshape(-1)
    return [indices[i:i + batch_size] for i in range(0, count, batch_size)]


def _train_epoch(model: RiverForecaster, optimizer: torch.optim.Optimizer, cfg: dict,
                 graphs: list[dict], tensors: dict, device: torch.device, epoch: int) -> float:
    model.train()
    options = cfg["training"]
    # Data RNG is independent of model/dropout RNG and identical across settings.
    rng = np.random.default_rng(_stable_seed(cfg["data"].get("graph_seed", 12345), "order", epoch))
    examples = {str(g["graph_id"]): _examples(cfg, g, int(options["train_pairs"]), "train", epoch)
                for g in graphs}
    schedule = []
    for graph in graphs:
        gid = str(graph["graph_id"])
        schedule.extend((gid, indices) for indices in _balanced_batches(
            len(examples[gid]["target"]), int(options["batch_size"]), rng))
    rng.shuffle(schedule)
    squared_error, count = 0.0, 0
    for gid, indices in schedule:
        sample = examples[gid]
        dynamic = torch.as_tensor(sample["dynamic"][indices], dtype=torch.float32, device=device)
        target = torch.as_tensor(sample["target"][indices], dtype=torch.float32, device=device)
        optimizer.zero_grad(set_to_none=True)
        prediction = model(dynamic, **tensors[gid])
        loss = (prediction - target).square().mean()
        if not bool(torch.isfinite(loss)):
            raise FloatingPointError("Non-finite training loss; previous epoch checkpoint is preserved")
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        squared_error += float(loss.detach()) * len(indices)
        count += len(indices)
    return squared_error / count


def _evaluate(model: RiverForecaster, cfg: dict, graphs: list[dict], tensors: dict,
              device: torch.device, seed: int, configuration: str, kind: str,
              alpha: float | None, include_oracles: bool = True) -> list[dict]:
    model.eval()
    rows = []
    with torch.no_grad():
        for graph in graphs:
            split, gid = _split(graph), str(graph["graph_id"])
            pairs = int(cfg["training"]["test_pairs" if split == "test" else "val_pairs"])
            sample = _examples(cfg, graph, pairs, split)
            predictions = []
            for start in range(0, len(sample["target"]), int(cfg["training"]["batch_size"])):
                dynamic = torch.as_tensor(sample["dynamic"][start:start + int(cfg["training"]["batch_size"])],
                                          dtype=torch.float32, device=device)
                predictions.append(model(dynamic, **tensors[gid]).cpu().numpy())
            prediction = np.concatenate(predictions)
            target = np.asarray(sample["target"], dtype=np.float64)
            if not np.isfinite(prediction).all():
                raise FloatingPointError("Non-finite evaluation prediction")
            k = int(cfg["data"].get("source_count", 4))
            if include_oracles:
                oracle = np.asarray(exact_oracle(graph, sample["dynamic"], k=k), dtype=np.float64)
                blind = np.asarray(blind_oracle(sample["dynamic"], k=k), dtype=np.float64)
                if oracle.shape != target.shape or blind.shape != target.shape:
                    raise ValueError("Oracle predictions must match target shape")
            for task in (0, 1):
                mask = np.asarray(sample["task"]) == task
                row = {"seed": seed, "configuration": configuration, "alpha": alpha,
                       "kind": kind, "graph_id": gid, "split": split, "task": TASK_NAMES[task],
                       "n_nodes": int(graph["n_nodes"]), "depth": int(graph["depth"]),
                       "profile": str(graph["profile"]), "replicate": int(graph["replicate"]),
                       "pairing_id": str(graph.get("pairing_id", "")),
                       "topology_hash": str(graph["topology_hash"]),
                       "V2": int(graph.get("V2", np.sum(np.asarray(graph["ancestor_dist"])[int(graph["root"])] <= 2))),
                       "mse": float(np.mean((prediction[mask] - target[mask])**2)),
                       "n_examples": int(mask.sum()), "zero_mse": float(np.mean(target[mask]**2))}
                if include_oracles:
                    row.update(blind_oracle_mse=float(np.mean((blind[mask] - target[mask])**2)),
                               oracle_mse=float(np.mean((oracle[mask] - target[mask])**2)))
                rows.append(row)
    return rows


def _cpu_state(model: RiverForecaster) -> dict:
    # clone is essential: state_dict tensors otherwise alias live CPU weights.
    return {name: tensor.detach().cpu().clone() for name, tensor in model.state_dict().items()}


def _rng_state() -> dict:
    return {"python": random.getstate(), "numpy": np.random.get_state(),
            "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}


def _restore_rng(state: dict) -> None:
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if state.get("cuda") is not None and torch.cuda.is_available():
        available = torch.cuda.device_count()
        for index, value in enumerate(state["cuda"][:available]):
            torch.cuda.set_rng_state(value, index)


def _checkpoint(path: Path, state: dict) -> None:
    temporary = path.with_suffix(".pt.tmp")
    torch.save(state, temporary)
    os.replace(temporary, path)


def _plan(cfg: dict) -> list[dict]:
    settings = []
    alphas = [float(value) for value in cfg["experiment"]["alphas"]]
    if len(alphas) != len(set(alphas)) or any(a < 0 or a > 1 for a in alphas):
        raise ValueError("alphas must be unique values in [0,1]")
    seeds = [int(seed) for seed in cfg["experiment"]["seeds"]]
    if len(seeds) != len(set(seeds)):
        raise ValueError("Training seeds must be unique")
    baselines = list(cfg["experiment"].get("baselines", ["pooled", "local"]))
    if len(baselines) != len(set(baselines)) or set(baselines) - {"pooled", "local"}:
        raise ValueError("baselines must be unique choices from pooled/local")
    for alpha in alphas:
        name = "hybrid_a" + format(alpha, "g").replace(".", "p")
        settings.append({"configuration": name, "kind": "hybrid", "alpha": alpha})
    settings.extend({"configuration": kind, "kind": kind, "alpha": None} for kind in baselines)
    return [{**setting, "seed": seed,
             "run_id": f"{setting['configuration']}__s{seed}"}
            for setting in settings for seed in seeds]


def _run_one(work: Path, cfg: dict, graphs: list[dict], tensors: dict,
             device: torch.device, run: dict, fingerprint: str) -> None:
    directory = work / "runs" / run["run_id"]
    directory.mkdir(parents=True, exist_ok=True)
    completed = directory / "result.json"
    if completed.exists():
        result = json.loads(completed.read_text())
        if result.get("fingerprint") != fingerprint or result.get("status") != "complete":
            raise ValueError(f"Invalid completed marker in {directory}")
        if not (directory / "metrics.csv").exists():
            raise ValueError(f"Missing metrics for completed run {directory}")
        print(f"Skipping completed {run['run_id']}", flush=True)
        return
    options = cfg["training"]
    model = _model(cfg, run["kind"], run["alpha"] or 0.0, int(run["seed"]), device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(options["learning_rate"]),
                                 weight_decay=float(options["weight_decay"]))
    checkpoint = directory / "checkpoint.pt"
    history: list[dict] = []
    best_state = None
    best_value, best_epoch, stale, last_epoch, elapsed_before = math.inf, 0, 0, 0, 0.0
    if checkpoint.exists():
        state = torch.load(checkpoint, map_location="cpu", weights_only=False)
        if state.get("fingerprint") != fingerprint or state.get("run") != run:
            raise ValueError(f"Checkpoint fingerprint/run mismatch in {directory}")
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        # Explicit migration also supports resuming a CUDA run on CPU or vice versa.
        for optimizer_state in optimizer.state.values():
            for key, value in optimizer_state.items():
                if torch.is_tensor(value) and key != "step":
                    optimizer_state[key] = value.to(device)
        best_state, best_value = state["best_state"], float(state["best_value"])
        best_epoch, stale, last_epoch = int(state["best_epoch"]), int(state["stale"]), int(state["epoch"])
        history, elapsed_before = state["history"], float(state["elapsed_seconds"])
        _restore_rng(state["rng"])
        print(f"Resuming {run['run_id']} after epoch {last_epoch}", flush=True)
    else:
        print(f"Running {run['run_id']} on {device}", flush=True)
    train = [g for g in graphs if _split(g) == "train"]
    validation = [g for g in graphs if _split(g) == "validation"]
    test = [g for g in graphs if _split(g) == "test"]
    _sync(device)
    start_time = time.perf_counter()
    epochs = int(options["epochs"])
    patience = int(options["patience"])
    if epochs < 1 or patience < 1:
        raise ValueError("epochs and patience must be positive")
    for epoch in range(last_epoch + 1, epochs + 1):
        if stale >= patience:
            break
        _sync(device)
        epoch_start = time.perf_counter()
        training_mse = _train_epoch(model, optimizer, cfg, train, tensors, device, epoch)
        val_rows = _evaluate(model, cfg, validation, tensors, device, int(run["seed"]),
                             run["configuration"], run["kind"], run["alpha"], include_oracles=False)
        val_mse = float(np.mean([row["mse"] for row in val_rows]))
        if val_mse < best_value:
            best_state, best_value, best_epoch, stale = _cpu_state(model), val_mse, epoch, 0
        else:
            stale += 1
        _sync(device)
        seconds = time.perf_counter() - epoch_start
        history.append({"epoch": epoch, "train_mse": training_mse,
                        "validation_mse": val_mse, "seconds": seconds,
                        "best_epoch": best_epoch, "epochs_without_improvement": stale})
        checkpoint_state = {"fingerprint": fingerprint, "run": run, "epoch": epoch,
                            "model": _cpu_state(model), "optimizer": optimizer.state_dict(),
                            "best_state": best_state, "best_value": best_value,
                            "best_epoch": best_epoch, "stale": stale, "history": history,
                            "rng": _rng_state(), "elapsed_seconds": elapsed_before + time.perf_counter() - start_time}
        _checkpoint(checkpoint, checkpoint_state)
        _write_csv(directory / "training_history.csv", history)
        print(f"[{run['run_id']}] epoch {epoch}/{epochs} train_mse={training_mse:.6f} "
              f"validation_mse={val_mse:.6f} seconds={seconds:.1f} best_epoch={best_epoch}", flush=True)
        if epoch == 1:
            print(f"  At this first-epoch rate, this fit has at most approximately "
                  f"{seconds * (epochs - 1) / 60:.1f} training/validation minutes left; "
                  "early stopping may shorten it. Final evaluation adds time.", flush=True)
    if best_state is None:
        raise RuntimeError("No valid checkpoint was produced")
    model.load_state_dict(best_state)
    rows = _evaluate(model, cfg, validation + test, tensors, device, int(run["seed"]),
                     run["configuration"], run["kind"], run["alpha"])
    _write_csv(directory / "metrics.csv", rows)
    _sync(device)
    seconds = elapsed_before + time.perf_counter() - start_time
    # Only publish the completion marker after every result is safely on disk.
    _write_json(completed, {"status": "complete", "fingerprint": fingerprint, **run,
                           "best_epoch": best_epoch, "best_validation_mse": best_value,
                           "epochs_completed": len(history), "seconds": seconds,
                           "device": str(device), "torch_version": torch.__version__,
                           "parameter_counts": model.parameter_counts(),
                           "active_params": model.parameter_counts()["active"],
                           "test_selection": "none; test evaluated only after validation checkpoint selection"})
    print(f"[{run['run_id']}] Complete: {len(history)} epochs, {seconds / 60:.1f} minutes.", flush=True)


def run_sweep(work: Path, cfg: dict, graphs: list[dict], *, device: str = "auto",
              max_runs: int | None = None) -> None:
    """Run or resume fixed model comparisons; no alpha selection uses test data."""
    work = Path(work)
    fingerprint = _prepare(work, cfg, graphs)
    torch.set_num_threads(int(cfg["training"].get("threads", 2)))
    selected_device = _device(device)
    batch_size = int(cfg["training"]["batch_size"])
    if batch_size < 2 or batch_size % 2:
        raise ValueError("batch_size must be even and at least 2")
    if any(int(cfg["training"][key]) < 1 for key in ("train_pairs", "val_pairs", "test_pairs")):
        raise ValueError("Example pair counts must be positive")
    plan = _plan(cfg)
    _write_json(work / "sweep_plan.json", {"fingerprint": fingerprint, "runs": plan,
                                         "joint_tasks": ["local", "distant"]})
    tensors = {str(g["graph_id"]): _graph_tensors(g, selected_device) for g in graphs}
    print(f"Plan: {len(plan)} fits, each jointly trained on balanced local and distant tasks. "
          f"Device: {selected_device}.", flush=True)
    finished = 0
    try:
        for run in plan:
            already_done = (work / "runs" / run["run_id"] / "result.json").exists()
            if max_runs is not None and finished >= max_runs and not already_done:
                print("Reached --max-runs; repeat the same command to continue.", flush=True)
                break
            _run_one(work, cfg, graphs, tensors, selected_device, run, fingerprint)
            if not already_done:
                finished += 1
    except KeyboardInterrupt:
        print("\nStopped. Completed epochs/runs are saved. Repeat the same command to resume; "
              "the interrupted epoch will run again.", flush=True)
        raise
    except torch.cuda.OutOfMemoryError:
        print("CUDA memory exhausted. Results and epoch checkpoints are preserved. "
              "Use a smaller batch_size with a NEW work directory (config fingerprint changes).", flush=True)
        raise


def benchmark(work: Path, cfg: dict, graphs: list[dict], device: str = "auto") -> dict:
    """Measure the unchanged interior hybrid on the largest training graph."""
    selected_device = _device(device)
    torch.set_num_threads(int(cfg["training"].get("threads", 2)))
    graph = max((g for g in graphs if _split(g) == "train"), key=lambda g: int(g["n_nodes"]))
    batch_size = int(cfg["training"]["batch_size"])
    if batch_size < 2 or batch_size % 2:
        raise ValueError("batch_size must be even and at least 2")
    model = _model(cfg, "hybrid", 0.5, int(cfg["experiment"]["seeds"][0]), selected_device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(cfg["training"]["learning_rate"]),
                                 weight_decay=float(cfg["training"]["weight_decay"]))
    sample = _examples(cfg, graph, batch_size // 2, "benchmark")
    dynamic = torch.as_tensor(sample["dynamic"], dtype=torch.float32, device=selected_device)
    target = torch.as_tensor(sample["target"], dtype=torch.float32, device=selected_device)
    tensors = _graph_tensors(graph, selected_device)
    times = []
    model.train()
    for iteration in range(4):
        _sync(selected_device)
        begin = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        loss = (model(dynamic, **tensors) - target).square().mean()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        _sync(selected_device)
        if iteration >= 2:
            times.append(time.perf_counter() - begin)
    seconds = float(np.mean(times))
    train_graphs = sum(_split(g) == "train" for g in graphs)
    steps = train_graphs * math.ceil(2 * int(cfg["training"]["train_pairs"]) / batch_size)
    report = {"device": str(selected_device), "torch_version": torch.__version__,
              "graph_id": str(graph["graph_id"]), "n_nodes": int(graph["n_nodes"]),
              "batch_size": batch_size, "warmup_steps": 2, "timed_steps": 2,
              "seconds_per_training_step": seconds,
              "training_steps_per_epoch": steps,
              "largest_graph_rate_train_minutes_per_epoch": seconds * steps / 60,
              "note": "A size-based planning estimate, not a runtime guarantee. Excludes validation, "
                      "data generation, checkpointing, and final evaluation. Endpoint models use "
                      "one branch; early stopping and thermal throttling change total runtime."}
    Path(work).mkdir(parents=True, exist_ok=True)
    _write_json(Path(work) / "benchmark.json", report)
    print(json.dumps(report, indent=2), flush=True)
    return report
