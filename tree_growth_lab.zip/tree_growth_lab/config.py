"""Declared experimental settings. A work directory keeps an immutable copy."""
from copy import deepcopy


MAIN = {
    "format_version": 1,
    "preset": "main",
    "data": {
        "sizes": [63, 127], "depths": [4, 8],
        "profiles": ["early", "uniform", "late"],
        "graphs_per_split": {"train": 2, "val": 2, "test": 4},
        "graph_seed": 20261015, "source_count": 4,
    },
    "model": {"hidden_dim": 64, "layers": 8, "heads": 4, "dropout": 0.1},
    "training": {
        "epochs": 30, "patience": 6, "batch_size": 32,
        "learning_rate": 0.001, "weight_decay": 0.0001,
        "train_pairs": 128, "val_pairs": 128, "test_pairs": 256,
        "threads": 2, "device": "auto",
    },
    "experiment": {
        "alphas": [0.0, 0.25, 0.5, 0.75, 1.0],
        "seeds": [42, 43, 44], "baselines": ["pooled", "local"],
        "bootstrap_samples": 1000,
    },
}


def preset_config(name="main"):
    cfg = deepcopy(MAIN)
    cfg["preset"] = name
    if name == "pilot":
        cfg["data"].update(sizes=[63], graph_seed=20261003,
                           graphs_per_split={"train": 1, "val": 1, "test": 2})
        cfg["training"].update(epochs=12, patience=4, train_pairs=64, val_pairs=64, test_pairs=128)
        cfg["experiment"].update(seeds=[42], bootstrap_samples=500)
    elif name == "smoke":
        cfg["data"].update(sizes=[63], depths=[4], profiles=["early", "late"], graph_seed=20261002,
                           graphs_per_split={"train": 1, "val": 1, "test": 2})
        cfg["model"].update(hidden_dim=16, heads=2, dropout=0.0)
        cfg["training"].update(epochs=2, patience=2, train_pairs=8, val_pairs=8,
                              test_pairs=16, batch_size=8)
        cfg["experiment"].update(alphas=[0.0, 0.5, 1.0], seeds=[42], bootstrap_samples=100)
    elif name != "main":
        raise ValueError(f"Unknown preset: {name}")
    return cfg


def merge_config(base, extra):
    for key, value in extra.items():
        if key not in base:
            raise ValueError(f"Unknown configuration key: {key}")
        if isinstance(value, dict) and isinstance(base[key], dict):
            merge_config(base[key], value)
        else:
            base[key] = value
    return base


def validate_config(cfg):
    d, m, t, e = (cfg[k] for k in ("data", "model", "training", "experiment"))
    if cfg["format_version"] != 1:
        raise ValueError("Unsupported configuration format")
    if d["source_count"] != 4:
        raise ValueError("This protocol fixes four sources per shell")
    if not d["sizes"] or not d["depths"] or min(d["depths"]) < 4 or max(d["depths"]) > 8:
        raise ValueError("Use graph depths 4 through 8 for this protocol")
    if any(n < 1 + 4 * depth for n in d["sizes"] for depth in d["depths"]):
        raise ValueError("Each size must hold four full root-to-leaf chains")
    if not {"early", "late"}.issubset(d["profiles"]):
        raise ValueError("Both early and late profiles are required")
    if set(d["graphs_per_split"]) != {"train", "val", "test"} or min(d["graphs_per_split"].values()) < 1:
        raise ValueError("Train, validation, and test graph counts must be positive")
    if m["layers"] < max(d["depths"]):
        raise ValueError("Message-passing layers must cover all graph depths; do not confound reach with compression")
    if m["hidden_dim"] % m["heads"]:
        raise ValueError("Hidden width must divide evenly across attention heads")
    if any(t[k] < 1 for k in ("epochs", "patience", "batch_size", "train_pairs", "val_pairs", "test_pairs", "threads")):
        raise ValueError("Training counts must be positive")
    if t["batch_size"] < 2 or t["batch_size"] % 2:
        raise ValueError("Use an even batch size of at least 2 to keep paired tasks balanced")
    if not {0.0, 1.0}.issubset(e["alphas"]) or any(not 0 <= a <= 1 for a in e["alphas"]):
        raise ValueError("Include both alpha endpoints; all coefficients must lie in [0,1]")
    if len(e["seeds"]) != len(set(e["seeds"])) or not e["seeds"]:
        raise ValueError("Training seeds must be nonempty and unique")
    if set(e["baselines"]) != {"pooled", "local"}:
        raise ValueError("This protocol requires pooled and local controls")
