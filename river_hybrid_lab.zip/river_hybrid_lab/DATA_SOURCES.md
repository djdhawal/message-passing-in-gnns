# Data sources and attribution

## LamaH-CE release used by this package

- Dataset: **LamaH-CE: Large-Sample Data for Hydrology and Environmental Sciences for Central Europe**, original v1.0 release.
- Official record and attribution: https://zenodo.org/records/5153305
- DOI: https://doi.org/10.5281/zenodo.5153305
- Daily archive: https://zenodo.org/records/5153305/files/2_LamaH-CE_daily.tar.gz
- Archive filename: `2_LamaH-CE_daily.tar.gz`
- Published MD5: `69fd2733e969513403f923ecc5eaa3dc`
- Approximate size: 1.5 GB downloaded; 5 GB extracted. Experiment outputs require additional space.
- Source license reported by this release: **Creative Commons Attribution-ShareAlike 4.0 International**. Consult the linked record and included source documentation when redistributing data or derivatives; cite the dataset and paper in research outputs.
- Paper: Klingler, C., Schulz, K., and Herrnegger, M. (2021), *LamaH-CE: LArge-SaMple DAta for Hydrology and Environmental Sciences for Central Europe*, Earth System Science Data, 13, 4529–4565. https://doi.org/10.5194/essd-13-4529-2021
- Paper and appendices: https://essd.copernicus.org/articles/13/4529/2021/

This package targets the original daily release. It does not silently substitute Extended LamaH-CE, LamaH-Ice, or a differently processed third-party copy. The downloader verifies the expected archive checksum on every call and does not treat a partial download as complete. Extraction rejects links and unsafe paths. The code bundle itself contains no real LamaH observations.

## Fields used

The reader uses semicolon-separated source CSVs and explicit schema checks. Run `python -m river_hybrid audit --raw data/raw --output data/audit.json` to inspect the actual downloaded fields before preparation.

| Source path relative to extracted root | Fields and purpose |
|---|---|
| `B_basins_intermediate_all/1_attributes/Gauge_hierarchy.csv` | `ID`, `NEXTDOWNID`: direct gauge-to-gauge downstream topology |
| `B_basins_intermediate_all/1_attributes/Stream_dist.csv` | `ID`, `NEXTDOWNID`, `dist_hdn`, `strm_slope`: edge topology, river distance in km, stream slope in m/km |
| `B_basins_intermediate_all/1_attributes/Catchment_attributes.csv` | `ID`, `area_calc`, `elev_mean`, `slope_mean`: intermediate catchment area and physical attributes |
| `B_basins_intermediate_all/2_timeseries/daily/ID_<gauge>.csv` | `YYYY`, `MM`, `DD`, `prec`, `2m_temp_mean`: daily precipitation and mean 2 m air temperature |
| `D_gauges/2_timeseries/daily/ID_<gauge>.csv` | `YYYY`, `MM`, `DD`, `qobs`, `ckhs`, and available warning flags: observed discharge and quality control |
| `D_gauges/1_attributes/Gauge_attributes.csv` | Gauge metadata, including `degimpact` when available; used for audit/sensitivity metadata rather than the default model inputs |
| `B_basins_intermediate_all/1_attributes/Crossbasin_water_transfers.csv` | Documented transfer endpoints and cross-parent links, when the table is present |

Weather is associated with **intermediate catchments B**, not accumulated upstream catchments A. Upstream rainfall must therefore be communicated or pooled by the models. The graph represents gauge connectivity; each source row is not a complete hydraulic simulation of its corresponding reach.

The precipitation and temperature inputs retain their source units until fitted normalization; consult the source appendices for the release's variable definitions. Discharge `qobs` is in m³/s and drainage area is in km². The conversion to specific discharge is `qobs * 86.4 / upstream_area`, in mm/day. Direct edge attributes and their upstream path aggregates are scaled using development-graph edges only.

The `-999` source sentinel is treated as missing. Default discharge quality requires checked (`ckhs=1`), nonnegative, finite values; statistical warning flags are retained and counted. The source timestamp denotes the start of the UTC day: a daily forecast in this experiment is issued after that day's measurements are complete. It is a retrospective evaluation, not a claim that reanalysis/weather products and all gauge measurements would have been operationally available without delay.

The audit and preparation manifest preserve source identity, units, observed columns, graph selection, missingness rules, transfer information, and regulation indicators. The source network may contain hydraulic dependencies beyond the simplified gauge tree. Physical independence is not assumed merely because selected graphs contain disjoint gauges.

## Architecture reference

The experiment follows the general idea of combining local message passing with global attention. It adds an explicit fixed alpha sweep, river-direction masks, and a temporal encoder; it is not an exact reproduction of the following reference:

- Rampášek et al. (2022), *Recipe for a General, Powerful, Scalable Graph Transformer* (GraphGPS): https://arxiv.org/abs/2205.12454
- Official GraphGPS implementation: https://github.com/rampasek/GraphGPS

## Attribution in your report

Cite the LamaH-CE dataset DOI and ESSD article, describe the intermediate-catchment delineation, date split, quality policy, spatial grouping, selected gauges, and transformations. Report the prepared manifest and resolved environment with results. Label artificial demo outputs as synthetic workflow checks, separately from any LamaH-CE experimental results.
