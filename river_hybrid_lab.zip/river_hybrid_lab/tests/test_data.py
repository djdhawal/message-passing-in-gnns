"""Data integrity checks that require neither real data nor a GPU."""
import io
import json
import tarfile

import numpy as np
import pandas as pd
import pytest

from river_hybrid.data import BASIN, _choose_holdout, create_fixture, flow_validity, prepare_dataset, safe_extract


SMALL_CONFIG = dict(train_start="2000-01-01", train_end="2000-03-31",
                    val_start="2000-04-01", val_end="2000-04-30",
                    test_start="2000-05-01", test_end="2000-06-30",
                    min_train_flow_days=30, history=7)


@pytest.fixture
def prepared(tmp_path):
    raw = create_fixture(tmp_path / "raw")
    out = tmp_path / "processed"
    manifest = prepare_dataset(raw, out, SMALL_CONFIG)
    return raw, out, manifest


def test_complete_disjoint_trees_and_routing(prepared):
    _, out, manifest = prepared
    seen, partition_parents = set(), {}
    for graph in manifest["graphs"]:
        arrays = np.load(out / graph["file"], allow_pickle=False)
        ids = set(arrays["node_ids"].tolist())
        assert seen.isdisjoint(ids)
        seen |= ids
        parent = graph["basin_id"]
        assert partition_parents.setdefault(parent, graph["spatial_split"]) == graph["spatial_split"]
        distance, edges = arrays["ancestor_dist"], arrays["edge_index"]
        root = int(arrays["outlet_index"])
        assert (distance[root] >= 0).all()
        assert len(ids) - 1 == edges.shape[1]
        assert (distance[edges[1], edges[0]] == 1).all()
        assert (distance[edges[0], edges[1]] == -1).all()
        assert np.allclose(arrays["pair_attr"][edges[1], edges[0]], arrays["edge_attr"])
        assert np.allclose(arrays["edge_attr"] * np.asarray(manifest["edge_scaler"]["scale"]), arrays["edge_attr_raw"])
        assert np.allclose(arrays["pair_attr"] * np.asarray(manifest["edge_scaler"]["scale"]), arrays["pair_attr_raw"])
        assert float(arrays["upstream_area"][root]) == pytest.approx(graph["drainage_area_km2"])
        assert graph["depth"] == distance[root].max()
        assert np.isfinite(arrays["weather"]).all()
        assert np.isfinite(arrays["flow"]).all()
        assert not arrays["flow_mask"].all()  # fixture includes a gap and unchecked value
    assert manifest["synthetic_fixture"] is True
    assert set(partition_parents.values()) == {"development", "heldout"}


def test_normalization_does_not_fit_future_or_heldout_values(prepared, tmp_path):
    raw, out, before = prepared
    heldout_nodes = set()
    for graph in before["graphs"]:
        if graph["spatial_split"] == "heldout":
            heldout_nodes.update(np.load(out / graph["file"])["node_ids"].tolist())
    for path in (raw / "D_gauges/2_timeseries/daily").glob("ID_*.csv"):
        node = int(path.stem[3:])
        frame = pd.read_csv(path, sep=";")
        altered = (frame.MM >= 4) | (node in heldout_nodes)
        altered &= frame.qobs >= 0
        frame.loc[altered, "qobs"] *= 100
        frame.to_csv(path, sep=";", index=False)
    for path in (raw / BASIN / "2_timeseries/daily").glob("ID_*.csv"):
        node = int(path.stem[3:])
        frame = pd.read_csv(path, sep=";")
        altered = (frame.MM >= 4) | (node in heldout_nodes)
        frame.loc[altered, ["prec", "2m_temp_mean"]] += 1000
        frame.to_csv(path, sep=";", index=False)
    stream_path = raw / BASIN / "1_attributes/Stream_dist.csv"
    streams = pd.read_csv(stream_path, sep=";")
    select = streams.ID.isin(heldout_nodes) & (streams.NEXTDOWNID != 0)
    streams.loc[select, ["dist_hdn", "strm_slope"]] *= 20
    streams.to_csv(stream_path, sep=";", index=False)
    catchment_path = raw / BASIN / "1_attributes/Catchment_attributes.csv"
    catchments = pd.read_csv(catchment_path, sep=";")
    catchments.loc[catchments.ID.isin(heldout_nodes), ["area_calc", "elev_mean", "slope_mean"]] *= 10
    catchments.to_csv(catchment_path, sep=";", index=False)
    after = prepare_dataset(raw, tmp_path / "changed", SMALL_CONFIG)
    for key in ("target_scaler", "weather_scaler", "static_scaler", "edge_scaler"):
        assert before[key] == after[key]
    assert [(g["graph_id"], g["spatial_split"]) for g in before["graphs"]] == [(g["graph_id"], g["spatial_split"]) for g in after["graphs"]]


def test_qc_semantics_preserve_extremes_unless_strict():
    frame = pd.DataFrame({"qobs": [0, np.nan, -1, 2, 100], "ckhs": [1, 1, 1, 0, 1], "qceq": [0] * 5, "qcol": [0, 0, 0, 0, 1]})
    assert flow_validity(frame, "checked").tolist() == [True, False, False, False, True]
    assert flow_validity(frame, "strict").tolist() == [True, False, False, False, False]


def test_safe_extraction_rejects_escape_and_links(tmp_path):
    for name, kind in [("../outside.txt", tarfile.REGTYPE), ("link", tarfile.SYMTYPE)]:
        archive = tmp_path / "bad.tar"
        with tarfile.open(archive, "w") as handle:
            info = tarfile.TarInfo(name)
            info.type = kind
            info.size = 1 if kind == tarfile.REGTYPE else 0
            info.linkname = "/outside"
            handle.addfile(info, io.BytesIO(b"x") if info.size else None)
        with pytest.raises(ValueError):
            safe_extract(archive, tmp_path / "extracted")
    assert not (tmp_path / "outside.txt").exists()


def test_fullrecord_flow_attributes_rejected(tmp_path):
    raw = create_fixture(tmp_path / "raw")
    with pytest.raises(ValueError, match="PHYSICAL_ALLOWLIST"):
        prepare_dataset(raw, tmp_path / "out", {**SMALL_CONFIG, "static_columns": ["q_mean"]})


def test_impact_filter_rejects_whole_upstream_tree(tmp_path):
    raw = create_fixture(tmp_path / "raw")
    path = raw / "D_gauges/1_attributes/Gauge_attributes.csv"
    gauges = pd.read_csv(path, sep=";")
    # 104 is an upstream leaf, while the outlet 100 remains low-impact.
    gauges.loc[gauges.ID == 104, "degimpact"] = "s"
    gauges.to_csv(path, sep=";", index=False)
    manifest = prepare_dataset(raw, tmp_path / "out", {**SMALL_CONFIG, "excluded_impact_classes": ["s"]})
    assert "100" not in {g["graph_id"] for g in manifest["graphs"]}
    assert "complete upstream tree rejected" in manifest["rejected_outlets"]["100"]
    assert all(g["strong_impact_fraction"] == 0 for g in manifest["graphs"])


def test_transfer_connected_parent_rivers_stay_in_same_split(tmp_path):
    raw = create_fixture(tmp_path / "raw")
    pd.DataFrame({"ID": [104, 204], "To_ID": [203, 303]}).to_csv(
        raw / BASIN / "1_attributes/Crossbasin_water_transfers.csv", sep=";", index=False)
    manifest = prepare_dataset(raw, tmp_path / "out", SMALL_CONFIG)
    graphs = {g["graph_id"]: g for g in manifest["graphs"]}
    assert {graphs[g]["basin_id"] for g in ["100", "200", "300"]} == {"100"}
    assert len({graphs[g]["spatial_split"] for g in ["100", "200", "300"]}) == 1
    assert {graphs[g]["terminal_basin_id"] for g in ["100", "200", "300"]} == {"100", "200", "300"}


def test_group_split_avoids_dominant_group_and_preserves_support():
    graphs = [{"basin_id": "big"}] * 25
    graphs += [{"basin_id": str(i)} for i in range(6)] + [{"basin_id": "0"}]
    held = _choose_holdout(graphs, 0.2, 42)
    assert "big" not in held
    assert 2 <= len(held) <= 4
    assert sum(g["basin_id"] in held for g in graphs) == 5
