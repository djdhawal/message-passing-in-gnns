"""Meaningful architecture invariants; run with python -m unittest discover -s tests."""
import unittest
from unittest.mock import patch

import torch

from river_hybrid.models import ModelConfig, RiverForecaster, UpstreamAttention, build_model


class RiverModelTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(123)
        torch.set_num_threads(1)
        # 0 -> 2 -> 3; 1 -> 2.  Row is receiver, column is upstream source.
        self.edges = torch.tensor([[0, 1, 2], [2, 2, 3]])
        self.edge_attr = torch.tensor([[0.2, 0.1], [0.3, -0.1], [0.5, 0.2]])
        self.dist = torch.tensor([[0, -1, -1, -1], [-1, 0, -1, -1],
                                  [1, 1, 0, -1], [2, 2, 1, 0]])
        self.x = torch.randn(2, 4, 6, 3)
        self.static = torch.randn(4, 2)
        self.pair_attr = torch.randn(4, 4, 2)

    def model(self, alpha=0.5, kind="hybrid"):
        return RiverForecaster(ModelConfig(
            dynamic_dim=3, static_dim=2, hidden_dim=8, heads=2,
            layers=2, alpha=alpha, dropout=0, kind=kind,
        )).eval()

    def run_model(self, model, x=None, outlet=3):
        return model(self.x if x is None else x, self.static, self.edges,
                     self.edge_attr, self.dist, outlet_index=outlet, pair_attr=self.pair_attr)

    def test_permutation_invariance_at_corresponding_outlet(self):
        permutation = torch.tensor([2, 0, 3, 1])  # new index -> original index
        inverse = torch.argsort(permutation)
        for kind in ("hybrid", "local", "pooled"):
            for alpha in ((0.0, 0.5, 1.0) if kind == "hybrid" else (0.5,)):
                model = self.model(alpha, kind)
                original = self.run_model(model)
                reordered = model(
                    self.x[:, permutation], self.static[permutation],
                    inverse[self.edges], self.edge_attr,
                    self.dist[permutation][:, permutation],
                    outlet_index=int(inverse[3]),
                    pair_attr=self.pair_attr[permutation][:, permutation],
                )
                torch.testing.assert_close(original, reordered, atol=2e-6, rtol=2e-5)

    def test_no_downstream_or_sibling_information_leaks_upstream(self):
        # A query at headwater 0 cannot access downstream 2/3 or sibling 1.
        changed = self.x.clone()
        changed[:, 1:] += 100
        for alpha in (0.0, 0.5, 1.0):
            model = self.model(alpha)
            torch.testing.assert_close(
                self.run_model(model, outlet=0), self.run_model(model, changed, outlet=0),
                atol=0, rtol=0,
            )

    def test_upstream_information_can_affect_outlet(self):
        for alpha in (0.0, 0.5, 1.0):
            model = self.model(alpha)
            x = self.x.clone().requires_grad_(True)
            self.run_model(model, x).sum().backward()
            self.assertGreater(float(x.grad[:, 0].abs().sum()), 0)

    def test_endpoint_does_not_execute_inactive_branch(self):
        local = self.model(0)
        with patch.object(local.layers[0].global_attention, "forward", side_effect=AssertionError("inactive attention ran")):
            self.run_model(local).sum().backward()
        self.assertTrue(all(p.grad is None for p in local.layers[0].global_attention.parameters()))
        attention = self.model(1)
        with patch.object(attention.layers[0].local, "forward", side_effect=AssertionError("inactive local branch ran")):
            self.run_model(attention).sum().backward()
        self.assertTrue(all(p.grad is None for p in attention.layers[0].local.parameters()))

    def test_local_baseline_ignores_other_nodes(self):
        model = self.model(kind="local")
        changed = self.x.clone()
        changed[:, :3] += 100
        torch.testing.assert_close(self.run_model(model), self.run_model(model, changed), atol=0, rtol=0)

    def test_pool_control_ignores_edges(self):
        model = self.model(kind="pooled")
        expected = self.run_model(model)
        actual = model(self.x, self.static, outlet_index=3)
        torch.testing.assert_close(expected, actual, atol=0, rtol=0)

    def test_shared_initialization_and_parameter_accounting(self):
        models = []
        for alpha in (0, 0.5, 1):
            torch.manual_seed(10)
            models.append(self.model(alpha))
        for a, b in zip(models[0].state_dict().values(), models[1].state_dict().values()):
            torch.testing.assert_close(a, b, atol=0, rtol=0)
        counts = [m.parameter_counts() for m in models]
        self.assertEqual(counts[0]["total"], counts[1]["total"])
        self.assertEqual(counts[1]["total"], counts[2]["total"])
        self.assertEqual(counts[1]["active"], counts[1]["total"])
        self.assertGreater(counts[0]["inactive"], 0)
        self.assertGreater(counts[2]["inactive"], 0)

    def test_attention_rejects_invalid_distance_matrix(self):
        attention = UpstreamAttention(8, 2, 1, 0)
        with self.assertRaisesRegex(ValueError, "max_distance"):
            attention(torch.randn(2, 4, 8), self.dist)
        dist = self.dist.clone()
        dist[0, 0] = -1
        with self.assertRaisesRegex(ValueError, "diagonal"):
            attention(torch.randn(2, 4, 8), dist)

    def test_single_node_empty_edge_graph_has_finite_gradients(self):
        for alpha in (0, 0.5, 1):
            model = self.model(alpha)
            x = self.x[:, :1].clone().requires_grad_(True)
            output = model(x, self.static[:1], torch.empty(2, 0, dtype=torch.long),
                           torch.empty(0, 2), torch.zeros(1, 1, dtype=torch.long))
            self.assertEqual(output.shape, (2, 3))
            output.square().mean().backward()
            self.assertTrue(bool(torch.isfinite(x.grad).all()))

    def test_factory_accepts_dimensions_and_serialized_horizons(self):
        model = build_model({"kind": "hybrid", "hidden_dim": 8, "layers": 2,
                             "heads": 2, "horizons": [1, 3, 7]},
                            dynamic_dim=3, static_dim=2, edge_dim=2)
        self.assertEqual(self.run_model(model).shape, (2, 3))


if __name__ == "__main__":
    unittest.main()
