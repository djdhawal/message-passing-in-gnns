"""Forecast leakage, observation masks, split safety, and train/reload checks."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd
import torch

from river_hybrid.training import GraphWindowDataset, load_graphs, train_run


def tiny_processed(directory):
    directory = Path(directory)
    (directory / "graphs").mkdir(parents=True)
    dates = np.arange(np.datetime64("2000-01-01"), np.datetime64("2000-02-01")).astype(str)
    weather = np.zeros((len(dates), 3, 2), dtype=np.float32)
    weather[:, :, 0] = np.arange(len(dates))[:, None]
    weather[:, :, 1] = np.arange(3)[None, :]
    distance = np.array([[0, -1, -1], [1, 0, -1], [2, 1, 0]])
    metadata = []
    for index, spatial in enumerate(("development", "heldout")):
        factor = index + 1
        q = (4 + np.sin(np.arange(len(dates)) / 3))[:, None] * np.ones((1, 3)) * factor
        name = f"g{index}"
        graph = {
            "dates": dates, "weather": weather.copy(), "weather_mask": np.ones_like(weather),
            "flow": ((q / factor - 4) / 2).astype(np.float32)[..., None],
            "flow_mask": np.ones((*q.shape, 1), dtype=np.float32), "q_raw": q,
            "static": np.arange(6, dtype=np.float32).reshape(3, 2) / 6,
            "edge_index": np.array([[0, 1], [1, 2]]),
            "edge_attr": np.array([[1., .1], [2., .2]], dtype=np.float32),
            "ancestor_dist": distance, "pair_attr": np.zeros((3, 3, 2), dtype=np.float32),
            "outlet_index": np.array(2),
        }
        np.savez_compressed(directory / f"graphs/{name}.npz", **graph)
        metadata.append({"graph_id": name, "basin_id": f"basin{index}",
            "spatial_split": spatial, "file": f"graphs/{name}.npz", "depth": 2,
            "drainage_area_km2": 86.4 * factor,
            "train_mean": 4. * factor, "train_std": 2. * factor, "train_q90": 6. * factor})
    manifest = {
        "config": {"train_start": "2000-01-01", "train_end": "2000-01-12",
            "val_start": "2000-01-13", "val_end": "2000-01-20",
            "test_start": "2000-01-21", "test_end": "2000-01-31", "history": 3, "horizons": [1, 2]},
        "target_scaler": {"mean": 4., "std": 2., "q90": 6.}, "graphs": metadata,
    }
    (directory / "manifest.json").write_text(json.dumps(manifest))
    return manifest


class RiverTrainingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.processed = self.root / "processed"
        tiny_processed(self.processed)
        self.manifest, self.records = load_graphs(self.processed)
        self.metadata, self.graph = self.records[0]
        self.config = {"training": {"history": 3, "horizons": [1, 2], "batch_size": 4,
            "epochs": 2, "patience": 2, "learning_rate": .001, "weight_decay": .0001,
            "train_stride": 1, "eval_stride": 1, "device": "cpu", "threads": 1,
            "max_train_windows_per_graph": 6, "max_eval_windows_per_graph": 4},
            "model": {"hidden_dim": 8, "heads": 2, "layers": 2, "dropout": .1}}

    def tearDown(self):
        self.temporary.cleanup()

    def dataset(self, split="train", **kwargs):
        return GraphWindowDataset(self.graph, self.metadata, self.manifest, split,
                                  history=3, horizons=(1, 2), **kwargs)

    def test_all_targets_stay_inside_split_and_inputs_end_at_origin(self):
        for split in ("train", "val", "test"):
            dataset = self.dataset(split)
            starts = np.datetime64(self.manifest["config"][f"{split}_start"])
            ends = np.datetime64(self.manifest["config"][f"{split}_end"])
            for index, origin in enumerate(dataset.origins):
                targets = dataset.dates[origin + dataset.horizons]
                self.assertTrue(np.all((targets >= starts) & (targets <= ends)))
                sample = dataset[index]
                np.testing.assert_array_equal(sample["dynamic"][0, :, 0], np.arange(origin - 2, origin + 1))
                np.testing.assert_allclose(sample["target_raw"], self.graph["q_raw"][origin + dataset.horizons, 2])
            if split == "val":
                # The legitimate history crosses the split boundary; labels do not.
                self.assertLess(dataset.dates[dataset.origins[0]], starts)

    def test_missing_inputs_and_radius_hide_values_and_masks(self):
        self.graph["weather"][2, 2, 0] = np.nan
        self.graph["weather_mask"][2, 2, 1] = 0
        dataset = self.dataset(input_regime="weather_flow", context_radius=0)
        sample = dataset[0]["dynamic"].numpy()
        self.assertEqual(sample.shape, (3, 3, 6))
        self.assertTrue(np.isfinite(sample).all())
        self.assertTrue((sample[:2] == 0).all())
        np.testing.assert_array_equal(sample[2, -1, :4], [0, 0, 0, 0])
        self.assertEqual(sample[2, -1, 5], 1)

    def test_heldout_graphs_never_supply_train_or_validation_windows(self):
        metadata, graph = self.records[1]
        for split in ("train", "val"):
            with self.assertRaisesRegex(ValueError, "Held-out"):
                GraphWindowDataset(graph, metadata, self.manifest, split, history=3, horizons=(1, 2))
        test = GraphWindowDataset(graph, metadata, self.manifest, "test", history=3, horizons=(1, 2))
        self.assertEqual((test.mean, test.std, test.q90), (8., 4., 12.))
        # Changing held-out observations cannot change the training-fitted scaler.
        graph["q_raw"][:] *= 100
        test2 = GraphWindowDataset(graph, metadata, self.manifest, "test", history=3, horizons=(1, 2))
        self.assertEqual(test.std, test2.std)

    def test_disagreement_with_training_scaler_fails_loudly(self):
        self.metadata["train_std"] = 17
        with self.assertRaisesRegex(ValueError, "global development-training scaler"):
            self.dataset()

    def test_missing_targets_remove_entire_multi_horizon_window(self):
        self.graph["q_raw"][5, 2] = np.nan
        dataset = self.dataset()
        self.assertNotIn(3, dataset.origins)
        self.assertNotIn(4, dataset.origins)
        self.assertIn(5, dataset.origins)

    def test_train_predict_checkpoint_reload_and_fingerprint(self):
        output = self.root / "run"
        runtime = train_run(self.processed, output, self.config, seed=123)
        self.assertEqual(runtime["development_train_graphs"], ["g0"])
        self.assertEqual(runtime["heldout_test_graphs"], ["g1"])
        self.assertEqual(runtime["epochs_finished"], 2)
        predictions = pd.read_csv(output / "predictions.csv")
        self.assertTrue((predictions.y_pred >= 0).all())
        self.assertTrue(np.isfinite(predictions.y_pred).all())
        self.assertEqual(set(predictions[predictions.spatial_split == "heldout"].split), {"test"})
        self.assertTrue((pd.to_datetime(predictions.target_date) > pd.to_datetime(predictions.origin_date)).all())
        checkpoint = torch.load(output / "checkpoint.pt", weights_only=True)
        self.assertEqual(checkpoint["fingerprint"], runtime["fingerprint"])
        reused = train_run(self.processed, output, self.config, seed=123)
        self.assertTrue(reused["reused_completed_run"])
        # Simulate an interruption after the last training checkpoint but before
        # final prediction artifacts. Reload must reproduce the predictions.
        (output / "runtime.json").unlink()
        (output / "predictions.csv").unlink()
        resumed = train_run(self.processed, output, self.config, seed=123)
        self.assertEqual(resumed["epochs_finished"], 2)
        pd.testing.assert_frame_equal(predictions, pd.read_csv(output / "predictions.csv"))
        changed = copy.deepcopy(self.config)
        changed["model"]["hidden_dim"] = 16
        with self.assertRaisesRegex(ValueError, "different configuration"):
            train_run(self.processed, output, changed, seed=123)

    def test_persistence_uses_latest_available_past_observation(self):
        output = self.root / "persistence"
        train_run(self.processed, output, self.config, model="persistence", input_regime="weather_flow")
        prediction = pd.read_csv(output / "predictions.csv")
        for row in prediction[prediction.graph_id == "g0"].itertuples():
            origin = np.where(self.graph["dates"] == row.origin_date)[0][0]
            self.assertAlmostEqual(row.y_pred, self.graph["q_raw"][origin, 2], places=5)
        with self.assertRaisesRegex(ValueError, "requires"):
            train_run(self.processed, self.root / "bad_persistence", self.config, model="persistence")

    def test_persistence_missing_history_uses_training_mean_without_dropping_targets(self):
        self.graph["q_raw"][10:13, 2] = np.nan
        self.graph["flow_mask"][10:13, 2] = 0
        self.graph["flow"][10:13, 2] = 0
        np.savez_compressed(self.processed / self.metadata["file"], **self.graph)
        config = copy.deepcopy(self.config)
        config["training"]["max_eval_windows_per_graph"] = None
        persistence_dir, local_dir = self.root / "missing_persistence", self.root / "missing_local"
        runtime = train_run(self.processed, persistence_dir, config, model="persistence", input_regime="weather_flow")
        train_run(self.processed, local_dir, config, model="local", input_regime="weather_flow")
        persistence = pd.read_csv(persistence_dir / "predictions.csv")
        local = pd.read_csv(local_dir / "predictions.csv")
        keys = ["graph_id", "split", "horizon", "target_date"]
        pd.testing.assert_frame_equal(persistence[keys], local[keys])
        missing = persistence[(persistence.graph_id == "g0") & (persistence.origin_date == "2000-01-13")]
        self.assertEqual(len(missing), 2)
        np.testing.assert_allclose(missing.y_pred, self.manifest["target_scaler"]["mean"])
        self.assertEqual(runtime["prediction_rows_skipped_no_history"], 0)
        self.assertEqual(runtime["persistence_climatology_fallback_rows"], 2)


if __name__ == "__main__":
    unittest.main()
