import unittest
import json
import tempfile
from pathlib import Path
import pandas as pd
from river_hybrid.cli import sweep_specs, run_name, config_from, collect_runtimes
from river_hybrid.defaults import default_config


class WorkflowPlanTests(unittest.TestCase):
    def test_main_run_counts(self):
        cfg = default_config()
        self.assertEqual(len(sweep_specs(cfg)), 30)
        # 30 main + 12 learned controls + 1 deterministic persistence control.
        self.assertEqual(len(sweep_specs(cfg, True)), 43)

    def test_names_distinguish_all_runs(self):
        specs = sweep_specs(default_config(), True)
        names = [run_name(m, s, a, k, r) for m, s, a, k, r in specs]
        self.assertEqual(len(names), len(set(names)))
        self.assertNotEqual(run_name('hybrid','weather',.5,42,-1), run_name('hybrid','weather',.5,42,2))

    def test_defaults_are_independent(self):
        cfg = config_from(None)
        cfg['experiment']['alphas'].append(.9)
        self.assertEqual(len(default_config()['experiment']['alphas']),5)

    def test_training_runtime_adapts_to_analysis_cost_columns(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = Path(tmp) / 'one'
            run.mkdir()
            (run / 'runtime.json').write_text(json.dumps({
                'parameter_counts': {'total': 100, 'active': 60},
                'epochs_finished': 2, 'wall_seconds': 12.0,
            }))
            pd.DataFrame({'seconds': [3.0, 4.0]}).to_csv(run / 'learningcurve.csv', index=False)
            collect_runtimes(tmp)
            row = pd.read_csv(Path(tmp) / 'runtimes.csv').iloc[0]
            self.assertEqual(row['parameters'], 100)
            self.assertEqual(row['active_parameters'], 60)
            self.assertEqual(row['epochs'], 2)
            self.assertEqual(row['train_seconds'], 7.0)
