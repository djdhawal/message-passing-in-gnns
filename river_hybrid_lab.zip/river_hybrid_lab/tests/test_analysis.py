"""Small fabricated fixtures test statistics and leakage controls, not hydrology."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from river_hybrid.analysis import (
    analyze, bootstrap_selector_comparison, choose_heldout_alphas, compute_metrics,
    fit_selector, near_optimal_alpha_table, paired_selector_errors, validate_predictions,
    _record_prediction_manifest, _stream_paired_errors,
)


def fixture():
    graphs, rows = [], []
    for graph_index in range(6):
        graph = f"g{graph_index}"
        basin = f"b{graph_index}"
        spatial_split = "development" if graph_index < 4 else "heldout"
        depth = 2 if graph_index % 2 == 0 else 6
        graphs.append(dict(graph_id=graph, basin_id=basin, spatial_split=spatial_split,
                           n_nodes=depth + 2, depth=depth, mean_branching=1.5,
                           river_length_km=10 * depth, drainage_area_km2=100 * depth))
        for split, dates in [("val", ["2002-01-01", "2003-01-01"]),
                             ("test", ["2006-01-01", "2007-01-01"])]:
            for regime in ["weather", "weather_flow"]:
                for horizon in [1, 3]:
                    optimal = float((depth > 3) != (regime == "weather_flow"))
                    for alpha in [0.0, 0.5, 1.0]:
                        for seed in [0, 1]:
                            run_id = f"hybrid_{regime}_{alpha}_{seed}"
                            for index, date in enumerate(dates):
                                truth = float(1 + 2 * index)
                                error = 0.1 + abs(alpha - optimal) + 0.01 * seed
                                rows.append(dict(graph_id=graph, basin_id=basin,
                                    spatial_split=spatial_split, split=split, input_regime=regime,
                                    model="hybrid", alpha=alpha, seed=seed, horizon=horizon,
                                    target_date=date, y_true=truth, y_pred=truth + error,
                                    train_mean=2.0, train_std=2.0, train_q90=2.5,
                                    context_radius=-1, run_id=run_id))
    return pd.DataFrame(rows), pd.DataFrame(graphs)


class MetricsTests(unittest.TestCase):
    def test_metrics_use_frozen_training_scale_and_threshold(self):
        p, _ = fixture()
        p = p[(p.graph_id == "g0") & (p.split == "val") & (p.input_regime == "weather")
              & (p.horizon == 1) & (p.alpha == 0) & (p.seed == 0)].copy()
        p.loc[:, "y_true"] = [1.0, 3.0]
        p.loc[:, "y_pred"] = [2.0, 2.0]
        m = compute_metrics(p).iloc[0]
        self.assertAlmostEqual(m.rmse, 1)
        self.assertAlmostEqual(m.mae, 1)
        self.assertAlmostEqual(m.nrmse, .5)
        self.assertAlmostEqual(m.nse, 0)
        self.assertEqual(m.high_flow_n, 1)
        self.assertAlmostEqual(m.high_flow_mae, 1)

    def test_constant_series_nse_is_undefined(self):
        p, _ = fixture()
        p = p[(p.graph_id == "g0") & (p.split == "val") & (p.input_regime == "weather")
              & (p.horizon == 1) & (p.alpha == 0) & (p.seed == 0)].copy()
        p.loc[:, "y_true"] = 1.0
        self.assertTrue(np.isnan(compute_metrics(p).nse.iloc[0]))

    def test_comparison_requires_matching_dates(self):
        p, _ = fixture()
        p = p.drop(p.index[0])
        with self.assertRaisesRegex(ValueError, "forecast dates"):
            validate_predictions(p)

    def test_rejects_duplicate_records(self):
        p, _ = fixture()
        with self.assertRaisesRegex(ValueError, "Duplicate forecast"):
            validate_predictions(pd.concat([p, p.iloc[:1]]))

    def test_near_optimal_set_keeps_ties(self):
        p, _ = fixture()
        m = compute_metrics(p)
        m.loc[(m.graph_id == "g0") & (m.split == "val"), "nrmse"] = 1.0
        selected = near_optimal_alpha_table(m)
        self.assertTrue(selected[selected.graph_id == "g0"].near_optimal.all())
        self.assertEqual(set(selected.split), {"val"})
        self.assertEqual(set(selected.spatial_split), {"development"})


class SelectorTests(unittest.TestCase):
    def test_selector_does_not_read_test_or_heldout_labels(self):
        p, graphs = fixture()
        m = compute_metrics(p)
        before = fit_selector(m, graphs)
        poisoned = m.copy()
        excluded = (poisoned.split != "val") | (poisoned.spatial_split != "development")
        poisoned.loc[excluded, "nrmse"] = np.arange(excluded.sum()) * 10000.0
        after = fit_selector(poisoned, graphs)
        self.assertEqual(before["selected_hyperparameters"], after["selected_hyperparameters"])
        self.assertEqual(before["rules"], after["rules"])
        pd.testing.assert_frame_equal(before["fixed_choices"], after["fixed_choices"])
        choices_before = choose_heldout_alphas(before, p, graphs)
        modified_p = p.copy()
        modified_p.loc[modified_p.spatial_split == "heldout", "y_true"] = -1000000
        choices_after = choose_heldout_alphas(after, modified_p, graphs)
        pd.testing.assert_frame_equal(choices_before, choices_after)

    def test_group_cv_keeps_horizons_and_regimes_of_each_basin_together(self):
        p, graphs = fixture()
        fitted = fit_selector(compute_metrics(p), graphs)
        seen_validation = []
        for fold in fitted["cv_folds"]:
            self.assertFalse(set(fold["train_basins"]) & set(fold["validation_basins"]))
            self.assertEqual(set(fold["train_basins"]) | set(fold["validation_basins"]), {"b0", "b1", "b2", "b3"})
            seen_validation.extend(fold["validation_basins"])
        self.assertEqual(sorted(seen_validation), ["b0", "b1", "b2", "b3"])
        self.assertEqual(len(fitted["fixed_choices"]), 4)

    def test_incomplete_curves_rejected(self):
        p, graphs = fixture()
        m = compute_metrics(p)
        remove = (m.graph_id == "g0") & (m.split == "val") & (m.input_regime == "weather") & (m.horizon == 1) & (m.alpha == 1)
        with self.assertRaisesRegex(ValueError, "incomplete alpha curves"):
            fit_selector(m[~remove], graphs)

    def test_insufficient_groups_rejected(self):
        p, graphs = fixture()
        m = compute_metrics(p)
        with self.assertRaisesRegex(ValueError, "three development basin"):
            fit_selector(m[m.basin_id.isin(["b0", "b1", "b4", "b5"])], graphs)

    def test_pairing_averages_errors_not_predictions(self):
        p, graphs = fixture()
        selector = fit_selector(compute_metrics(p), graphs)
        choices = choose_heldout_alphas(selector, p, graphs)
        choices.loc[:, "selected_alpha"] = 0.0
        choices.loc[:, "fixed_alpha"] = 0.0
        held = (p.spatial_split == "heldout") & (p.split == "test") & (p.alpha == 0)
        p.loc[held & (p.seed == 0), "y_pred"] = p.loc[held & (p.seed == 0), "y_true"] + 2.0
        p.loc[held & (p.seed == 1), "y_pred"] = p.loc[held & (p.seed == 1), "y_true"] - 2.0
        paired = paired_selector_errors(p, choices)
        self.assertTrue(np.allclose(paired.scaled_error2_selected, 1.0))
        self.assertTrue(np.allclose(paired.scaled_error2_fixed, 1.0))
        summary = bootstrap_selector_comparison(paired, samples=20)
        self.assertEqual(summary["delta_selected_minus_fixed"], 0)
        self.assertEqual(summary["delta_95pct_interval"], [0.0, 0.0])

    def test_spatial_group_overlap_is_rejected(self):
        p, graphs = fixture()
        selector = fit_selector(compute_metrics(p), graphs)
        p.loc[p.graph_id == "g4", "basin_id"] = "b0"
        with self.assertRaisesRegex(ValueError, "both development and held-out"):
            choose_heldout_alphas(selector, p, graphs)

    def test_streamed_pairing_matches_in_memory_across_files_and_chunks(self):
        p, graphs = fixture()
        p = validate_predictions(p)
        metrics = compute_metrics(p)
        selector = fit_selector(metrics, graphs)
        choices = choose_heldout_alphas(selector, metrics, graphs)
        expected = paired_selector_errors(p, choices)
        manifest = {"runs": {}, "graphs": {}, "tasks": {}, "run_tasks": set()}
        with tempfile.TemporaryDirectory() as directory:
            paths = []
            for run_id, frame in p.groupby("run_id"):
                path = Path(directory) / f"{run_id}.csv"
                frame.to_csv(path, index=False)
                paths.append(path)
                _record_prediction_manifest(frame, manifest)
            actual = _stream_paired_errors(paths, choices, metrics, manifest, chunksize=31)
        keys = ["graph_id", "basin_id", "input_regime", "horizon", "target_date"]
        expected = expected.sort_values(keys).reset_index(drop=True)
        actual = actual.sort_values(keys).reset_index(drop=True)[expected.columns]
        pd.testing.assert_frame_equal(actual, expected, check_dtype=False, rtol=1e-12)

    def test_cross_file_manifest_rejects_mismatched_target_dates(self):
        p, _ = fixture()
        p = validate_predictions(p)
        runs = list(p.groupby("run_id"))
        manifest = {"runs": {}, "graphs": {}, "tasks": {}, "run_tasks": set()}
        _record_prediction_manifest(runs[0][1], manifest)
        changed = runs[1][1].copy()
        changed.loc[changed.index[0], "target_date"] += pd.Timedelta(days=1)
        with self.assertRaisesRegex(ValueError, "disagree across runs"):
            _record_prediction_manifest(changed, manifest)

    def test_analysis_writes_reviewable_outputs(self):
        p, graphs = fixture()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            p.to_csv(root / "predictions.csv", index=False)
            graphs.to_csv(root / "graphs.csv", index=False)
            status = analyze([root / "predictions.csv"], root / "graphs.csv", root / "analysis", bootstrap_samples=10)
            self.assertEqual(status["selector"], "evaluated")
            self.assertEqual(status["bootstrap"], "evaluated")
            for name in ["metrics.csv", "selector_choices.csv", "selector_comparison.csv", "selector_bootstrap.json",
                         "alpha_curves.csv", "near_optimal_alpha.csv", "selector_status.json"]:
                self.assertTrue((root / "analysis" / name).exists(), name)
            self.assertTrue(list((root / "analysis" / "plots").glob("*.png")))


if __name__ == "__main__":
    unittest.main()
