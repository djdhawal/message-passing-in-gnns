# Verification performed for this code bundle

Verified on 1 October 2026. These are software checks, not evidence that any alpha is scientifically better.

## Automated checks

The complete suite passed: **44 tests**. It covers:

- Complete upstream trees, edge direction, disjoint gauge selection, known-transfer grouping, and spatial split support.
- Training-only normalization, including perturbations of future and held-out observations/static values.
- Source discharge quality flags, strongly impacted-gauge exclusion, and safe archive extraction.
- Permutation invariance, upstream-only communication, both alpha endpoints, and active parameter accounting.
- Forecast histories ending at issue time, all target dates staying inside their partition, missing inputs/targets, and context masking.
- Training, checkpoint reload, data/configuration fingerprints, and persistence's missing-history fallback.
- Frozen metric scales, comparable forecast dates, held-out-label exclusion from alpha selection, grouped cross-validation, and streamed paired-error calculations.
- CLI run counts, unique run names, and the conversion of runtime logs into analysis cost columns.

To run the checks yourself:

```bash
python -m pip install -e '.[test]'
python -m pytest -q tests
```

## End-to-end execution

An artificial file-format fixture completed the full five-alpha, two-input-setting, three-seed grid: 43 main/baseline runs and 36 context ablation runs. Analysis processed 26,544 forecast rows and wrote metrics, alpha curves, baseline/context figures, runtime figures, and held-out selector comparisons. The fixture contains only six months, so the calendar-year bootstrap correctly reported insufficient support instead of inventing an uncertainty interval. This fixture is not a hydrological benchmark.

The final source version was also checked using the smaller `demo` workflow after the last data and persistence changes. The plots were inspected for readable axes and labels. The Python package built successfully as a wheel. The notebook has valid JSON structure and its code cells pass Python syntax checks; an interactive Google Colab session was not executed here.

## Real LamaH-CE validation

The actual original daily archive was downloaded and its MD5 matched `69fd2733e969513403f923ecc5eaa3dc`. The adapter successfully audited and processed its real files without schema substitutions.

With the default structural caps, preparation selected 32 gauge-disjoint trees, containing 5–35 nodes and depth 1–8. Ten terminal river groups became seven spatial groups after joining groups linked by documented cross-basin transfers. The resulting split contained 27 development graphs across three groups and five held-out graphs across four groups. This small number of development groups limits the strength of selector conclusions. Twenty selected outlets were strongly impacted and 16 graphs contained transfer endpoints; the manifest records these confounders.

One **capped real-data training run** completed on CPU: alpha 0.5, weather plus past flow, 90-day histories, horizons 1/3/7, eight layers, hidden width 16, and one epoch. It used 216 training windows, 108 validation windows, and 128 test windows, exporting 708 forecasts. A separate availability audit checked all 191,402 eligible validation/test windows and found no cases with entirely missing 90-day outlet-flow history. The missing-history fallback is still tested for other configurations.

**The full real-data experiment has not been trained, tuned, or evaluated for research conclusions.** No real-data accuracy or preferred alpha is claimed. `configs/real_smoke.json` reproduces the deliberately capped optimizer check; use `configs/default.json` or `init-config` for the planned experiment.

Example after preparing real data:

```bash
python -m river_hybrid train --processed data/processed --runs results/real_smoke --config configs/real_smoke.json --model hybrid --alpha 0.5 --input-regime weather_flow --seed 42
```

Keep smoke outputs in their own directory, separate from the research sweep.

## Environment used

| Component | Version |
|---|---|
| Python | 3.12.14 |
| NumPy | 2.3.5 |
| pandas | 2.2.3 |
| PyTorch | 2.14.1+cpu |
| scikit-learn | 1.8.0 |
| Matplotlib | 3.10.8 |
| pytest | 9.1.1 |

CUDA was unavailable in the verification environment. GPU execution, full-budget convergence, Colab-specific behavior, and every version allowed by the dependency bounds remain unverified. Record your resolved environment and inspect learning curves for each research run.
