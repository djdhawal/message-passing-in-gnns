"""Chronological forecasting windows and reproducible single-run training.

All target scaling comes from development-basin training dates. The supplied
NPZs already contain standardized observations and their availability masks;
this module never interpolates, fits a scaler, or consults future observations.
Negative discharge predictions are clipped to zero for validation/evaluation,
but targets and the training objective are never clipped. A completed output
directory is reusable only with an identical configuration and data manifest.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset

from .models import ModelConfig, build_model


PREDICTION_COLUMNS = [
    "graph_id", "basin_id", "spatial_split", "split", "input_regime", "model",
    "alpha", "seed", "horizon", "origin_date", "target_date", "y_true", "y_pred",
    "train_mean", "train_std", "train_q90", "context_radius", "run_id",
]


def _write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def _save_torch(path: Path, obj: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, temporary)
    temporary.replace(path)


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed % (2**32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # GPU implementations can still have small numerical differences across
    # hardware/library versions. Deterministic kernels are preferred when present.
    torch.use_deterministic_algorithms(True, warn_only=True)
    if torch.backends.cudnn.is_available():
        torch.backends.cudnn.benchmark = False


def load_graphs(processed_dir: str | Path) -> tuple[dict, list[tuple[dict, dict]]]:
    """Read manifest and the explicitly listed NPZ graph files, without pickle."""
    directory = Path(processed_dir)
    manifest = json.loads((directory / "manifest.json").read_text())
    records = []
    for metadata in manifest["graphs"]:
        with np.load(directory / metadata["file"], allow_pickle=False) as archive:
            graph = {key: archive[key] for key in archive.files}
        records.append((metadata, graph))
    if not records:
        raise ValueError("The processed manifest contains no graphs")
    return manifest, records


class GraphWindowDataset(Dataset):
    """Windows for one graph, preserving graph boundaries when batching.

    A sample issued at t uses [t-history+1, t] and predicts t+h for each h.
    Every target date must belong to the requested split. Histories may extend
    into the previous split because those observations existed at issue time.
    Missing input values are zero with mask zero, never forward/backward filled.
    ``context_radius`` masks observations outside the outlet's upstream radius
    throughout training and evaluation; it does not remove structural nodes.
    """

    def __init__(self, graph: dict, metadata: dict, manifest: dict, split: str,
                 history: int = 90, horizons=(1, 3, 7), input_regime: str = "weather",
                 context_radius: int = -1, stride: int = 1,
                 max_windows: int | None = None):
        if split not in {"train", "val", "test"}:
            raise ValueError("split must be train, val, or test")
        if metadata["spatial_split"] == "heldout" and split != "test":
            raise ValueError("Held-out catchments are reserved exclusively for test evaluation")
        if input_regime not in {"weather", "weather_flow"}:
            raise ValueError("input_regime must be weather or weather_flow")
        if history < 1 or stride < 1 or context_radius < -1:
            raise ValueError("history and stride must be positive; context_radius >= -1")
        self.horizons = np.asarray(horizons, dtype=int)
        if self.horizons.ndim != 1 or not len(self.horizons) or np.any(self.horizons <= 0):
            raise ValueError("horizons must be nonempty positive integers")
        if len(set(self.horizons.tolist())) != len(self.horizons):
            raise ValueError("Duplicate horizons are not allowed")
        self.graph, self.metadata, self.manifest = graph, metadata, manifest
        self.split, self.history = split, int(history)
        self.input_regime, self.context_radius = input_regime, int(context_radius)
        self.root = int(np.asarray(graph["outlet_index"]).item())
        self.dates = np.asarray(graph["dates"]).astype("datetime64[D]")
        if np.any(np.diff(self.dates) != np.timedelta64(1, "D")):
            raise ValueError("Prepared graphs must use a contiguous daily date axis")
        self.mean, self.std, self.q90 = self._target_stats()
        weather = np.asarray(graph["weather"], dtype=np.float32)
        weather_mask = np.asarray(graph["weather_mask"])
        if weather.ndim != 3 or weather.shape[-1] != 2 or weather_mask.shape != weather.shape:
            raise ValueError("Expected weather and weather_mask shapes [days,nodes,2]")
        self.weather, self.weather_mask = weather, weather_mask
        self.flow, self.flow_mask = None, None
        if input_regime == "weather_flow":
            flow = np.asarray(graph["flow"], dtype=np.float32)
            flow_mask = np.asarray(graph["flow_mask"])
            if flow.shape != (*weather.shape[:2], 1) or flow_mask.shape != flow.shape:
                raise ValueError("Expected flow and flow_mask shapes [days,nodes,1]")
            self.flow, self.flow_mask = flow, flow_mask
        self.context_mask = np.ones(weather.shape[1], dtype=bool)
        if context_radius >= 0:
            distance = np.asarray(graph["ancestor_dist"])[self.root]
            self.context_mask = (distance >= 0) & (distance <= context_radius)
        self.q = np.asarray(graph["q_raw"])[:, self.root].astype(float)
        date_config = manifest["config"]
        start = np.datetime64(date_config[f"{split}_start"], "D")
        end = np.datetime64(date_config[f"{split}_end"], "D")
        if start > end:
            raise ValueError(f"Invalid {split} date interval")
        origins = np.arange(history - 1, len(self.dates) - int(self.horizons.max()), dtype=int)
        targets = origins[:, None] + self.horizons
        target_dates = self.dates[targets]
        valid = np.all((target_dates >= start) & (target_dates <= end), axis=1)
        valid &= np.all(np.isfinite(self.q[targets]), axis=1)
        self.origins = origins[valid][::stride]
        if max_windows is not None:
            if int(max_windows) < 1:
                raise ValueError("max_windows must be positive or None")
            if len(self.origins) > int(max_windows):
                # Cover the entire split rather than selecting only early years.
                keep = np.linspace(0, len(self.origins) - 1, int(max_windows), dtype=int)
                self.origins = self.origins[keep]

    def _target_stats(self) -> tuple[float, float, float]:
        scaler = self.manifest["target_scaler"]
        factor = float(self.metadata["drainage_area_km2"]) / 86.4
        if not math.isfinite(factor) or factor <= 0:
            raise ValueError("A positive outlet drainage area is required")
        mean, std = float(scaler["mean"]) * factor, float(scaler["std"]) * factor
        q90 = float(scaler["q90"]) * factor
        if not all(map(math.isfinite, (mean, std, q90))) or std <= 0:
            raise ValueError("Invalid development-training target scaler")
        # The per-graph values are convenience copies, not outlet-specific fits.
        for key, value in (("train_mean", mean), ("train_std", std), ("train_q90", q90)):
            if key in self.metadata and not np.isclose(float(self.metadata[key]), value, rtol=1e-5, atol=1e-6):
                raise ValueError(f"{key} conflicts with the global development-training scaler")
        return mean, std, q90

    def __len__(self) -> int:
        return len(self.origins)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        origin = int(self.origins[index])
        # Construct only this window; keeping three full feature copies for
        # train/validation/test can otherwise use gigabytes on the real archive.
        window = slice(origin - self.history + 1, origin + 1)
        weather = self.weather[window]
        weather_mask = ((self.weather_mask[window] > 0) & np.isfinite(weather)).astype(np.float32)
        pieces = [np.where(weather_mask > 0, weather, 0), weather_mask]
        if self.flow is not None:
            flow = self.flow[window]
            flow_mask = ((self.flow_mask[window] > 0) & np.isfinite(flow)).astype(np.float32)
            pieces.extend([np.where(flow_mask > 0, flow, 0), flow_mask])
        dynamic = np.concatenate(pieces, axis=-1).transpose(1, 0, 2).copy()
        dynamic[~self.context_mask] = 0
        target_raw = self.q[origin + self.horizons].astype(np.float32)
        target = ((target_raw - self.mean) / self.std).astype(np.float32)
        return {"dynamic": torch.from_numpy(dynamic), "target": torch.from_numpy(target),
                "target_raw": torch.from_numpy(target_raw), "origin": torch.tensor(origin)}


def _graph_tensors(graph: dict, device: torch.device) -> dict:
    return {
        "static": torch.as_tensor(graph["static"], dtype=torch.float32, device=device),
        "edge_index": torch.as_tensor(graph["edge_index"], dtype=torch.long, device=device),
        "edge_attr": torch.as_tensor(graph["edge_attr"], dtype=torch.float32, device=device),
        "ancestor_dist": torch.as_tensor(graph["ancestor_dist"], dtype=torch.long, device=device),
        "outlet_index": int(np.asarray(graph["outlet_index"]).item()),
        "pair_attr": torch.as_tensor(graph["pair_attr"], dtype=torch.float32, device=device),
    }


def _loader(dataset: GraphWindowDataset, batch_size: int, shuffle: bool = False,
            seed: int = 0) -> DataLoader:
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=0,
                      generator=generator, drop_last=False)


def _validate(network, datasets, batch_size, device) -> float:
    """Mean of graph-level standardized MSEs, with physical prediction clipping."""
    network.eval()
    graph_losses = []
    with torch.no_grad():
        for dataset in datasets:
            tensors = _graph_tensors(dataset.graph, device)
            total, count = 0., 0
            for batch in _loader(dataset, batch_size):
                prediction = network(batch["dynamic"].to(device), **tensors)
                prediction = prediction.clamp_min(-dataset.mean / dataset.std)
                errors = (prediction - batch["target"].to(device)).square()
                total += errors.sum().item()
                count += errors.numel()
            if count:
                graph_losses.append(total / count)
    if not graph_losses:
        raise ValueError("No development validation windows; inspect dates and QC masks")
    return float(np.mean(graph_losses))


def _prediction_rows(network, datasets, options, batch_size, device):
    rows, fallback_rows = [], 0
    if network is not None:
        network.eval()
    with torch.no_grad():
        for dataset in datasets:
            tensors = _graph_tensors(dataset.graph, device) if network is not None else None
            for batch in _loader(dataset, batch_size):
                origins = batch["origin"].numpy()
                fallback = np.zeros(len(origins), dtype=bool)
                if network is None:
                    predictions = []
                    for i, origin in enumerate(origins):
                        recent = dataset.q[origin - dataset.history + 1:origin + 1]
                        finite = recent[np.isfinite(recent)]
                        # Keep precisely the same target windows as every other
                        # model. If the permitted history has no discharge, use
                        # the globally fitted development-training climatology,
                        # area-scaled for this outlet, without fitting held-out Q.
                        fallback[i] = not len(finite)
                        value = finite[-1] if len(finite) else max(dataset.mean, 0.)
                        predictions.append(np.repeat(value, len(dataset.horizons)))
                    raw = np.asarray(predictions)
                else:
                    standardized = network(batch["dynamic"].to(device), **tensors).cpu().numpy()
                    raw = np.maximum(standardized * dataset.std + dataset.mean, 0)
                if not np.isfinite(raw).all():
                    raise FloatingPointError("Non-finite predictions; refusing to silently change evaluation coverage")
                targets = batch["target_raw"].numpy()
                for index, origin in enumerate(origins):
                    for j, horizon in enumerate(dataset.horizons):
                        fallback_rows += int(fallback[index])
                        meta = dataset.metadata
                        rows.append({
                            "graph_id": str(meta["graph_id"]), "basin_id": str(meta["basin_id"]),
                            "spatial_split": meta["spatial_split"], "split": dataset.split,
                            "input_regime": options["input_regime"], "model": options["model"],
                            "alpha": options["alpha"] if options["model"] == "hybrid" else None,
                            "seed": options["seed"], "horizon": int(horizon),
                            "origin_date": str(dataset.dates[origin]),
                            "target_date": str(dataset.dates[origin + horizon]),
                            "y_true": float(targets[index, j]), "y_pred": float(raw[index, j]),
                            "train_mean": dataset.mean, "train_std": dataset.std,
                            "train_q90": dataset.q90, "context_radius": options["context_radius"],
                            "run_id": options["run_id"],
                        })
    return rows, fallback_rows


def train_run(processed_dir: str | Path, output_dir: str | Path, config: dict,
              model: str = "hybrid", alpha: float = .5, input_regime: str = "weather",
              seed: int = 42, context_radius: int = -1) -> dict:
    """Train one configuration, resume safely, and write held-out predictions.

    ``model='persistence'`` evaluates latest available discharge in the history
    window without fitting; it requires ``input_regime='weather_flow'``. Windows
    with no observed discharge use the area-scaled development-training mean so
    all models retain identical target dates. Runtime records fallback counts.
    Runs stop on development validation loss only. Held-out catchments are
    loaded exclusively for final temporal test predictions.
    """
    start_time = time.perf_counter()
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    processed = Path(processed_dir)
    if model not in {"hybrid", "local", "pooled", "persistence"}:
        raise ValueError("Unknown model kind")
    if input_regime not in {"weather", "weather_flow"}:
        raise ValueError("input_regime must be weather or weather_flow")
    if model == "persistence" and input_regime != "weather_flow":
        raise ValueError("Persistence requires the weather_flow observation regime")
    if not 0 <= float(alpha) <= 1:
        raise ValueError("alpha must lie in [0,1]")
    options = {"model": model, "alpha": float(alpha), "input_regime": input_regime,
               "seed": int(seed), "context_radius": int(context_radius), "run_id": output.name}
    manifest_bytes = (processed / "manifest.json").read_bytes()
    declared_graphs = json.loads(manifest_bytes)["graphs"]
    identity = {"config": config, "options": options,
                "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
                "graph_sha256": {record["file"]: _file_sha256(processed / record["file"])
                                 for record in declared_graphs}}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    config_path = output / "config.json"
    if config_path.exists():
        prior = json.loads(config_path.read_text())
        if prior.get("fingerprint") != fingerprint:
            raise ValueError("Output directory belongs to a different configuration/data manifest. Use a new run directory.")
    else:
        _write_json(config_path, {**identity, "fingerprint": fingerprint})
    runtime_path = output / "runtime.json"
    if runtime_path.exists() and (output / "predictions.csv").exists():
        previous = json.loads(runtime_path.read_text())
        if previous.get("completed") and previous.get("fingerprint") == fingerprint:
            print(f"[{output.name}] Reusing completed run with matching configuration and data.", flush=True)
            return {**previous, "reused_completed_run": True}

    settings = config.get("training", {})
    model_settings = config.get("model", {})
    threads = int(settings.get("threads", 2))
    if threads > 0:
        torch.set_num_threads(threads)
    _seed_everything(seed)
    device_name = settings.get("device", "auto")
    if device_name == "auto":
        device_name = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(device_name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA requested but unavailable; use training.device='auto' or 'cpu'")
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    manifest, records = load_graphs(processed)
    data_settings = manifest["config"]
    history = int(settings.get("history", data_settings.get("history", 90)))
    horizons = tuple(int(h) for h in settings.get("horizons", data_settings.get("horizons", [1, 3, 7])))
    batch_size = int(settings.get("batch_size", 16))
    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    train_sets, val_sets, test_sets = [], [], []
    for metadata, graph in records:
        for split in ("train", "val", "test"):
            if metadata["spatial_split"] == "heldout" and split != "test":
                continue
            is_train = split == "train"
            dataset = GraphWindowDataset(
                graph, metadata, manifest, split, history, horizons, input_regime, context_radius,
                stride=int(settings.get("train_stride" if is_train else "eval_stride", 7 if is_train else 1)),
                max_windows=settings.get("max_train_windows_per_graph" if is_train else "max_eval_windows_per_graph"),
            )
            if len(dataset):
                {"train": train_sets, "val": val_sets, "test": test_sets}[split].append(dataset)
    if not train_sets or not val_sets or not test_sets:
        raise ValueError("Need nonempty development train/validation and test windows; inspect split dates, history, horizons, and flow QC")
    feature_dims = {dataset.graph["static"].shape[1] for dataset in train_sets + val_sets + test_sets}
    if len(feature_dims) != 1:
        raise ValueError("All graphs must have the same static feature schema")
    if model == "hybrid" and int(model_settings.get("layers", 8)) < max(int(ds.metadata["depth"]) for ds in train_sets + test_sets):
        raise ValueError("Spatial layers are below graph depth. Increase model.layers or prepare shallower trees; under-reaching is a separate control.")

    network, epochs_finished, best_val, parameter_counts = None, 0, None, {"total": 0, "active": 0, "inactive": 0}
    curve_path = output / "learningcurve.csv"
    curve = []
    if model != "persistence":
        architecture = ModelConfig(kind=model, hidden_dim=int(model_settings.get("hidden_dim", 64)),
            layers=int(model_settings.get("layers", 8)), heads=int(model_settings.get("heads", 4)),
            horizons=horizons, alpha=float(alpha), dropout=float(model_settings.get("dropout", .1)),
            max_distance=int(model_settings.get("max_distance", 64)))
        network = build_model(architecture, dynamic_dim=4 if input_regime == "weather" else 6,
                              static_dim=next(iter(feature_dims)), edge_dim=2).to(device)
        parameter_counts = network.parameter_counts()
        optimizer = torch.optim.AdamW(network.parameters(), lr=float(settings.get("learning_rate", .001)),
                                      weight_decay=float(settings.get("weight_decay", .0001)))
        epochs, patience = int(settings.get("epochs", 50)), int(settings.get("patience", 8))
        if epochs < 1 or patience < 1:
            raise ValueError("epochs and patience must be positive")
        begin_epoch, best_val, bad_epochs, best_state = 0, float("inf"), 0, None
        last_path = output / "last.pt"
        if last_path.exists():
            saved = torch.load(last_path, map_location=device, weights_only=True)
            if saved["fingerprint"] != fingerprint:
                raise ValueError("Checkpoint fingerprint does not match this run")
            network.load_state_dict(saved["model_state"])
            optimizer.load_state_dict(saved["optimizer_state"])
            begin_epoch, best_val, bad_epochs = int(saved["epoch"]) + 1, float(saved["best_val"]), int(saved["bad_epochs"])
            best_state = saved["best_state"]
            curve = saved["learningcurve"]
        for epoch in range(begin_epoch, epochs):
            if bad_epochs >= patience:
                break
            # Reseeding by epoch makes resumed epochs reproduce loader order and dropout.
            _seed_everything(seed + epoch)
            network.train()
            epoch_start = time.perf_counter()
            total_loss, total_targets = 0., 0
            order = np.random.default_rng(seed + epoch).permutation(len(train_sets))
            for graph_number in order:
                dataset = train_sets[int(graph_number)]
                tensors = _graph_tensors(dataset.graph, device)
                for batch in _loader(dataset, batch_size, shuffle=True, seed=seed + epoch * 1009 + int(graph_number)):
                    optimizer.zero_grad(set_to_none=True)
                    predicted = network(batch["dynamic"].to(device), **tensors)
                    target = batch["target"].to(device)
                    loss = (predicted - target).square().mean()
                    if not torch.isfinite(loss):
                        raise FloatingPointError("Non-finite training loss; inspect preprocessing and learning rate")
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(network.parameters(), float(settings.get("gradient_clip", 1.)))
                    optimizer.step()
                    total_loss += loss.item() * target.numel()
                    total_targets += target.numel()
            validation = _validate(network, val_sets, batch_size, device)
            improved = validation < best_val - float(settings.get("min_delta", 0.))
            if improved:
                best_val, bad_epochs = validation, 0
                best_state = {name: value.detach().cpu().clone() for name, value in network.state_dict().items()}
            else:
                bad_epochs += 1
            curve.append({"epoch": epoch + 1, "train_mse": total_loss / total_targets,
                          "val_mse": validation, "seconds": time.perf_counter() - epoch_start})
            print(f"[{output.name}] epoch {epoch + 1}/{epochs} "
                  f"train_mse={curve[-1]['train_mse']:.5f} dev_val_mse={validation:.5f} "
                  f"seconds={curve[-1]['seconds']:.1f}", flush=True)
            pd.DataFrame(curve).to_csv(curve_path, index=False)
            _save_torch(last_path, {"fingerprint": fingerprint, "epoch": epoch,
                "model_state": network.state_dict(), "optimizer_state": optimizer.state_dict(),
                "best_val": best_val, "bad_epochs": bad_epochs, "best_state": best_state,
                "learningcurve": curve})
        if best_state is None:
            raise RuntimeError("Training produced no checkpoint")
        network.load_state_dict(best_state)
        epochs_finished = len(curve)
        _save_torch(output / "checkpoint.pt", {"fingerprint": fingerprint, "model_state": best_state,
                    "config": identity, "best_val": best_val, "epochs_finished": epochs_finished})
    else:
        pd.DataFrame(columns=["epoch", "train_mse", "val_mse", "seconds"]).to_csv(curve_path, index=False)

    rows, fallback_rows = _prediction_rows(network, val_sets + test_sets, options, batch_size, device)
    if not rows:
        raise ValueError("No predictions could be made")
    prediction_path = output / "predictions.csv"
    pd.DataFrame(rows, columns=PREDICTION_COLUMNS).to_csv(prediction_path, index=False)
    runtime = {
        "completed": True, "fingerprint": fingerprint, **options,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "wall_seconds": time.perf_counter() - start_time, "device": str(device),
        "torch_version": str(torch.__version__), "epochs_finished": epochs_finished,
        "best_validation_mse": best_val, "parameter_counts": parameter_counts,
        "train_windows": sum(map(len, train_sets)), "validation_windows": sum(map(len, val_sets)),
        "test_windows": sum(map(len, test_sets)), "prediction_rows": len(rows),
        "prediction_rows_skipped_no_history": 0,
        "persistence_climatology_fallback_rows": fallback_rows,
        "persistence_missing_history_policy": "If no discharge is observed in the allowed input history, use the area-scaled global development-training mean; retain every eligible target window",
        "development_train_graphs": [ds.metadata["graph_id"] for ds in train_sets],
        "heldout_test_graphs": [ds.metadata["graph_id"] for ds in test_sets if ds.metadata["spatial_split"] == "heldout"],
        "peak_cuda_memory_bytes": int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else 0,
        "prediction_clipping": "Negative predictions clipped to zero; targets and training loss unmodified",
        "validation_weighting": "Equal graph weights; within each graph, mean over windows and horizons",
        "reused_completed_run": False,
    }
    _write_json(runtime_path, runtime)
    print(f"[{output.name}] Complete: {epochs_finished} epochs, {len(rows)} prediction rows, "
          f"{runtime['wall_seconds']:.1f} seconds.", flush=True)
    return runtime
