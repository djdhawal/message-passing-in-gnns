"""Command line workflow. Run ``python -m river_hybrid --help``."""
from __future__ import annotations

import argparse
from copy import deepcopy
import importlib.metadata
import json
from pathlib import Path
import sys

from .defaults import default_config, smoke_config


def merge(base, extra):
    for key, value in extra.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            merge(base[key], value)
        else:
            base[key] = value
    return base


def config_from(path):
    cfg = default_config()
    if path:
        merge(cfg, json.loads(Path(path).read_text()))
    return cfg


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def run_name(model, setting, alpha, seed, radius):
    alpha_name = f"{float(alpha):g}".replace(".", "p") if model == "hybrid" else "na"
    context = "full" if radius == -1 else str(radius)
    return f"{model}__{setting}__a{alpha_name}__s{seed}__r{context}"


def run_one(processed, runs, cfg, model, setting, alpha, seed, radius):
    from .training import train_run
    name = run_name(model, setting, alpha, seed, radius)
    print(f"Running {name}", flush=True)
    return train_run(
        processed, Path(runs) / name, cfg, model=model, alpha=alpha,
        input_regime=setting, seed=seed, context_radius=radius,
    )


def sweep_specs(cfg, include_baselines=False):
    exp = cfg["experiment"]
    specs = [
        ("hybrid", setting, alpha, seed, -1)
        for setting in exp["input_regimes"]
        for alpha in exp["alphas"] for seed in exp["seeds"]
    ]
    if include_baselines:
        specs += [
            (kind, setting, 0.0, seed, -1)
            for kind in ("local", "pooled")
            for setting in exp["input_regimes"] for seed in exp["seeds"]
        ]
        if "weather_flow" in exp["input_regimes"]:
            specs.append(("persistence", "weather_flow", 0.0, exp["seeds"][0], -1))
    return specs


def execute_specs(specs, processed, runs, cfg, dry_run=False):
    plan = [dict(model=m, input_regime=s, alpha=a, seed=k, context_radius=r,
                 run_id=run_name(m, s, a, k, r)) for m, s, a, k, r in specs]
    if dry_run:
        print(json.dumps({"runs": len(plan), "plan": plan}, indent=2), flush=True)
        return
    name = "ablation_plan.json" if any(s[-1] != -1 for s in specs) else "sweep_plan.json"
    save_json(Path(runs) / name, {"runs": len(plan), "plan": plan})
    print(f"Executing {len(plan)} runs; plan saved to {Path(runs) / name}", flush=True)
    for spec in specs:
        run_one(processed, runs, cfg, *spec)
    collect_runtimes(runs)


def collect_runtimes(runs):
    import pandas as pd
    rows = []
    for path in sorted(Path(runs).glob("*/runtime.json")):
        row = json.loads(path.read_text())
        row.setdefault("run_id", path.parent.name)
        counts = row.get("parameter_counts", {})
        row["parameters"] = counts.get("total", row.get("parameters", 0))
        row["active_parameters"] = counts.get("active", row.get("active_parameters", 0))
        row["epochs"] = row.get("epochs_finished", row.get("epochs", 0))
        curve_path = path.parent / "learningcurve.csv"
        curve = pd.read_csv(curve_path) if curve_path.exists() else pd.DataFrame()
        row["train_seconds"] = float(curve["seconds"].sum()) if "seconds" in curve else 0.0
        rows.append(row)
    if rows:
        pd.DataFrame(rows).to_csv(Path(runs) / "runtimes.csv", index=False)


def ablation_specs(runs, cfg):
    """Freeze a global validation choice before retraining context ablations."""
    import pandas as pd
    frames = []
    for path in sorted(Path(runs).glob("*/predictions.csv")):
        frame = pd.read_csv(path, usecols=["model", "context_radius", "split", "spatial_split",
                            "input_regime", "alpha", "seed", "graph_id", "horizon",
                            "y_true", "y_pred", "train_std"])
        needed = {"model", "context_radius", "split", "spatial_split"}
        if not needed.issubset(frame.columns):
            continue
        frame = frame.loc[(frame.model == "hybrid") & (frame.context_radius == -1)
                          & (frame.split == "val") & (frame.spatial_split == "development")]
        if len(frame):
            frames.append(frame)
    if not frames:
        raise ValueError("Run the full-context hybrid sweep before choosing ablations")
    frame = pd.concat(frames, ignore_index=True)
    frame["sq"] = ((frame.y_pred - frame.y_true) / frame.train_std) ** 2
    graph_error = frame.groupby(["input_regime", "alpha", "seed", "graph_id", "horizon"]).sq.mean().pow(0.5)
    scores = graph_error.groupby(["input_regime", "alpha"]).mean()
    choices, specs = {}, []
    for setting in cfg["experiment"]["input_regimes"]:
        if setting not in scores.index.get_level_values(0):
            raise ValueError(f"No validation predictions for input regime {setting}")
        candidates = scores.loc[setting].sort_index()
        expected = set(map(float, cfg["experiment"]["alphas"]))
        if not expected.issubset(set(map(float, candidates.index))):
            raise ValueError(f"Incomplete validation alpha sweep for {setting}")
        best = float(candidates.idxmin())
        chosen = sorted({0.0, 1.0, best})
        choices[setting] = {"validation_best_alpha": best, "tested_alphas": chosen}
        for alpha in chosen:
            for seed in cfg["experiment"]["seeds"]:
                for radius in cfg["experiment"]["context_radii"]:
                    specs.append(("hybrid", setting, alpha, seed, int(radius)))
    save_json(Path(runs) / "ablation_choices.json", {
        "selection_data": "development validation only; equal outlet/horizon/seed weight",
        "choices": choices,
    })
    return specs


def analyze_runs(processed, runs, out, cfg):
    from .analysis import analyze
    paths = sorted(Path(runs).glob("*/predictions.csv"))
    if not paths:
        raise ValueError("No predictions.csv files found under the runs directory")
    collect_runtimes(runs)
    return analyze(paths, Path(processed) / "graphs.csv", Path(out),
                   bootstrap_samples=cfg["experiment"]["bootstrap_samples"])


def demo(work, full_grid=False):
    from .data import create_fixture, prepare_dataset
    work = Path(work)
    cfg = smoke_config()
    if full_grid:
        cfg["experiment"].update(alphas=[0.0, 0.25, 0.5, 0.75, 1.0], seeds=[42, 43, 44])
    save_json(work / "config.json", cfg)
    create_fixture(work / "raw")
    prepare_dataset(work / "raw", work / "processed", cfg["data"])
    execute_specs(sweep_specs(cfg, True), work / "processed", work / "runs", cfg)
    execute_specs(ablation_specs(work / "runs", cfg), work / "processed", work / "runs", cfg)
    analyze_runs(work / "processed", work / "runs", work / "analysis", cfg)
    print(f"Synthetic plumbing demo complete: {work.resolve()}. These are NOT LamaH research results.")


def prepare_or_reuse(raw, processed, data_config):
    """Re-use immutable prepared data only when its configuration matches."""
    from .data import prepare_dataset
    path = Path(processed) / "manifest.json"
    if not path.exists():
        return prepare_dataset(raw, processed, data_config)
    manifest = json.loads(path.read_text())
    changed = [key for key, value in data_config.items() if manifest["config"].get(key) != value]
    if changed:
        raise ValueError(f"Existing processed data use different settings {changed}; choose a new work directory")
    for graph in manifest["graphs"]:
        if not (Path(processed) / graph["file"]).is_file():
            raise FileNotFoundError(f"Prepared graph file missing: {graph['file']}")
    print(f"Reusing frozen prepared data: {processed}", flush=True)
    return manifest


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor", help="Show installed versions and GPU availability")
    q = sub.add_parser("init-config", help="Write an editable configuration")
    q.add_argument("--output", default="experiment.json"); q.add_argument("--smoke", action="store_true")
    q = sub.add_parser("download", help="Download/check/extract the official daily release (~1.5 GB)")
    q.add_argument("--destination", default="data/raw"); q.add_argument("--archive-only", action="store_true")
    q = sub.add_parser("audit", help="Inspect actual LamaH columns and topology")
    q.add_argument("--raw", required=True); q.add_argument("--output", default="data/audit.json")
    q = sub.add_parser("prepare", help="Select graphs, split catchments, fit training-only preprocessing")
    q.add_argument("--raw", required=True); q.add_argument("--processed", default="data/processed")
    q.add_argument("--config")
    for command in ("train", "sweep", "ablate", "analyze"):
        q = sub.add_parser(command)
        q.add_argument("--processed", default="data/processed")
        q.add_argument("--runs", default="results/runs"); q.add_argument("--config")
        if command in ("sweep", "ablate"):
            q.add_argument("--dry-run", action="store_true")
        if command == "sweep":
            q.add_argument("--include-baselines", action="store_true")
        if command == "train":
            q.add_argument("--model", choices=["hybrid", "local", "pooled", "persistence"], default="hybrid")
            q.add_argument("--alpha", type=float, default=0.5)
            q.add_argument("--input-regime", choices=["weather", "weather_flow"], default="weather_flow")
            q.add_argument("--seed", type=int, default=42); q.add_argument("--context-radius", type=int, default=-1)
        if command == "analyze":
            q.add_argument("--output", default="results/analysis")
    q = sub.add_parser("run-all", help="Download if needed, prepare, run sweep/baselines/ablations, analyze")
    q.add_argument("--raw", help="Existing extracted LamaH root; omit to download")
    q.add_argument("--work", default="river_experiment"); q.add_argument("--config")
    q.add_argument("--skip-ablations", action="store_true")
    q = sub.add_parser("demo", help="Small synthetic file-format fixture; not real-data scientific evidence")
    q.add_argument("--work", default="demo_output"); q.add_argument("--full-grid", action="store_true")
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    cfg = config_from(getattr(args, "config", None))
    try:
        if args.command == "doctor":
            versions = {p: importlib.metadata.version(p) for p in ("numpy", "pandas", "torch", "scikit-learn", "matplotlib")}
            import torch
            print(json.dumps({"python": sys.version, "packages": versions, "cuda": torch.cuda.is_available()}, indent=2))
        elif args.command == "init-config":
            if Path(args.output).exists():
                raise FileExistsError(f"Configuration already exists: {args.output}")
            save_json(args.output, smoke_config() if args.smoke else cfg)
        elif args.command == "download":
            from .data import download_lamah
            print(download_lamah(args.destination, extract=not args.archive_only))
        elif args.command == "audit":
            from .data import audit
            print(json.dumps(audit(args.raw, args.output), indent=2))
        elif args.command == "prepare":
            from .data import prepare_dataset
            result = prepare_dataset(args.raw, args.processed, cfg["data"])
            print(f"Prepared data: {Path(args.processed).resolve()}")
        elif args.command == "train":
            run_one(args.processed, args.runs, cfg, args.model, args.input_regime, args.alpha, args.seed, args.context_radius)
            collect_runtimes(args.runs)
        elif args.command == "sweep":
            execute_specs(sweep_specs(cfg, args.include_baselines), args.processed, args.runs, cfg, args.dry_run)
        elif args.command == "ablate":
            execute_specs(ablation_specs(args.runs, cfg), args.processed, args.runs, cfg, args.dry_run)
        elif args.command == "analyze":
            analyze_runs(args.processed, args.runs, args.output, cfg)
        elif args.command == "demo":
            demo(args.work, args.full_grid)
        elif args.command == "run-all":
            from .data import download_lamah, prepare_dataset, audit
            work = Path(args.work)
            raw = Path(args.raw) if args.raw else download_lamah(work / "raw")
            audit(raw, work / "audit.json")
            save_json(work / "config.json", cfg)
            prepare_or_reuse(raw, work / "processed", cfg["data"])
            execute_specs(sweep_specs(cfg, True), work / "processed", work / "runs", cfg)
            if not args.skip_ablations:
                execute_specs(ablation_specs(work / "runs", cfg), work / "processed", work / "runs", cfg)
            analyze_runs(work / "processed", work / "runs", work / "analysis", cfg)
    except (ValueError, FileNotFoundError, FileExistsError, KeyError) as exc:
        raise SystemExit(f"Experiment stopped: {exc}") from exc


if __name__ == "__main__":
    main()
