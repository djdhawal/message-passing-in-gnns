"""LamaH-CE daily-data acquisition, strict schema audit, and preparation.

This reader targets the original LamaH-CE v1.0 daily archive (Zenodo 5153305),
not Extended LamaH-CE or LamaH-Ice. Source schema:
https://zenodo.org/records/5153305
https://essd.copernicus.org/articles/13/4529/2021/
https://aquafetch.readthedocs.io/en/latest/_modules/aqua_fetch/rr/_lamah.html
https://ouyangwenyu.github.io/hydrodataset/api/lamah_ce/

Weather comes exclusively from B intermediate catchments. Physical attributes
are explicitly allowlisted; no supplied flow/climate summary statistics enter
model features. Land-cover attributes are a retrospective CORINE-2012 snapshot.
"""
from __future__ import annotations

import hashlib
import json
import math
import shutil
import tarfile
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

DAILY_URL = "https://zenodo.org/records/5153305/files/2_LamaH-CE_daily.tar.gz"
DAILY_MD5 = "69fd2733e969513403f923ecc5eaa3dc"
BASIN = "B_basins_intermediate_all"
WEATHER_COLUMNS = ["prec", "2m_temp_mean"]
STATIC_COLUMNS = ["area_calc", "elev_mean", "slope_mean"]
EDGE_COLUMNS = ["dist_hdn", "strm_slope"]
PHYSICAL_ALLOWLIST = set(STATIC_COLUMNS + ["forest_fra", "lake_fra", "urban_fra", "elev_med", "elev_std", "elev_ran", "agr_fra", "bare_fra", "glac_fra", "strm_dens"])


def _dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def download_lamah(destination: str | Path, extract: bool = True) -> Path:
    """Download the 1.5-GB official daily archive, verify MD5, optionally extract.

    Partial downloads are never mistaken for complete files. Existing archives
    are always checksum-verified. This function performs network I/O only when
    explicitly called, never during import/audit/preparation.
    """
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / "2_LamaH-CE_daily.tar.gz"
    if not archive.exists():
        partial = archive.with_suffix(archive.suffix + ".part")
        request = urllib.request.Request(DAILY_URL, headers={"User-Agent": "river-hybrid-lab/1.0"})
        with urllib.request.urlopen(request, timeout=120) as response, partial.open("wb") as output:
            shutil.copyfileobj(response, output, length=1024 * 1024)
        partial.rename(archive)
    digest = hashlib.md5()
    with archive.open("rb") as source:
        for block in iter(lambda: source.read(8 * 1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != DAILY_MD5:
        raise ValueError(f"Checksum mismatch for {archive}; expected {DAILY_MD5}. Remove or replace this file before retrying.")
    if extract:
        safe_extract(archive, destination)
        return resolve_root(destination)
    return archive


def safe_extract(archive: str | Path, destination: str | Path) -> None:
    """Extract regular files/directories; reject links, devices and path escapes."""
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:*") as source:
        for member in source:
            target = (destination / member.name).resolve()
            if not target.is_relative_to(destination):
                raise ValueError(f"Unsafe archive path: {member.name}")
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif member.isfile():
                target.parent.mkdir(parents=True, exist_ok=True)
                stream = source.extractfile(member)
                if stream is None:
                    raise ValueError(f"Unreadable archive member: {member.name}")
                with stream, target.open("wb") as output:
                    shutil.copyfileobj(stream, output)
            else:
                raise ValueError(f"Unsupported archive member (links/devices rejected): {member.name}")


def resolve_root(raw_dir: str | Path) -> Path:
    """Accept the extracted root or a parent containing exactly one such root."""
    root = Path(raw_dir).resolve()
    if (root / BASIN).is_dir() and (root / "D_gauges").is_dir():
        return root
    candidates = [p.parent for p in root.rglob(BASIN) if p.is_dir() and (p.parent / "D_gauges").is_dir()]
    if len(candidates) != 1:
        raise FileNotFoundError(f"Expected one extracted LamaH root with {BASIN} and D_gauges under {root}; found {len(candidates)}.")
    return candidates[0]


def read_table(path: str | Path, required: list[str] | tuple[str, ...] = ()) -> pd.DataFrame:
    table = pd.read_csv(path, sep=";", na_values=[-999, -9999, "NA", "NaN"], low_memory=False)
    table.columns = table.columns.str.strip()
    missing = set(required) - set(table.columns)
    if missing:
        raise ValueError(f"{path}: missing columns {sorted(missing)}; found {table.columns.tolist()}. This reader expects original LamaH-CE daily v1.0.")
    return table


def _indexed(path: Path, required: list[str]) -> pd.DataFrame:
    frame = read_table(path, ["ID", *required])
    frame["ID"] = pd.to_numeric(frame["ID"], errors="raise").astype(int)
    if frame["ID"].duplicated().any():
        raise ValueError(f"Duplicate station ID in {path}")
    return frame.set_index("ID")


def read_daily(path: str | Path, columns: list[str]) -> pd.DataFrame:
    frame = read_table(path, ["YYYY", "MM", "DD", *columns])
    dates = pd.to_datetime(dict(year=frame.YYYY, month=frame.MM, day=frame.DD), errors="raise")
    if dates.duplicated().any():
        raise ValueError(f"Duplicate daily timestamp in {path}")
    frame.index = dates
    return frame.sort_index()


def flow_validity(frame: pd.DataFrame, quality: str = "checked") -> np.ndarray:
    """Mask missing/negative flows and explicitly interpret the source QC flags.

    checked: require ckhs=1; retain statistical warnings (possible real extremes).
    strict: checked plus exclude qceq=1 and qcol=1 if those columns exist.
    basic: retain unchecked observations, exclude suspect qceq/qcol.
    finite: only finite nonnegative flow, for an explicit sensitivity analysis.
    qceq is a constant-run warning, not a missing-value code. qcol marks
    statistical outliers which can include genuine rare low/high flow events.
    Unknown/missing ckhs flags fail the checked/strict policies.
    """
    if quality not in {"checked", "strict", "basic", "finite"}:
        raise ValueError(f"Unknown quality policy: {quality}")
    q = pd.to_numeric(frame["qobs"], errors="coerce").to_numpy(float)
    valid = np.isfinite(q) & (q >= 0)
    if quality in {"checked", "strict"}:
        if "ckhs" not in frame:
            raise ValueError("quality='checked' requires the LamaH ckhs flag")
        valid &= pd.to_numeric(frame.ckhs, errors="coerce").eq(1).to_numpy()
    if quality in {"basic", "strict"}:
        for flag in ("qceq", "qcol"):
            if flag in frame:
                values = pd.to_numeric(frame[flag], errors="coerce")
                valid &= values.eq(0).to_numpy()
    return valid


def audit(raw_dir: str | Path, output: str | Path | None = None) -> dict[str, Any]:
    root = resolve_root(raw_dir)
    attr_dir = root / BASIN / "1_attributes"
    tables = {
        "catchment": _indexed(attr_dir / "Catchment_attributes.csv", STATIC_COLUMNS),
        "hierarchy": _indexed(attr_dir / "Gauge_hierarchy.csv", ["NEXTDOWNID"]),
        "stream": _indexed(attr_dir / "Stream_dist.csv", ["NEXTDOWNID", *EDGE_COLUMNS]),
        "gauge": _indexed(root / "D_gauges/1_attributes/Gauge_attributes.csv", []),
    }
    weather_files = {int(p.stem[3:]): p for p in (root / BASIN / "2_timeseries/daily").glob("ID_*.csv")}
    flow_files = {int(p.stem[3:]): p for p in (root / "D_gauges/2_timeseries/daily").glob("ID_*.csv")}
    if not weather_files or not flow_files:
        raise ValueError("No daily ID_<gauge>.csv files found in the expected folders")
    weather_example = read_daily(weather_files[min(weather_files)], WEATHER_COLUMNS)
    flow_example = read_daily(flow_files[min(flow_files)], ["qobs", "ckhs"])
    transfer_file = attr_dir / "Crossbasin_water_transfers.csv"
    transfers = read_table(transfer_file, ["ID", "To_ID"]) if transfer_file.exists() else pd.DataFrame(columns=["ID", "To_ID"])
    _, _, parent_rivers = _network(tables["hierarchy"])
    parent_links = sorted({tuple(sorted((parent_rivers[int(a)], parent_rivers[int(b)])))
                           for a, b in zip(transfers.ID, transfers.To_ID)
                           if int(a) in parent_rivers and int(b) in parent_rivers
                           and parent_rivers[int(a)] != parent_rivers[int(b)]})
    result = {
        "root": str(root), "source": DAILY_URL, "archive_md5": DAILY_MD5,
        "weather_files": len(weather_files), "flow_files": len(flow_files),
        "table_columns": {name: frame.columns.tolist() for name, frame in tables.items()},
        "weather_columns": weather_example.columns.tolist(), "flow_columns": flow_example.columns.tolist(),
        "weather_example_dates": [str(weather_example.index.min().date()), str(weather_example.index.max().date())],
        "flow_example_dates": [str(flow_example.index.min().date()), str(flow_example.index.max().date())],
        "missing_weather_ids": sorted(set(tables["hierarchy"].index) - set(weather_files)),
        "missing_flow_ids": sorted(set(tables["hierarchy"].index) - set(flow_files)),
        "source_units": {"prec": "mm/day", "2m_temp_mean": "degC", "qobs": "m3/s", "area_calc": "km2", "dist_hdn": "km", "strm_slope": "m/km"},
        "units_source": "https://essd.copernicus.org/articles/13/4529/2021/ (Appendix A1--A3)",
        "crossbasin_transfer_records": len(transfers),
        "crossbasin_transfer_parent_links": parent_links,
        "gauge_impact_counts": tables["gauge"]["degimpact"].value_counts().to_dict() if "degimpact" in tables["gauge"] else {},
        "impact_codes": {"u": "uninfluenced", "l": "low", "m": "moderate", "s": "strong", "x": "not considered in basin delineation"},
        "physical_network_note": "Gauge topology is a tree representation. Cross-basin transfers and regulation can violate hydraulic tree assumptions; terminal river groups are not guaranteed physically independent.",
        "scope": "Header/schema audit plus one time series from each source; preparation validates every selected series.",
    }
    if output:
        _dump(Path(output), result)
    return result


DEFAULT_CONFIG = {
    "seed": 42, "train_start": "1981-01-01", "train_end": "1999-12-31",
    "val_start": "2000-01-01", "val_end": "2005-12-31",
    "test_start": "2006-01-01", "test_end": "2017-12-31",
    "min_nodes": 5, "max_nodes": 64, "max_depth": 8, "max_graphs": 32,
    "heldout_fraction": 0.2, "quality": "checked", "min_train_flow_days": 365,
    "min_weather_coverage": 0.95, "weather_columns": WEATHER_COLUMNS,
    "static_columns": STATIC_COLUMNS, "history": 90, "horizons": [1, 3, 7],
    "excluded_impact_classes": [],
}


def _network(hierarchy: pd.DataFrame) -> tuple[dict[int, int], dict[int, list[int]], dict[int, int]]:
    """Validate an acyclic downstream functional graph and identify parent rivers."""
    downstream = {}
    for node, value in hierarchy.NEXTDOWNID.items():
        if pd.isna(value):
            raise ValueError(f"Missing NEXTDOWNID at gauge {node}; use the source zero sentinel for outlets")
        downstream[int(node)] = int(value)
    known = set(downstream)
    for node, target in downstream.items():
        if target != 0 and target not in known:
            raise ValueError(f"Gauge {node} points to unknown downstream gauge {target}; refusing an incomplete topology")
    upstream: dict[int, list[int]] = {node: [] for node in known}
    for node, target in downstream.items():
        if target:
            upstream[target].append(node)
    parents: dict[int, int] = {}
    for start in known:
        seen, path, node = set(), [], start
        while node not in parents and downstream[node] != 0:
            if node in seen:
                raise ValueError(f"Directed cycle detected from gauge {start}")
            seen.add(node)
            path.append(node)
            node = downstream[node]
        terminal = parents.get(node, node)
        parents[node] = terminal
        for member in path:
            parents[member] = terminal
    return downstream, upstream, parents


def _upstream_nodes(outlet: int, upstream: dict[int, list[int]]) -> tuple[list[int], dict[int, int]]:
    depth, queue = {outlet: 0}, [outlet]
    for node in queue:
        for source in upstream[node]:
            depth[source] = depth[node] + 1
            queue.append(source)
    return sorted(depth), depth


def _stats(values: np.ndarray, name: str) -> dict[str, Any]:
    flat = np.asarray(values, dtype=float)
    if flat.ndim == 1:
        flat = flat[:, None]
    if np.any(np.isfinite(flat).sum(axis=0) == 0):
        raise ValueError(f"No finite development-training observations for {name}")
    mean = np.nanmean(flat, axis=0)
    std = np.nanstd(flat, axis=0)
    std = np.where(std > 1e-8, std, 1.0)
    return {"mean": mean.tolist(), "std": std.tolist()}


def _standardize(values: np.ndarray, stats: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    mask = np.isfinite(values)
    normalized = (values - np.asarray(stats["mean"])) / np.asarray(stats["std"])
    return np.where(mask, normalized, 0).astype(np.float32), mask


def _select_disjoint(candidates: list[dict[str, Any]], limit: int, seed: int) -> list[dict[str, Any]]:
    """Round-robin structural bins; whole upstream sets are retained or rejected."""
    rng = np.random.default_rng(seed)
    bins: dict[tuple[int, int], list[dict[str, Any]]] = defaultdict(list)
    for graph in candidates:
        bins[(graph["depth"] // 2, int(graph["max_branching"] > 2))].append(graph)
    for group in bins.values():
        rng.shuffle(group)
        group.sort(key=lambda g: g["n_nodes"], reverse=True)
    selected, used = [], set()
    keys = sorted(bins)
    while any(bins.values()) and len(selected) < limit:
        for key in keys:
            while bins[key]:
                graph = bins[key].pop(0)
                if not used.intersection(graph["nodes"]):
                    selected.append(graph)
                    used.update(graph["nodes"])
                    break
            if len(selected) >= limit:
                break
    return selected


def _transfer_groups(parents: dict[int, int], transfers: pd.DataFrame) -> dict[int, int]:
    """Union terminal river groups connected by known artificial transfers."""
    leader = {p: p for p in set(parents.values())}

    def find(value: int) -> int:
        while leader[value] != value:
            leader[value] = leader[leader[value]]
            value = leader[value]
        return value

    for source, target in zip(transfers.ID, transfers.To_ID):
        source, target = int(source), int(target)
        if source not in parents or target not in parents:
            continue
        first, second = find(parents[source]), find(parents[target])
        if first != second:
            leader[max(first, second)] = min(first, second)
    return {node: find(parent) for node, parent in parents.items()}


def _choose_holdout(graphs: list[dict[str, Any]], fraction: float, seed: int) -> set[str]:
    """Closest graph-count fraction subject to whole-group and support constraints.

    Dynamic programming avoids choosing one dominant river group when that
    would consume most graphs. If five groups exist, reserve at least two for
    transfer evaluation and at least three for development/selection.
    """
    counts: dict[str, int] = defaultdict(int)
    for graph in graphs:
        counts[graph["basin_id"]] += 1
    groups = sorted(counts)
    if len(groups) < 2:
        raise ValueError("Spatial evaluation needs at least two transfer-connected river groups")
    rng = np.random.default_rng(seed)
    rng.shuffle(groups)
    # (graph count, group count) -> one seeded representative group subset.
    states: dict[tuple[int, int], tuple[str, ...]] = {(0, 0): ()}
    for group in groups:
        for (size, number), selected in list(states.items()):
            states.setdefault((size + counts[group], number + 1), (*selected, group))
    min_heldout = 2 if len(groups) >= 5 else 1
    min_development = 3 if len(groups) >= 5 else 1
    feasible = [(key, value) for key, value in states.items()
                if min_heldout <= key[1] <= len(groups) - min_development]
    (_, _), chosen = min(feasible, key=lambda item: (abs(item[0][0] - fraction * len(graphs)),
                                                   abs(item[0][1] - fraction * len(groups)),
                                                   item[0][0]))
    return set(chosen)


def prepare_dataset(raw_dir: str | Path, out_dir: str | Path, config: dict[str, Any] | None = None) -> dict[str, Any]:
    """Prepare complete, gauge-disjoint upstream trees and leakage-controlled arrays.

    All model scalers use development graphs and training dates only. Heldout
    parent rivers never contribute observations or static values to fitting.
    Graph selection uses structural information and training-period availability,
    never validation/test discharge values. Missing inputs become normalized zero
    plus an observation mask; missing targets stay NaN. No interpolation is used.
    """
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    dates = pd.date_range(cfg["train_start"], cfg["test_end"], freq="D")
    boundaries = [pd.Timestamp(cfg[k]) for k in ("train_start", "train_end", "val_start", "val_end", "test_start", "test_end")]
    if not (boundaries[0] <= boundaries[1] < boundaries[2] <= boundaries[3] < boundaries[4] <= boundaries[5]):
        raise ValueError("Expected ordered, nonoverlapping train/validation/test date ranges")
    if not 0 < cfg["heldout_fraction"] < 1:
        raise ValueError("heldout_fraction must be between zero and one")
    if set(cfg["static_columns"]) - PHYSICAL_ALLOWLIST:
        raise ValueError("Static features must come from PHYSICAL_ALLOWLIST; full-record climatic/hydrological signatures are prohibited")
    root, out_dir = resolve_root(raw_dir), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if (out_dir / "manifest.json").exists():
        raise FileExistsError(f"{out_dir}/manifest.json already exists; use a new output directory to preserve a fixed split")
    schema = audit(root)
    attr_dir = root / BASIN / "1_attributes"
    catchment = _indexed(attr_dir / "Catchment_attributes.csv", cfg["static_columns"])
    hierarchy = _indexed(attr_dir / "Gauge_hierarchy.csv", ["NEXTDOWNID"])
    stream = _indexed(attr_dir / "Stream_dist.csv", ["NEXTDOWNID", *EDGE_COLUMNS])
    gauge = _indexed(root / "D_gauges/1_attributes/Gauge_attributes.csv", [])
    transfer_file = attr_dir / "Crossbasin_water_transfers.csv"
    transfers = read_table(transfer_file, ["ID", "To_ID"]) if transfer_file.exists() else pd.DataFrame(columns=["ID", "To_ID"])
    transfer_nodes = set(transfers.ID.dropna().astype(int)) | set(transfers.To_ID.dropna().astype(int))
    excluded_impacts = set(cfg["excluded_impact_classes"])
    if excluded_impacts - {"u", "l", "m", "s", "x"}:
        raise ValueError("excluded_impact_classes accepts only source codes u,l,m,s,x")
    if excluded_impacts and "degimpact" not in gauge:
        raise ValueError("Impact filtering requires the source degimpact column")
    downstream, upstream, parents = _network(hierarchy)
    dependency_groups = _transfer_groups(parents, transfers)
    train = (dates >= boundaries[0]) & (dates <= boundaries[1])
    cache: dict[int, dict[str, Any]] = {}
    rejected: dict[str, str] = {}

    def read_node(node: int) -> dict[str, Any]:
        if node in cache:
            return cache[node]
        weather_frame = read_daily(root / BASIN / "2_timeseries/daily" / f"ID_{node}.csv", cfg["weather_columns"]).reindex(dates)
        flow_frame = read_daily(root / "D_gauges/2_timeseries/daily" / f"ID_{node}.csv", ["qobs"]).reindex(dates)
        weather = weather_frame[cfg["weather_columns"]].apply(pd.to_numeric, errors="coerce").to_numpy(float)
        q = pd.to_numeric(flow_frame.qobs, errors="coerce").to_numpy(float)
        valid = flow_validity(flow_frame, cfg["quality"])
        q[~valid] = np.nan
        static = pd.to_numeric(catchment.loc[node, cfg["static_columns"]], errors="coerce").to_numpy(float)
        area = float(catchment.loc[node, "area_calc"])
        if not math.isfinite(area) or area <= 0:
            raise ValueError(f"Nonpositive/unknown intermediate catchment area for {node}")
        cache[node] = {"weather": weather, "q": q, "static": static, "area": area,
                       "weather_coverage": float(np.isfinite(weather[train]).mean()),
                       "flow_days": int(np.isfinite(q[train]).sum()),
                       "qceq_count": int(pd.to_numeric(flow_frame.get("qceq", pd.Series(dtype=float)), errors="coerce").eq(1).sum()),
                       "qcol_count": int(pd.to_numeric(flow_frame.get("qcol", pd.Series(dtype=float)), errors="coerce").eq(1).sum())}
        return cache[node]

    candidates = []
    for outlet in sorted(downstream):
        nodes, depths = _upstream_nodes(outlet, upstream)
        depth = max(depths.values())
        if not cfg["min_nodes"] <= len(nodes) <= cfg["max_nodes"] or depth > cfg["max_depth"]:
            continue
        try:
            for node in nodes:
                if excluded_impacts and node in gauge.index and str(gauge.loc[node, "degimpact"]).strip() in excluded_impacts:
                    raise ValueError(f"Gauge {node} has excluded impact class {gauge.loc[node, 'degimpact']}; complete upstream tree rejected")
                data = read_node(node)
                if data["weather_coverage"] < cfg["min_weather_coverage"]:
                    raise ValueError(f"Gauge {node} has insufficient training-period weather coverage")
                if node != outlet:
                    if node not in stream.index or int(stream.loc[node, "NEXTDOWNID"]) != downstream[node]:
                        raise ValueError(f"Hierarchy/stream mismatch at {node}")
                    attrs = pd.to_numeric(stream.loc[node, EDGE_COLUMNS], errors="coerce").to_numpy(float)
                    if not np.isfinite(attrs).all() or attrs[0] <= 0:
                        raise ValueError(f"Gauge {node} has missing/invalid river length or slope")
            if read_node(outlet)["flow_days"] < cfg["min_train_flow_days"]:
                raise ValueError("Outlet has too few valid training discharge observations")
        except (FileNotFoundError, KeyError, ValueError) as error:
            rejected[str(outlet)] = str(error)
            continue
        branches = [len(upstream[node]) for node in nodes]
        candidates.append({"graph_id": str(outlet), "basin_id": str(dependency_groups[outlet]),
                           "terminal_basin_id": str(parents[outlet]), "nodes": nodes,
                           "n_nodes": len(nodes), "depth": depth, "max_branching": max(branches),
                           "mean_branching": float(np.mean([b for b in branches if b] or [0])),
                           "strong_impact_fraction": float(np.mean([str(gauge.loc[node].get("degimpact", "")) == "s" if node in gauge.index else False for node in nodes])),
                           "transfer_endpoint_count": int(len(set(nodes) & transfer_nodes)),
                           "river_length_km": float(sum(float(stream.loc[node, "dist_hdn"]) for node in nodes if node != outlet)),
                           "drainage_area_km2": float(sum(read_node(node)["area"] for node in nodes))})
    selected = _select_disjoint(candidates, int(cfg["max_graphs"]), int(cfg["seed"]))
    groups = sorted({g["basin_id"] for g in selected})
    if len(groups) < 2:
        _dump(out_dir / "preparation_failure.json", {"n_candidates": len(candidates), "n_selected": len(selected), "parent_groups": groups, "rejected_outlets": rejected})
        raise ValueError("Fewer than two distinct parent river groups survived selection. No valid spatial split can be made; inspect preparation_failure.json and adjust structural/availability caps.")
    heldout = _choose_holdout(selected, cfg["heldout_fraction"], cfg["seed"])
    for graph in selected:
        graph["spatial_split"] = "heldout" if graph["basin_id"] in heldout else "development"
    development_nodes = sorted({n for g in selected if g["spatial_split"] == "development" for n in g["nodes"]})
    weather_stats = _stats(np.concatenate([cache[n]["weather"][train] for n in development_nodes]), "weather")
    static_stats = _stats(np.stack([cache[n]["static"] for n in development_nodes]), "static")
    development_edges = [node for graph in selected if graph["spatial_split"] == "development"
                         for node in graph["nodes"] if node != int(graph["graph_id"])]
    edge_values = stream.loc[development_edges, EDGE_COLUMNS].to_numpy(float)
    edge_scale = np.maximum(np.sqrt(np.mean(edge_values ** 2, axis=0)), 1e-6)
    edge_stats = {"scale": edge_scale.tolist(), "method": "scale-only per-column RMS",
                  "fit": "development graph edges only", "raw_units": ["km", "m/km"]}
    upstream_areas = {}
    for graph in selected:
        for node in graph["nodes"]:
            ancestors, _ = _upstream_nodes(node, upstream)
            upstream_areas[node] = sum(cache[a]["area"] for a in ancestors)
    specific_flow = np.concatenate([cache[n]["q"][train] * 86.4 / upstream_areas[n] for n in development_nodes])
    valid_specific = specific_flow[np.isfinite(specific_flow)]
    if valid_specific.size == 0 or np.std(valid_specific) <= 1e-8:
        raise ValueError("Development-training specific discharge has no usable variance")
    target_stats = {"mean": float(valid_specific.mean()), "std": float(valid_specific.std()),
                    "q90": float(np.quantile(valid_specific, 0.9)), "units": "mm/day",
                    "fit": "all development nodes on training dates only"}
    metadata = []
    (out_dir / "graphs").mkdir(exist_ok=True)
    for graph in selected:
        nodes, outlet = graph.pop("nodes"), int(graph["graph_id"])
        index = {node: i for i, node in enumerate(nodes)}
        n = len(nodes)
        weather, weather_mask = _standardize(np.stack([cache[node]["weather"] for node in nodes], axis=1), weather_stats)
        static, static_mask = _standardize(np.stack([cache[node]["static"] for node in nodes]), static_stats)
        q_raw = np.stack([cache[node]["q"] for node in nodes], axis=1)
        area = np.asarray([upstream_areas[node] for node in nodes], dtype=np.float32)
        specific_q = q_raw * 86.4 / area[None, :]
        flow_mask = np.isfinite(specific_q)[..., None]
        flow = np.where(flow_mask, (specific_q[..., None] - target_stats["mean"]) / target_stats["std"], 0).astype(np.float32)
        sources = [node for node in nodes if node != outlet]
        edge_index = np.asarray([[index[node], index[downstream[node]]] for node in sources], dtype=np.int64).T
        edge_attr_raw = np.asarray([stream.loc[node, EDGE_COLUMNS].to_numpy(float) for node in sources], dtype=np.float32)
        ancestor_dist = np.full((n, n), -1, dtype=np.int64)
        pair_attr_raw = np.zeros((n, n, 2), dtype=np.float32)
        for source in nodes:
            node, hops, length, fall = source, 0, 0.0, 0.0
            while node in index:
                ancestor_dist[index[node], index[source]] = hops
                pair_attr_raw[index[node], index[source]] = (length, fall / length if length else 0)
                if node == outlet:
                    break
                segment = float(stream.loc[node, "dist_hdn"])
                length += segment
                fall += segment * float(stream.loc[node, "strm_slope"])
                node, hops = downstream[node], hops + 1
        file = f"graphs/{outlet}.npz"
        edge_attr = (edge_attr_raw / edge_scale).astype(np.float32)
        pair_attr = (pair_attr_raw / edge_scale).astype(np.float32)
        np.savez_compressed(out_dir / file, dates=dates.strftime("%Y-%m-%d").to_numpy(dtype="U10"),
                            node_ids=np.asarray(nodes, dtype=np.int64), weather=weather, weather_mask=weather_mask,
                            flow=flow, flow_mask=flow_mask, q_raw=q_raw.astype(np.float32),
                            static=static, static_mask=static_mask, upstream_area=area,
                            edge_index=edge_index, edge_attr=edge_attr, ancestor_dist=ancestor_dist,
                            pair_attr=pair_attr, edge_attr_raw=edge_attr_raw, pair_attr_raw=pair_attr_raw,
                            outlet_index=np.asarray(index[outlet], dtype=np.int64))
        conversion = graph["drainage_area_km2"] / 86.4
        graph.update({"file": file, "outlet_id": str(outlet), "outlet_index": index[outlet],
                      "train_mean": target_stats["mean"] * conversion,
                      "train_std": target_stats["std"] * conversion,
                      "train_q90": target_stats["q90"] * conversion,
                      "metric_reference": "global development-training specific discharge, area-scaled",
                      "train_prec_mean": float(np.nanmean(cache[outlet]["weather"][train, 0])),
                      "train_temp_mean": float(np.nanmean(cache[outlet]["weather"][train, 1])),
                      "impact_class": str(gauge.loc[outlet].get("degimpact", "unknown")) if outlet in gauge.index else "unknown",
                      "valid_train_targets": int(np.isfinite(q_raw[train, index[outlet]]).sum()),
                      "valid_val_targets": int(np.isfinite(q_raw[(dates >= boundaries[2]) & (dates <= boundaries[3]), index[outlet]]).sum()),
                      "valid_test_targets": int(np.isfinite(q_raw[(dates >= boundaries[4]) & (dates <= boundaries[5]), index[outlet]]).sum()),
                      "outlet_qceq_warning_days": cache[outlet]["qceq_count"],
                      "outlet_qcol_warning_days": cache[outlet]["qcol_count"]})
        metadata.append(graph)
    all_node_ids = [int(n) for row in metadata for n in np.load(out_dir / row["file"], allow_pickle=False)["node_ids"]]
    if len(all_node_ids) != len(set(all_node_ids)):
        raise AssertionError("Selected graphs share gauges")
    manifest = {
        "format_version": 1, "synthetic_fixture": (root / "SYNTHETIC_FIXTURE.json").exists(),
        "source": {"name": "LamaH-CE v1.0", "doi": "10.5281/zenodo.5153305", "url": DAILY_URL,
                   "license": "CC-BY-SA-4.0", "basin_delineation": "B", "raw_root": str(root)},
        "config": cfg, "target_scaler": target_stats, "weather_scaler": weather_stats,
        "static_scaler": static_stats, "edge_scaler": edge_stats,
        "weather_columns": cfg["weather_columns"], "static_columns": cfg["static_columns"],
        "graphs": metadata, "n_candidates": len(candidates), "n_graphs": len(metadata),
        "parent_basin_count": len(groups), "heldout_parent_basins": sorted(heldout),
        "terminal_basin_count": len({g["terminal_basin_id"] for g in metadata}),
        "development_group_count": len(groups) - len(heldout), "heldout_group_count": len(heldout),
        "spatial_split_rule": "Terminal parent rivers linked by listed cross-basin transfers are unioned; whole connected groups are held out. Dynamic programming targets the requested graph-count fraction while keeping at least 2 heldout / 3 development groups when 5+ groups exist. Selected graphs are gauge-disjoint.",
        "physical_network_note": schema["physical_network_note"],
        "crossbasin_transfer_records": schema["crossbasin_transfer_records"],
        "crossbasin_transfer_parent_links": schema["crossbasin_transfer_parent_links"],
        "strongly_impacted_outlet_count": sum(g["impact_class"] == "s" for g in metadata),
        "graphs_with_strongly_impacted_nodes": sum(g["strong_impact_fraction"] > 0 for g in metadata),
        "graphs_with_transfer_endpoints": sum(g["transfer_endpoint_count"] > 0 for g in metadata),
        "heldout_graph_fraction": sum(g["spatial_split"] == "heldout" for g in metadata) / len(metadata),
        "rejected_outlets": rejected,
        "quality_note": "checked keeps ckhs=1 including qceq/qcol warnings because warnings can mark true extreme events; strict removes warning rows",
        "time_note": "Daily timestamp is start of UTC day; issue forecasts after that full day has elapsed. History includes issue day's complete measurements.",
        "edge_units": ["development edge RMS units", "development edge RMS units"],
        "pair_units": ["development edge RMS units", "development edge RMS units"],
        "raw_edge_units": ["km", "m/km"], "raw_pair_units": ["km", "m/km"],
        "normalization_note": "All learned scalers use development training data only; metric thresholds are global specific-discharge references, not per-gauge percentiles.",
    }
    _dump(out_dir / "manifest.json", manifest)
    _dump(out_dir / "schema_audit.json", schema)
    pd.DataFrame(metadata).to_csv(out_dir / "graphs.csv", index=False)
    return manifest


def create_fixture(raw_dir: str | Path, seed: int = 123) -> Path:
    """Create a tiny SYNTHETIC schema fixture, solely for pipeline verification.

    Twelve independent 5--9-node trees over 2000-01-01..2000-06-30. Values are
    invented toy processes, never observations or real hydrological evidence.
    The fixture follows LamaH's columns but is not a replacement for LamaH.
    """
    root = Path(raw_dir)
    if (root / BASIN).exists():
        raise FileExistsError(f"Refusing to replace existing data at {root}")
    for relative in (f"{BASIN}/1_attributes", f"{BASIN}/2_timeseries/daily", "D_gauges/1_attributes", "D_gauges/2_timeseries/daily"):
        (root / relative).mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2000-01-01", "2000-06-30", freq="D")
    base = pd.DataFrame({"YYYY": dates.year, "MM": dates.month, "DD": dates.day, "DOY": dates.dayofyear})
    catches, gauges, hierarchy_rows, streams = [], [], [], []
    for group in range(12):
        n = 5 + group % 5
        ids = [100 * (group + 1) + i for i in range(n)]
        child_map: dict[int, list[int]] = {node: [] for node in ids}
        parent = {ids[0]: 0}
        for i in range(1, n):
            parent[ids[i]] = ids[(i - 1) // 2]
            child_map[parent[ids[i]]].append(ids[i])
        q_by_node, area_by_node = {}, {}
        for i in reversed(range(n)):
            node = ids[i]
            area = float(rng.uniform(20, 100))
            area_by_node[node] = area
            rain = rng.gamma(0.8, 3, len(dates))
            temperature = 5 + 10 * np.sin(np.arange(len(dates)) / 50) + rng.normal(0, 2, len(dates))
            local = np.zeros(len(dates))
            for t in range(1, len(dates)):
                local[t] = 0.85 * local[t - 1] + 0.15 * rain[t] * area / 86.4
            q = local + sum((np.concatenate(([0.0], q_by_node[child][:-1]))
                             for child in child_map[node]), start=np.zeros(len(dates)))
            q = np.maximum(q + 0.05, 0)
            q_by_node[node] = q
            met = base.copy()
            met["prec"], met["2m_temp_mean"] = rain, temperature
            met.to_csv(root / BASIN / "2_timeseries/daily" / f"ID_{node}.csv", sep=";", index=False)
            runoff = base.copy()
            runoff["qobs"], runoff["ckhs"], runoff["qceq"], runoff["qcol"] = q, 1, 0, 0
            if i == n - 1:
                runoff.loc[20, "qobs"] = -999
                runoff.loc[25, "ckhs"] = 0
                runoff.loc[30, "qcol"] = 1
            runoff.to_csv(root / "D_gauges/2_timeseries/daily" / f"ID_{node}.csv", sep=";", index=False)
            catches.append({"ID": node, "area_calc": area, "elev_mean": 250 + i * 100 + group * 5,
                            "slope_mean": 20 + i * 2, "forest_fra": 0.5, "lake_fra": 0.02, "urban_fra": 0.03})
            gauges.append({"ID": node, "degimpact": "l", "region": group + 1})
            hierarchy_rows.append({"ID": node, "NEXTDOWNID": parent[node], "NEXTUPID": ",".join(map(str, child_map[node])) or "0"})
            streams.append({"ID": node, "NEXTDOWNID": parent[node], "dist_hdn": 5 + i if i else -999,
                            "elev_diff": (5 + i) * 3 if i else -999, "strm_slope": 3 if i else -999})
    for filename, rows in [("Catchment_attributes.csv", catches), ("Gauge_hierarchy.csv", hierarchy_rows), ("Stream_dist.csv", streams)]:
        pd.DataFrame(rows).to_csv(root / BASIN / "1_attributes" / filename, sep=";", index=False)
    pd.DataFrame(gauges).to_csv(root / "D_gauges/1_attributes/Gauge_attributes.csv", sep=";", index=False)
    _dump(root / "SYNTHETIC_FIXTURE.json", {"synthetic_fixture": True, "purpose": "plumbing tests only; not real observations", "seed": seed})
    return root
