"""All choices live in a JSON-serializable configuration."""
from copy import deepcopy

DEFAULT = {
    "data": {
        "seed": 42, "train_start": "1981-01-01", "train_end": "1999-12-31",
        "val_start": "2000-01-01", "val_end": "2005-12-31",
        "test_start": "2006-01-01", "test_end": "2017-12-31",
        "min_nodes": 5, "max_nodes": 64, "max_depth": 8, "max_graphs": 32,
        "heldout_fraction": 0.2, "quality": "checked",
        "excluded_impact_classes": [],
        "min_train_flow_days": 365, "min_weather_coverage": 0.95,
        "static_columns": ["area_calc", "elev_mean", "slope_mean"],
    },
    "model": {"hidden_dim": 64, "layers": 8, "heads": 4, "dropout": 0.1},
    "training": {
        "history": 90, "horizons": [1, 3, 7], "batch_size": 16,
        "epochs": 50, "patience": 8, "learning_rate": 0.001,
        "weight_decay": 0.0001, "train_stride": 7, "eval_stride": 1,
        "device": "auto", "threads": 2,
        "max_train_windows_per_graph": None, "max_eval_windows_per_graph": None,
    },
    "experiment": {
        "alphas": [0.0, 0.25, 0.5, 0.75, 1.0],
        "input_regimes": ["weather", "weather_flow"], "seeds": [42, 43, 44],
        "context_radii": [0, 2], "bootstrap_samples": 500,
    },
}


def default_config():
    return deepcopy(DEFAULT)


def smoke_config():
    cfg = default_config()
    cfg["data"].update(
        train_start="2000-01-01", train_end="2000-03-31",
        val_start="2000-04-01", val_end="2000-04-30",
        test_start="2000-05-01", test_end="2000-06-30",
        min_nodes=3, max_nodes=32, max_depth=4, max_graphs=12,
        min_train_flow_days=30, min_weather_coverage=0.8,
    )
    cfg["model"].update(hidden_dim=16, layers=4, heads=2, dropout=0.0)
    cfg["training"].update(
        history=7, epochs=2, patience=2, batch_size=8, device="cpu",
        train_stride=7, eval_stride=7,
        max_train_windows_per_graph=8, max_eval_windows_per_graph=6,
    )
    cfg["experiment"].update(alphas=[0.0, 0.5, 1.0], seeds=[42], bootstrap_samples=50)
    return cfg
