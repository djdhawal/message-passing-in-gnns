"""Reproducible local/global river forecasting experiments."""

__version__ = "0.1.0"
