"""Leakage-aware evaluation for the LamaH local/global mixing experiment.

Prediction CSVs contain raw discharge. ``train_*`` columns must be the frozen
statistics supplied by preparation/training, never recomputed on validation or
held-out basins here. The selector is fitted only to development validation
losses; spatial-test labels enter only final evaluation. Alpha is a branch
coefficient, not an estimate of causal contribution or compute allocation.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

PREDICTION_COLUMNS = [
    "graph_id", "basin_id", "spatial_split", "split", "input_regime", "model",
    "alpha", "seed", "horizon", "target_date", "y_true", "y_pred", "train_mean",
    "train_std", "train_q90", "context_radius", "run_id",
]
METRIC_GROUPS = [
    "graph_id", "basin_id", "spatial_split", "split", "input_regime", "model",
    "alpha", "seed", "horizon", "context_radius", "run_id",
]
TASK_KEYS = ["graph_id", "basin_id", "input_regime", "horizon"]
FEATURE_NAMES = [
    "depth", "mean_branching", "log_n_nodes", "log_river_length_km",
    "log_drainage_area_km2", "horizon", "has_flow_history",
]


def _require(frame: pd.DataFrame, columns: Iterable[str], name: str) -> None:
    missing = sorted(set(columns) - set(frame.columns))
    if missing:
        raise ValueError(f"{name} is missing columns: {missing}")


def load_predictions(paths: Iterable[str | Path]) -> pd.DataFrame:
    paths = [Path(p) for p in paths]
    if not paths:
        raise ValueError("No prediction CSVs supplied. Run training/evaluation first.")
    frames = [pd.read_csv(p, dtype={"graph_id": str, "basin_id": str, "run_id": str}) for p in paths]
    frame = pd.concat(frames, ignore_index=True)
    return validate_predictions(frame)


def validate_predictions(frame: pd.DataFrame) -> pd.DataFrame:
    """Reject duplicate forecast records and inconsistent labels/statistics."""
    _require(frame, PREDICTION_COLUMNS, "Predictions")
    if frame.empty:
        raise ValueError("Predictions are empty.")
    p = frame.copy()
    for column in ["graph_id", "basin_id", "run_id"]:
        p[column] = p[column].astype(str)
    for column in ["y_true", "y_pred", "train_mean", "train_std", "train_q90", "alpha"]:
        p[column] = pd.to_numeric(p[column], errors="raise")
    for column in ["seed", "horizon", "context_radius"]:
        numbers = pd.to_numeric(p[column], errors="raise")
        if not np.all(numbers == numbers.astype(int)):
            raise ValueError(f"{column} must contain integers.")
        p[column] = numbers.astype(int)
    p["target_date"] = pd.to_datetime(p["target_date"], errors="raise").dt.normalize()
    if p["target_date"].isna().any():
        raise ValueError("target_date contains missing dates.")
    numerical = ["y_true", "y_pred", "train_mean", "train_std", "train_q90"]
    if not np.isfinite(p[numerical].to_numpy()).all():
        raise ValueError("Predictions and training statistics must all be finite.")
    if (p.train_std <= 0).any():
        raise ValueError("train_std must be strictly positive and fitted on training data.")
    if not set(p.spatial_split).issubset({"development", "heldout"}):
        raise ValueError("spatial_split must be development or heldout.")
    if not set(p.split).issubset({"val", "test"}):
        raise ValueError("Analysis accepts only val/test predictions.")
    if not set(p.input_regime).issubset({"weather", "weather_flow"}):
        raise ValueError("input_regime must be weather or weather_flow.")
    hybrid = p.model.eq("hybrid")
    if p.loc[hybrid, "alpha"].isna().any() or not p.loc[hybrid, "alpha"].between(0, 1).all():
        raise ValueError("Every hybrid prediction needs alpha in [0, 1].")
    if (p.horizon < 1).any():
        raise ValueError("Forecast horizons must be positive.")
    identities = ["run_id", "graph_id", "split", "horizon", "target_date"]
    if p.duplicated(identities).any():
        raise ValueError("Duplicate forecast records: pass each run's prediction CSV exactly once.")
    for run, g in p.groupby("run_id", sort=False):
        for c in ["input_regime", "model", "alpha", "seed", "context_radius"]:
            if g[c].nunique(dropna=False) != 1:
                raise ValueError(f"Run {run} contains inconsistent {c} metadata.")
    labels = p.groupby(["graph_id", "horizon", "target_date"], dropna=False)
    if (labels.y_true.nunique() > 1).any():
        raise ValueError("Models disagree on the true value of the same forecast target.")
    for c in ["train_mean", "train_std", "train_q90", "basin_id", "spatial_split"]:
        if (p.groupby("graph_id")[c].nunique(dropna=False) > 1).any():
            raise ValueError(f"Graph-level {c} is inconsistent across runs.")
    # Every candidate model must be measured on the same dates for each task.
    # This is evaluated within a partition/task, not between distinct basins.
    by_task = ["graph_id", "spatial_split", "split", "input_regime", "horizon"]
    for task, g in p.groupby(by_task, sort=False):
        date_sets = g.groupby("run_id").target_date.apply(lambda x: frozenset(x))
        if len(set(date_sets)) != 1:
            raise ValueError(f"Runs do not share forecast dates for task {task}; compare common complete predictions.")
    return p


def compute_metrics(predictions: pd.DataFrame, *, _validated: bool = False) -> pd.DataFrame:
    """Per-outlet metrics; a zero-variance observed series has undefined NSE."""
    p = predictions if _validated else validate_predictions(predictions)
    rows = []
    for keys, g in p.groupby(METRIC_GROUPS, dropna=False, sort=True):
        y = g.y_true.to_numpy(dtype=float)
        error = g.y_pred.to_numpy(dtype=float) - y
        denominator = float(np.sum((y - y.mean()) ** 2))
        high = y >= float(g.train_q90.iloc[0])
        mse = float(np.mean(error ** 2))
        rows.append({
            **dict(zip(METRIC_GROUPS, keys)), "n": len(g),
            "rmse": float(np.sqrt(mse)), "mae": float(np.mean(np.abs(error))),
            "nrmse": float(np.sqrt(np.mean((error / g.train_std.to_numpy()) ** 2))),
            "nse": 1.0 - float(np.sum(error ** 2)) / denominator if denominator > 0 else np.nan,
            "high_flow_n": int(high.sum()),
            "high_flow_rmse": float(np.sqrt(np.mean(error[high] ** 2))) if high.any() else np.nan,
            "high_flow_mae": float(np.mean(np.abs(error[high]))) if high.any() else np.nan,
        })
    return pd.DataFrame(rows)


def alpha_curve_table(metrics: pd.DataFrame) -> pd.DataFrame:
    """Per-graph curves: error bars describe seed variability, not basin uncertainty."""
    m = metrics[(metrics.model == "hybrid") & (metrics.context_radius == -1)]
    keys = ["graph_id", "basin_id", "spatial_split", "split", "input_regime", "horizon", "alpha"]
    return m.groupby(keys, dropna=False).nrmse.agg(
        mean_nrmse="mean", seed_sd="std", n_seeds="count"
    ).reset_index()


def near_optimal_alpha_table(metrics: pd.DataFrame, relative_tolerance: float = 0.02) -> pd.DataFrame:
    """Report all weights within a declared relative tolerance of validation best.

    This is a descriptive tolerance, not a statistical equivalence test.
    """
    if relative_tolerance < 0:
        raise ValueError("relative_tolerance must be nonnegative.")
    curves = alpha_curve_table(metrics)
    curves = curves[(curves.spatial_split == "development") & (curves.split == "val")].copy()
    keys = ["graph_id", "basin_id", "input_regime", "horizon"]
    curves["best_validation_nrmse"] = curves.groupby(keys).mean_nrmse.transform("min")
    threshold = curves.best_validation_nrmse * (1 + relative_tolerance) + 1e-12
    curves["near_optimal"] = curves.mean_nrmse <= threshold
    curves["relative_tolerance"] = relative_tolerance
    return curves


def _graph_features(tasks: pd.DataFrame, graphs: pd.DataFrame) -> pd.DataFrame:
    required = ["graph_id", "basin_id", "spatial_split", "n_nodes", "depth", "mean_branching",
                "river_length_km", "drainage_area_km2"]
    _require(graphs, required, "Graph metadata")
    if graphs.graph_id.duplicated().any():
        raise ValueError("Graph metadata needs exactly one row per graph_id.")
    metadata = graphs.copy()
    metadata["graph_id"] = metadata.graph_id.astype(str)
    metadata["basin_id"] = metadata.basin_id.astype(str)
    columns = [c for c in required if c != "spatial_split"]
    merged = tasks.merge(metadata[columns], on=["graph_id", "basin_id"], how="left", validate="many_to_one")
    for c in ["n_nodes", "depth", "mean_branching", "river_length_km", "drainage_area_km2"]:
        merged[c] = pd.to_numeric(merged[c], errors="raise")
    if not np.isfinite(merged[["n_nodes", "depth", "mean_branching", "river_length_km", "drainage_area_km2"]]).all().all():
        raise ValueError("Missing/nonfinite structural features: audit graph metadata before fitting the selector.")
    if (merged[["n_nodes", "depth", "mean_branching", "river_length_km", "drainage_area_km2"]] < 0).any().any():
        raise ValueError("Structural features must be nonnegative.")
    merged["log_n_nodes"] = np.log1p(merged.n_nodes)
    merged["log_river_length_km"] = np.log1p(merged.river_length_km)
    merged["log_drainage_area_km2"] = np.log1p(merged.drainage_area_km2)
    merged["has_flow_history"] = merged.input_regime.eq("weather_flow").astype(float)
    return merged[FEATURE_NAMES].astype(float)


def fit_selector(metrics: pd.DataFrame, graphs: pd.DataFrame, seed: int = 1729) -> dict:
    """Fit one multi-output tree to validation loss at each tested alpha.

    Each (graph, input regime, horizon) is a row. GroupKFold keeps *all* tasks
    from an independent basin together. Held-out metrics never enter fitting.
    """
    from sklearn.model_selection import GroupKFold
    from sklearn.tree import DecisionTreeRegressor, export_text

    m = metrics[(metrics.model == "hybrid") & (metrics.context_radius == -1)
                & (metrics.spatial_split == "development") & (metrics.split == "val")].copy()
    if m.empty:
        raise ValueError("Selector requires development-validation hybrid predictions.")
    if m.basin_id.nunique() < 3:
        raise ValueError("Selector requires at least three development basin groups for grouped cross-validation.")
    alphas = sorted(float(a) for a in m.alpha.unique())
    if len(alphas) < 2:
        raise ValueError("Selector requires at least two tested alpha values.")
    # Equal seed support is needed before treating candidates as comparable.
    seed_sets = m.groupby(TASK_KEYS + ["alpha"]).seed.apply(lambda x: frozenset(x))
    for task, values in seed_sets.groupby(level=list(range(len(TASK_KEYS)))):
        if len(set(values)) != 1:
            raise ValueError(f"Alpha candidates have different seed support for {task}.")
    losses = m.groupby(TASK_KEYS + ["alpha"]).nrmse.mean().unstack("alpha").reindex(columns=alphas)
    if losses.isna().any().any():
        raise ValueError("Development validation has incomplete alpha curves; finish every candidate before selection.")
    tasks = losses.index.to_frame(index=False)
    X = _graph_features(tasks, graphs)
    Y = losses.to_numpy()
    groups = tasks.basin_id.to_numpy()
    splitter = GroupKFold(n_splits=min(5, len(set(groups))))
    folds = list(splitter.split(X, Y, groups=groups))
    fold_groups = [{"train_basins": sorted(set(groups[tr])), "validation_basins": sorted(set(groups[va]))}
                   for tr, va in folds]
    candidates = []
    for depth in [1, 2, 3]:
        for minimum_leaf in [1, 3, 5]:
            losses_by_fold = []
            for tr, va in folds:
                model = DecisionTreeRegressor(max_depth=depth, min_samples_leaf=minimum_leaf, random_state=seed)
                model.fit(X.iloc[tr], Y[tr])
                indices = np.argmin(model.predict(X.iloc[va]), axis=1)
                losses_by_fold.append(float(Y[va, indices].mean()))
            candidates.append({"max_depth": depth, "min_samples_leaf": minimum_leaf,
                               "cv_nrmse": float(np.mean(losses_by_fold))})
    best = min(candidates, key=lambda r: (r["cv_nrmse"], r["max_depth"], -r["min_samples_leaf"]))
    model = DecisionTreeRegressor(max_depth=best["max_depth"], min_samples_leaf=best["min_samples_leaf"], random_state=seed)
    model.fit(X, Y)
    # Each task type gets a development-selected uniform alpha. This is a
    # stronger comparator than forcing one alpha across unlike input regimes.
    fixed = []
    means = m.groupby(["graph_id", "input_regime", "horizon", "alpha"]).nrmse.mean().reset_index()
    means = means.groupby(["input_regime", "horizon", "alpha"]).nrmse.mean().reset_index()
    for (regime, horizon), group in means.groupby(["input_regime", "horizon"]):
        winner = group.sort_values(["nrmse", "alpha"]).iloc[0]
        fixed.append({"input_regime": regime, "horizon": int(horizon), "fixed_alpha": float(winner.alpha),
                      "development_validation_nrmse": float(winner.nrmse)})
    return {"model": model, "alphas": alphas, "fixed_choices": pd.DataFrame(fixed),
            "feature_names": FEATURE_NAMES, "cv_results": candidates, "cv_folds": fold_groups,
            "selected_hyperparameters": best,
            "development_basins": sorted(set(groups)),
            "rules": export_text(model, feature_names=FEATURE_NAMES, decimals=6)}


def choose_heldout_alphas(selector: dict, predictions: pd.DataFrame, graphs: pd.DataFrame) -> pd.DataFrame:
    """Generate frozen held-out choices using metadata, never target values."""
    p = predictions[(predictions.model == "hybrid") & (predictions.context_radius == -1)
                    & (predictions.spatial_split == "heldout") & (predictions.split == "test")]
    tasks = p[TASK_KEYS].drop_duplicates().sort_values(TASK_KEYS).reset_index(drop=True)
    if tasks.empty:
        raise ValueError("No spatially held-out test predictions are available.")
    overlap = set(tasks.basin_id) & set(selector["development_basins"])
    if overlap:
        raise ValueError(f"Basin groups appear in both development and held-out partitions: {sorted(overlap)}")
    x = _graph_features(tasks, graphs)
    estimated = selector["model"].predict(x)
    indices = np.argmin(estimated, axis=1)
    tasks["selected_alpha"] = np.asarray(selector["alphas"])[indices]
    tasks = tasks.merge(selector["fixed_choices"], on=["input_regime", "horizon"], how="left", validate="many_to_one")
    if tasks.fixed_alpha.isna().any():
        raise ValueError("Held-out tasks include regimes/horizons absent from development validation.")
    for i, alpha in enumerate(selector["alphas"]):
        tasks[f"predicted_validation_loss_alpha_{alpha:g}"] = estimated[:, i]
    return tasks


def paired_selector_errors(predictions: pd.DataFrame, choices: pd.DataFrame) -> pd.DataFrame:
    """Pair forecasts, then average squared error across matching seeds.

    This evaluates the mean performance of seeded runs, not a prediction ensemble.
    """
    p = predictions[(predictions.model == "hybrid") & (predictions.context_radius == -1)
                    & (predictions.spatial_split == "heldout") & (predictions.split == "test")]
    merged = p.merge(choices[TASK_KEYS + ["selected_alpha", "fixed_alpha"]], on=TASK_KEYS,
                     how="inner", validate="many_to_one")
    paired_keys = TASK_KEYS + ["target_date", "seed"]
    selected = merged[np.isclose(merged.alpha, merged.selected_alpha)].copy()
    fixed = merged[np.isclose(merged.alpha, merged.fixed_alpha)].copy()
    if selected.duplicated(paired_keys).any() or fixed.duplicated(paired_keys).any():
        raise ValueError("Multiple runs have the same seed/candidate/task; remove duplicate runs.")
    if set(map(tuple, selected[paired_keys].to_numpy())) != set(map(tuple, fixed[paired_keys].to_numpy())):
        raise ValueError("Selected and fixed alpha forecasts must have exactly matching dates and seeds.")
    if selected.empty or set(map(tuple, selected[TASK_KEYS].to_numpy())) != set(map(tuple, choices[TASK_KEYS].to_numpy())):
        raise ValueError("A frozen alpha choice has no corresponding held-out predictions.")
    for label, frame in [("selected", selected), ("fixed", fixed)]:
        frame[f"scaled_error2_{label}"] = ((frame.y_pred - frame.y_true) / frame.train_std) ** 2
    paired = selected[paired_keys + ["scaled_error2_selected"]].merge(
        fixed[paired_keys + ["scaled_error2_fixed"]], on=paired_keys, validate="one_to_one")
    result = paired.groupby(TASK_KEYS + ["target_date"])[["scaled_error2_selected", "scaled_error2_fixed"]].mean().reset_index()
    result["year"] = pd.to_datetime(result.target_date).dt.year
    return result


def _macro_score(errors: pd.DataFrame, keys: list[str]) -> tuple[float, float]:
    grouped = errors.groupby(keys)[["scaled_error2_selected", "scaled_error2_fixed"]].mean()
    return float(np.sqrt(grouped.scaled_error2_selected).mean()), float(np.sqrt(grouped.scaled_error2_fixed).mean())


def bootstrap_selector_comparison(paired: pd.DataFrame, samples: int = 500, seed: int = 1729) -> dict:
    """Paired basin and calendar-year block bootstrap of macro outlet NRMSE.

    Basin groups are sampled with replacement. Within each sampled group whole
    target years are sampled with replacement, retaining paired candidate errors.
    It accounts for grouped dates but does not establish causal effects.
    """
    if samples < 1:
        raise ValueError("bootstrap_samples must be at least one.")
    basins = sorted(paired.basin_id.unique())
    if len(basins) < 2:
        raise ValueError("Basin bootstrap requires at least two held-out basin groups.")
    for basin, group in paired.groupby("basin_id"):
        if group.year.nunique() < 2:
            raise ValueError(f"Basin {basin} requires at least two target-year blocks for temporal uncertainty.")
    observed_selected, observed_fixed = _macro_score(paired, TASK_KEYS)
    # Pre-aggregate sufficient statistics by year to make long-record bootstrap cheap.
    cols = ["scaled_error2_selected", "scaled_error2_fixed"]
    annual = paired.groupby(TASK_KEYS + ["year"])[cols].agg(["sum", "count"])
    annual.columns = [f"{c}_{s}" for c, s in annual.columns]
    annual = annual.reset_index()
    by_basin = {b: annual[annual.basin_id == b] for b in basins}
    rng = np.random.default_rng(seed)
    draws = []
    for _ in range(samples):
        blocks = []
        for copy_id, basin in enumerate(rng.choice(basins, size=len(basins), replace=True)):
            group = by_basin[basin]
            years = sorted(group.year.unique())
            for year in rng.choice(years, size=len(years), replace=True):
                piece = group[group.year == year].copy()
                piece["bootstrap_basin_copy"] = copy_id
                blocks.append(piece)
        stacked = pd.concat(blocks, ignore_index=True)
        keys = ["bootstrap_basin_copy"] + TASK_KEYS
        totals = stacked.groupby(keys)[[f"{c}_{s}" for c in cols for s in ["sum", "count"]]].sum()
        selected = np.sqrt(totals[f"{cols[0]}_sum"] / totals[f"{cols[0]}_count"]).mean()
        fixed = np.sqrt(totals[f"{cols[1]}_sum"] / totals[f"{cols[1]}_count"]).mean()
        draws.append(float(selected - fixed))
    low, high = np.quantile(draws, [0.025, 0.975])
    return {
        "selected_macro_nrmse": observed_selected, "fixed_macro_nrmse": observed_fixed,
        "delta_selected_minus_fixed": observed_selected - observed_fixed,
        "delta_95pct_interval": [float(low), float(high)], "bootstrap_samples": samples,
        "heldout_basins": len(basins), "negative_delta_favors_selector": True,
        "method": "paired basin resampling with within-basin whole target-year blocks; mean squared error across seeds",
        "limitation": "Intervals from fewer than five held-out groups are unstable." if len(basins) < 5 else "",
    }


def _plot_results(metrics: pd.DataFrame, outdir: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    curves = alpha_curve_table(metrics)
    plot_dir = outdir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    for (partition, split, regime), group in curves.groupby(["spatial_split", "split", "input_regime"]):
        horizons = sorted(group.horizon.unique())
        fig, axes = plt.subplots(1, len(horizons), figsize=(5 * len(horizons), 4), squeeze=False)
        for axis, horizon in zip(axes[0], horizons):
            for graph, g in group[group.horizon == horizon].groupby("graph_id"):
                g = g.sort_values("alpha")
                axis.errorbar(g.alpha, g.mean_nrmse, yerr=g.seed_sd.fillna(0), marker="o", alpha=.65,
                              linewidth=1, capsize=2, label=str(graph))
            axis.set(xlabel="Global attention coefficient α", ylabel="NRMSE", title=f"{horizon}-day forecast")
            axis.set_xticks(sorted(group.alpha.unique()))
            axis.grid(alpha=.2)
        if group.graph_id.nunique() <= 16:
            axes[0, -1].legend(title="Outlet", fontsize=7, loc="best")
        fig.suptitle(f"{partition} / {split} / {regime}; bars: SD across seeds")
        fig.tight_layout()
        fig.savefig(plot_dir / f"alpha_curves_{partition}_{split}_{regime}.png", dpi=160)
        plt.close(fig)
    # Per-run scores first average outlets; SD here again describes seed variability.
    keys = ["spatial_split", "split", "input_regime", "model", "alpha", "context_radius", "horizon", "seed"]
    macro = metrics.groupby(keys, dropna=False).nrmse.mean().reset_index()
    macro.to_csv(outdir / "macro_scores_by_seed.csv", index=False)
    ablation = metrics.groupby(["graph_id", "spatial_split", "split", "input_regime", "model", "alpha",
                                "context_radius", "horizon"], dropna=False).nrmse.agg(["mean", "std", "count"]).reset_index()
    ablation.to_csv(outdir / "context_and_baseline_scores.csv", index=False)
    test = macro[(macro.split == "test") & macro.context_radius.isin([-1, 0, 2])]
    for (partition, regime, horizon), data in test.groupby(["spatial_split", "input_regime", "horizon"]):
        summary = data.groupby(["model", "alpha", "context_radius"], dropna=False).nrmse.mean().reset_index()
        if summary.empty:
            continue
        labels = [f"{r.model} α={r.alpha:g} r={r.context_radius}" if pd.notna(r.alpha)
                  else f"{r.model} r={r.context_radius}" for r in summary.itertuples()]
        fig, axis = plt.subplots(figsize=(max(7, len(labels) * .65), 4))
        axis.bar(range(len(summary)), summary.nrmse)
        axis.set_xticks(range(len(labels)), labels, rotation=45, ha="right")
        axis.set(ylabel="Mean outlet NRMSE", title=f"{partition} / {regime} / {horizon}-day: test baselines and context")
        fig.tight_layout()
        fig.savefig(plot_dir / f"baselines_context_{partition}_{regime}_{horizon}day.png", dpi=160)
        plt.close(fig)


def _plot_costs(runtime_path: Path, outdir: Path) -> None:
    if not runtime_path.exists():
        return
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    runtimes = pd.read_csv(runtime_path)
    required = ["run_id", "model", "alpha", "input_regime", "seed", "context_radius", "train_seconds",
                "epochs", "parameters", "active_parameters"]
    _require(runtimes, required, "Runtime log")
    runtimes.to_csv(outdir / "costs.csv", index=False)
    hybrid = runtimes[(runtimes.model == "hybrid") & (runtimes.context_radius == -1)]
    if hybrid.empty:
        return
    fig, axes = plt.subplots(1, 2, figsize=(9, 4))
    for regime, group in hybrid.groupby("input_regime"):
        means = group.groupby("alpha")[["train_seconds", "active_parameters"]].mean().reset_index()
        axes[0].plot(means.alpha, means.train_seconds / 60, marker="o", label=regime)
        axes[1].plot(means.alpha, means.active_parameters, marker="o", label=regime)
    axes[0].set(xlabel="α", ylabel="Training minutes", title="Observed training cost")
    axes[1].set(xlabel="α", ylabel="Active parameters", title="Active model size")
    axes[0].legend()
    fig.tight_layout()
    fig.savefig(outdir / "plots" / "costs.png", dpi=160)
    plt.close(fig)


def _record_prediction_manifest(p: pd.DataFrame, manifest: dict) -> None:
    """Retain small signatures/date arrays, not predictions, across CSV files.

    Each (run, outlet, temporal split, horizon) must reside in one CSV. Common
    date and target hashes enforce paired comparisons across separately read
    runs. Numeric training statistics and run metadata must agree globally.
    """
    for run, group in p.groupby("run_id", sort=False):
        first = group.iloc[0]
        metadata = tuple(None if pd.isna(first[c]) else first[c]
                         for c in ["model", "alpha", "input_regime", "seed", "context_radius"])
        previous = manifest["runs"].setdefault(run, metadata)
        if previous != metadata:
            raise ValueError(f"Run {run} has conflicting metadata across CSV files.")
    for graph, group in p.groupby("graph_id", sort=False):
        first = group.iloc[0]
        stats = tuple(first[c] for c in ["basin_id", "spatial_split", "train_mean", "train_std", "train_q90"])
        previous = manifest["graphs"].setdefault(graph, stats)
        if previous != stats:
            raise ValueError(f"Graph {graph} has inconsistent partition/training statistics across files.")
    keys = ["graph_id", "spatial_split", "split", "input_regime", "horizon"]
    for task, group in p.groupby(keys, sort=False):
        # Within-file validation already checked agreement across its runs.
        one_run = group[group.run_id == group.run_id.iloc[0]].sort_values("target_date")
        dates = one_run.target_date.to_numpy(dtype="datetime64[ns]").astype(np.int64)
        labels = one_run.y_true.to_numpy(dtype=np.float64)
        digest = hashlib.sha256(dates.tobytes() + labels.tobytes()).hexdigest()
        if task in manifest["tasks"]:
            if manifest["tasks"][task]["digest"] != digest:
                raise ValueError(f"Forecast dates or true targets disagree across runs for task {task}.")
        else:
            manifest["tasks"][task] = {"digest": digest, "dates": dates}
    for key in p[["run_id", "graph_id", "split", "horizon"]].drop_duplicates().itertuples(index=False, name=None):
        if key in manifest["run_tasks"]:
            raise ValueError("Duplicate run/task across prediction files. Supply each run/task once; merge disjoint shards first.")
        manifest["run_tasks"].add(key)


def _stream_paired_errors(paths: list[Path], choices: pd.DataFrame, metrics: pd.DataFrame,
                          manifest: dict, chunksize: int = 150_000) -> pd.DataFrame:
    """Second pass: retain only paired daily sums/counts of seeded squared errors.

    The accumulator is proportional to held-out dates/tasks, not number of
    seeds, candidate alphas or CSV rows. Raw predictions never accumulate.
    """
    m = metrics[(metrics.model == "hybrid") & (metrics.context_radius == -1)
                & (metrics.spatial_split == "heldout") & (metrics.split == "test")]
    if m.duplicated(TASK_KEYS + ["alpha", "seed"]).any():
        raise ValueError("Multiple hybrid runs have the same held-out task/alpha/seed.")
    accumulators = {}
    decisions = choices[TASK_KEYS + ["selected_alpha", "fixed_alpha"]]
    for row in decisions.itertuples(index=False):
        task = tuple(getattr(row, c) for c in TASK_KEYS)
        subset = m[(m.graph_id == row.graph_id) & (m.basin_id == row.basin_id)
                   & (m.input_regime == row.input_regime) & (m.horizon == row.horizon)]
        selected_seeds = set(subset[np.isclose(subset.alpha, row.selected_alpha)].seed)
        fixed_seeds = set(subset[np.isclose(subset.alpha, row.fixed_alpha)].seed)
        if not selected_seeds or selected_seeds != fixed_seeds:
            raise ValueError(f"Selected and fixed alpha candidates need matching nonempty seeds for {task}.")
        manifest_key = (row.graph_id, "heldout", "test", row.input_regime, row.horizon)
        dates = manifest["tasks"][manifest_key]["dates"]
        accumulators[task] = {"dates": dates, "selected_sum": np.zeros(len(dates)),
                              "fixed_sum": np.zeros(len(dates)),
                              "selected_n": np.zeros(len(dates), dtype=np.int16),
                              "fixed_n": np.zeros(len(dates), dtype=np.int16)}
    columns = TASK_KEYS + ["spatial_split", "split", "model", "alpha", "context_radius",
                           "target_date", "y_true", "y_pred", "train_std"]
    dtypes = {"graph_id": str, "basin_id": str, "horizon": "int16", "context_radius": "int16"}
    # Conversion to categoricals happens only after filtering/merging; groupby
    # observed=True avoids generating the Cartesian product of category levels.
    categorical = ["graph_id", "basin_id", "input_regime"]
    for path in paths:
        for chunk in pd.read_csv(path, usecols=columns, dtype=dtypes, chunksize=chunksize):
            keep = (chunk.model == "hybrid") & (chunk.context_radius == -1) & (chunk.spatial_split == "heldout") & (chunk.split == "test")
            chunk = chunk.loc[keep]
            if chunk.empty:
                continue
            chunk = chunk.merge(decisions, on=TASK_KEYS, how="inner", validate="many_to_one")
            relevant = np.isclose(chunk.alpha, chunk.selected_alpha) | np.isclose(chunk.alpha, chunk.fixed_alpha)
            chunk = chunk.loc[relevant].copy()
            if chunk.empty:
                continue
            chunk["target_date"] = pd.to_datetime(chunk.target_date).dt.normalize()
            chunk["scaled_error2"] = ((chunk.y_pred - chunk.y_true) / chunk.train_std) ** 2
            for column in categorical:
                chunk[column] = chunk[column].astype("category")
            for task, group in chunk.groupby(TASK_KEYS, sort=False, observed=True):
                acc = accumulators[task]
                for side in ["selected", "fixed"]:
                    values = group[np.isclose(group.alpha, group[f"{side}_alpha"])]
                    if values.empty:
                        continue
                    dates = values.target_date.to_numpy(dtype="datetime64[ns]").astype(np.int64)
                    positions = np.searchsorted(acc["dates"], dates)
                    if (positions >= len(acc["dates"])).any() or not np.array_equal(acc["dates"][positions], dates):
                        raise ValueError("Prediction dates changed between the analysis passes.")
                    np.add.at(acc[f"{side}_sum"], positions, values.scaled_error2.to_numpy())
                    np.add.at(acc[f"{side}_n"], positions, 1)
    rows = []
    for task, acc in accumulators.items():
        if not np.array_equal(acc["selected_n"], acc["fixed_n"]) or (acc["selected_n"] == 0).any():
            raise ValueError(f"Paired forecast counts disagree for {task}.")
        frame = pd.DataFrame({"target_date": pd.to_datetime(acc["dates"]),
                              "scaled_error2_selected": acc["selected_sum"] / acc["selected_n"],
                              "scaled_error2_fixed": acc["fixed_sum"] / acc["fixed_n"]})
        for name, value in zip(TASK_KEYS, task):
            frame[name] = value
        frame["year"] = frame.target_date.dt.year.astype("int16")
        rows.append(frame)
    if not rows:
        raise ValueError("No paired held-out forecasts available.")
    return pd.concat(rows, ignore_index=True)


def analyze(prediction_paths: list[str | Path], graph_csv: str | Path, outdir: str | Path,
            bootstrap_samples: int = 500) -> dict:
    """Two-pass evaluation with memory bounded by one prediction CSV.

    Pass one converts each run CSV to a small metric table and cross-run
    signatures. Pass two streams only selected/fixed held-out forecasts into
    daily squared-error sums. No all-runs prediction concatenation occurs.
    Insufficient selector support is recorded while descriptive metrics remain
    available. Each run/task must be contained in a single prediction CSV.
    """
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    paths = [Path(p) for p in prediction_paths]
    if not paths:
        raise ValueError("No prediction CSVs supplied. Run training/evaluation first.")
    if len({p.resolve() for p in paths}) != len(paths):
        raise ValueError("Duplicate prediction file supplied.")
    graphs = pd.read_csv(graph_csv, dtype={"graph_id": str, "basin_id": str})
    metric_tables, heldout_paths = [], []
    manifest = {"runs": {}, "graphs": {}, "tasks": {}, "run_tasks": set()}
    prediction_rows = 0
    for path in paths:
        frame = pd.read_csv(path, dtype={"graph_id": str, "basin_id": str, "run_id": str},
                            usecols=PREDICTION_COLUMNS)
        frame = validate_predictions(frame)
        _record_prediction_manifest(frame, manifest)
        table = compute_metrics(frame, _validated=True)
        metric_tables.append(table)
        eligible = (table.model == "hybrid") & (table.context_radius == -1) & (table.spatial_split == "heldout") & (table.split == "test")
        if eligible.any():
            heldout_paths.append(path)
        prediction_rows += len(frame)
        del frame
    metrics = pd.concat(metric_tables, ignore_index=True)
    # Metadata and prediction CSVs must describe exactly the same graph/group
    # assignment; otherwise a mislabeled partition could bypass held-out checks.
    metadata = graphs.set_index("graph_id")
    for graph, stats in manifest["graphs"].items():
        if graph not in metadata.index:
            raise ValueError(f"Graph {graph} is missing from graphs.csv.")
        row = metadata.loc[graph]
        if row.basin_id != stats[0] or row.spatial_split != stats[1]:
            raise ValueError(f"Graph {graph} has inconsistent basin/spatial partition metadata.")
    metrics.to_csv(outdir / "metrics.csv", index=False)
    alpha_curve_table(metrics).to_csv(outdir / "alpha_curves.csv", index=False)
    near_optimal_alpha_table(metrics).to_csv(outdir / "near_optimal_alpha.csv", index=False)
    _plot_results(metrics, outdir)
    status: dict = {"metrics_rows": len(metrics), "prediction_rows": prediction_rows,
                   "analysis_mode": "two_pass_per_file_metrics_and_streamed_paired_errors"}
    try:
        selector = fit_selector(metrics, graphs)
        serializable = {k: v for k, v in selector.items() if k not in {"model", "fixed_choices"}}
        (outdir / "selector.json").write_text(json.dumps(serializable, indent=2))
        selector["fixed_choices"].to_csv(outdir / "fixed_alpha_choices.csv", index=False)
        # This function needs only task/partition metadata, not raw labels.
        choices = choose_heldout_alphas(selector, metrics, graphs)
        choices.to_csv(outdir / "selector_choices.csv", index=False)
        paired = _stream_paired_errors(heldout_paths, choices, metrics, manifest)
        group_scores = paired.groupby(TASK_KEYS)[["scaled_error2_selected", "scaled_error2_fixed"]].mean().pow(.5)
        group_scores.columns = ["selected_nrmse", "fixed_nrmse"]
        group_scores["delta_selected_minus_fixed"] = group_scores.selected_nrmse - group_scores.fixed_nrmse
        group_scores.reset_index().to_csv(outdir / "selector_comparison.csv", index=False)
        status["selector"] = "evaluated"
        try:
            result = bootstrap_selector_comparison(paired, samples=bootstrap_samples)
            (outdir / "selector_bootstrap.json").write_text(json.dumps(result, indent=2))
            status["bootstrap"] = "evaluated"
        except ValueError as exc:
            status["bootstrap"] = "insufficient_support"
            status["bootstrap_reason"] = str(exc)
    except ValueError as exc:
        status["selector"] = "unavailable"
        status["selector_reason"] = str(exc)
    runtime_paths = []
    for path in paths:
        for candidate in [path.parent / "runtimes.csv", path.parent.parent / "runtimes.csv"]:
            if candidate.exists() and candidate not in runtime_paths:
                runtime_paths.append(candidate)
    if runtime_paths:
        costs = pd.concat([pd.read_csv(p) for p in runtime_paths], ignore_index=True).drop_duplicates()
        if costs.run_id.duplicated().any():
            raise ValueError("Conflicting runtime log rows for the same run_id.")
        costs.to_csv(outdir / "runtimes.csv", index=False)
        _plot_costs(outdir / "runtimes.csv", outdir)
    (outdir / "selector_status.json").write_text(json.dumps(status, indent=2))
    (outdir / "interpretation.txt").write_text(
        "NRMSE uses frozen development-training scaling; outputs are equally weighted per outlet/task.\n"
        "Alpha-curve bars describe seed variability, not independent-basin uncertainty.\n"
        "Near-optimal alpha uses a declared 2% validation tolerance, not an equivalence test.\n"
        "The selector fits development validation only; held-out test labels evaluate frozen decisions.\n"
        "The fixed comparator selects one alpha per input regime and horizon on development validation.\n"
        "Real-data structure associations do not establish oversquashing or a causal alpha mechanism.\n"
        "Alpha is a branch coefficient, not an attention contribution or compute percentage.\n"
        "Analysis reads one CSV at a time, then streams paired errors; do not concatenate all run CSVs.\n"
    )
    return status
