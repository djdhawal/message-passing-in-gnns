"""Pure-PyTorch directed river forecasting models (no PyG/scatter dependency).

Batches contain several time windows on the same unpadded river graph.  Edges
point upstream -> downstream.  ``ancestor_dist[v, u]`` is the hop distance from
upstream node u to receiver v, zero on the diagonal, and -1 if u cannot reach v.
All graph tensors must be on the same device as the dynamic inputs.

The hybrid's alpha is a fixed branch coefficient, not an estimate of the fraction
of information or compute attributable to attention.  An inactive endpoint branch
is not executed, although its parameters are retained to keep initialization of
the active modules identical when seeds match.  ``parameter_counts`` distinguishes
registered parameters from those active in a forward pass.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import torch
from torch import Tensor, nn


@dataclass(frozen=True)
class ModelConfig:
    dynamic_dim: int = 0
    static_dim: int = 0
    edge_dim: int = 2
    hidden_dim: int = 64
    layers: int = 8
    heads: int = 4
    horizons: tuple[int, ...] = (1, 3, 7)
    alpha: float = 0.5
    dropout: float = 0.1
    max_distance: int = 64
    kind: str = "hybrid"

    def validate(self) -> None:
        if self.kind not in {"hybrid", "local", "pooled"}:
            raise ValueError("kind must be hybrid, local, or pooled")
        if self.dynamic_dim < 1 or self.static_dim < 0 or self.edge_dim < 0:
            raise ValueError("Invalid input feature dimensions")
        if self.hidden_dim < 1 or self.layers < 1 or self.heads < 1:
            raise ValueError("hidden_dim, layers and heads must be positive")
        if self.hidden_dim % self.heads:
            raise ValueError("hidden_dim must be divisible by heads")
        if not self.horizons or min(self.horizons) < 1 or self.max_distance < 0:
            raise ValueError("Invalid output count or maximum distance")
        if not 0 <= self.alpha <= 1 or not 0 <= self.dropout < 1:
            raise ValueError("alpha must be in [0,1], dropout in [0,1)")


class NodeTemporalEncoder(nn.Module):
    """One shared GRU encodes each node independently before spatial mixing."""

    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.dynamic_dim = cfg.dynamic_dim
        self.static_dim = cfg.static_dim
        self.gru = nn.GRU(cfg.dynamic_dim, cfg.hidden_dim, batch_first=True)
        self.combine = nn.Sequential(
            nn.Linear(cfg.hidden_dim + cfg.static_dim, cfg.hidden_dim),
            nn.GELU(),
            nn.LayerNorm(cfg.hidden_dim),
            nn.Dropout(cfg.dropout),
        )

    def forward(self, dynamic: Tensor, static: Tensor) -> Tensor:
        if dynamic.ndim != 4:
            raise ValueError("dynamic must have shape [batch,nodes,time,features]")
        batch, nodes, steps, features = dynamic.shape
        if steps < 1 or features != self.dynamic_dim:
            raise ValueError("Invalid temporal length or dynamic feature count")
        if static.ndim == 2:
            static = static.unsqueeze(0).expand(batch, -1, -1)
        if static.shape != (batch, nodes, self.static_dim):
            raise ValueError("static must be [nodes,features] or [batch,nodes,features]")
        _, last = self.gru(dynamic.reshape(batch * nodes, steps, features))
        encoded = last[-1].reshape(batch, nodes, -1)
        return self.combine(torch.cat((encoded, static), dim=-1))


class DirectedMessagePassing(nn.Module):
    """Mean aggregation from direct upstream neighbors, with edge attributes."""

    def __init__(self, hidden: int, edge_dim: int):
        super().__init__()
        self.edge_dim = edge_dim
        self.message = nn.Sequential(
            nn.Linear(2 * hidden + edge_dim, hidden), nn.GELU(), nn.Linear(hidden, hidden)
        )
        self.update = nn.Sequential(
            nn.Linear(2 * hidden, hidden), nn.GELU(), nn.Linear(hidden, hidden)
        )

    def forward(self, h: Tensor, edge_index: Tensor, edge_attr: Tensor | None) -> Tensor:
        batch, nodes, hidden = h.shape
        if edge_index.ndim != 2 or edge_index.shape[0] != 2:
            raise ValueError("edge_index must have shape [2,edges]")
        source, receiver = edge_index.long()
        edges = source.numel()
        if edge_attr is None:
            if self.edge_dim:
                raise ValueError("edge_attr is required when edge_dim > 0")
            edge_attr = h.new_empty((edges, 0))
        if edge_attr.shape != (edges, self.edge_dim):
            raise ValueError("edge_attr must have shape [edges,edge_dim]")
        aggregate = torch.zeros_like(h)
        if edges:
            attrs = edge_attr.unsqueeze(0).expand(batch, -1, -1)
            messages = self.message(torch.cat((h[:, source], h[:, receiver], attrs), dim=-1))
            aggregate.index_add_(1, receiver, messages)
            count = torch.bincount(receiver, minlength=nodes).to(h.dtype).clamp_min(1)
            aggregate = aggregate / count.view(1, nodes, 1)
        return self.update(torch.cat((h, aggregate), dim=-1))


class UpstreamAttention(nn.Module):
    """Global attention to ancestors and self, with per-head hop-distance bias."""

    def __init__(self, hidden: int, heads: int, max_distance: int, dropout: float, pair_dim: int = 2):
        super().__init__()
        self.heads = heads
        self.head_dim = hidden // heads
        self.max_distance = max_distance
        self.qkv = nn.Linear(hidden, 3 * hidden)
        self.output = nn.Linear(hidden, hidden)
        self.distance_bias = nn.Embedding(max_distance + 1, heads)
        self.pair_bias = nn.Linear(pair_dim, heads, bias=False) if pair_dim else None
        self.attention_dropout = nn.Dropout(dropout)
        nn.init.zeros_(self.distance_bias.weight)

    def forward(self, h: Tensor, ancestor_dist: Tensor, pair_attr: Tensor | None = None) -> Tensor:
        batch, nodes, hidden = h.shape
        if ancestor_dist.shape != (nodes, nodes):
            raise ValueError("ancestor_dist must have shape [nodes,nodes]")
        if bool((ancestor_dist.diagonal() != 0).any()):
            raise ValueError("ancestor_dist diagonal must be zero (self attention)")
        if bool((ancestor_dist > self.max_distance).any()):
            raise ValueError("Graph distance exceeds model max_distance")
        qkv = self.qkv(h).view(batch, nodes, 3, self.heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(dim=0)
        logits = (q @ k.transpose(-2, -1)) / self.head_dim**0.5
        bias = self.distance_bias(ancestor_dist.clamp_min(0).long()).permute(2, 0, 1)
        if pair_attr is not None:
            if self.pair_bias is None or pair_attr.shape != (nodes, nodes, self.pair_bias.in_features):
                raise ValueError("pair_attr must have shape [nodes,nodes,edge_dim]")
            bias = bias + self.pair_bias(pair_attr).permute(2, 0, 1)
        logits = logits + bias.unsqueeze(0)
        logits = logits.masked_fill((ancestor_dist < 0).view(1, 1, nodes, nodes), -torch.inf)
        weights = self.attention_dropout(torch.softmax(logits, dim=-1))
        mixed = (weights @ v).transpose(1, 2).contiguous().view(batch, nodes, hidden)
        return self.output(mixed)


class HybridLayer(nn.Module):
    """Parallel comparable branch outputs followed by a shared residual FFN."""

    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.alpha = float(cfg.alpha)
        self.local = DirectedMessagePassing(cfg.hidden_dim, cfg.edge_dim)
        self.global_attention = UpstreamAttention(
            cfg.hidden_dim, cfg.heads, cfg.max_distance, cfg.dropout, cfg.edge_dim
        )
        # Affine-free branch norms prevent an immediate learned scalar rescaling.
        self.local_norm = nn.LayerNorm(cfg.hidden_dim, elementwise_affine=False)
        self.global_norm = nn.LayerNorm(cfg.hidden_dim, elementwise_affine=False)
        self.dropout = nn.Dropout(cfg.dropout)
        self.ff_norm = nn.LayerNorm(cfg.hidden_dim)
        self.ff = nn.Sequential(
            nn.Linear(cfg.hidden_dim, 2 * cfg.hidden_dim), nn.GELU(),
            nn.Dropout(cfg.dropout), nn.Linear(2 * cfg.hidden_dim, cfg.hidden_dim),
        )

    def forward(
        self, h: Tensor, edge_index: Tensor, edge_attr: Tensor | None, ancestor_dist: Tensor,
        pair_attr: Tensor | None = None,
    ) -> Tensor:
        if self.alpha == 0:
            update = self.local_norm(self.local(h, edge_index, edge_attr))
        elif self.alpha == 1:
            update = self.global_norm(self.global_attention(h, ancestor_dist, pair_attr))
        else:
            local = self.local_norm(self.local(h, edge_index, edge_attr))
            global_update = self.global_norm(self.global_attention(h, ancestor_dist, pair_attr))
            update = (1 - self.alpha) * local + self.alpha * global_update
        h = h + self.dropout(update)
        return h + self.dropout(self.ff(self.ff_norm(h)))


class RiverForecaster(nn.Module):
    """Hybrid, outlet-only GRU, or topology-free upstream mean-pooling control.

    ``context_mask`` optionally zeros dynamic node histories before encoding; it
    does not remove nodes or edges, and static attributes remain available.  Prefer
    masked normalized values plus an explicit availability channel in ``dynamic``
    when constructing input ablations.  Dataset preprocessing owns that policy.

    The outlet-only control ignores every node except the selected outlet.  The
    pool control combines an outlet encoding with the mean of all node encodings;
    graph inputs are ignored.  It assumes the supplied graph is a complete outlet
    catchment, so every included node belongs to the upstream basin.
    """

    def __init__(self, cfg: ModelConfig):
        super().__init__()
        cfg.validate()
        self.config = cfg
        self.kind = cfg.kind
        self.encoder = NodeTemporalEncoder(cfg)
        self.layers = nn.ModuleList(
            [HybridLayer(cfg) for _ in range(cfg.layers)] if cfg.kind == "hybrid" else []
        )
        head_dim = cfg.hidden_dim * (2 if cfg.kind == "pooled" else 1)
        self.head = nn.Sequential(
            nn.LayerNorm(head_dim), nn.Linear(head_dim, cfg.hidden_dim),
            nn.GELU(), nn.Dropout(cfg.dropout), nn.Linear(cfg.hidden_dim, len(cfg.horizons)),
        )

    def forward(
        self,
        dynamic: Tensor,
        static: Tensor,
        edge_index: Tensor | None = None,
        edge_attr: Tensor | None = None,
        ancestor_dist: Tensor | None = None,
        outlet_index: int = 0,
        pair_attr: Tensor | None = None,
        context_mask: Tensor | None = None,
    ) -> Tensor:
        if dynamic.ndim != 4:
            raise ValueError("dynamic must have shape [batch,nodes,time,features]")
        if not 0 <= outlet_index < dynamic.shape[1]:
            raise ValueError("outlet_index is outside the graph")
        if context_mask is not None:
            if context_mask.ndim == 1:
                context_mask = context_mask.unsqueeze(0)
            if context_mask.shape not in {(1, dynamic.shape[1]), dynamic.shape[:2]}:
                raise ValueError("context_mask must be [nodes] or [batch,nodes]")
            dynamic = dynamic * context_mask.to(dynamic.dtype)[..., None, None]
        if self.kind == "local":
            selected_static = static[outlet_index:outlet_index + 1] if static.ndim == 2 else static[:, outlet_index:outlet_index + 1]
            h = self.encoder(dynamic[:, outlet_index:outlet_index + 1], selected_static)
            return self.head(h[:, 0])
        h = self.encoder(dynamic, static)
        if self.kind == "pooled":
            return self.head(torch.cat((h[:, outlet_index], h.mean(dim=1)), dim=-1))
        if edge_index is None or ancestor_dist is None:
            raise ValueError("Hybrid model requires edge_index and ancestor_dist")
        for layer in self.layers:
            h = layer(h, edge_index, edge_attr, ancestor_dist, pair_attr)
        return self.head(h[:, outlet_index])

    def parameter_counts(self) -> dict[str, int]:
        """Count parameters retained in checkpoints and those used by this alpha."""
        total = sum(p.numel() for p in self.parameters())
        inactive = 0
        if self.kind == "hybrid":
            for layer in self.layers:
                if self.config.alpha == 0:
                    inactive += sum(p.numel() for p in layer.global_attention.parameters())
                elif self.config.alpha == 1:
                    inactive += sum(p.numel() for p in layer.local.parameters())
        return {"total": total, "active": total - inactive, "inactive": inactive}


def build_model(
    config: ModelConfig | dict[str, Any],
    dynamic_dim: int | None = None,
    static_dim: int | None = None,
    edge_dim: int | None = None,
    **overrides: Any,
) -> RiverForecaster:
    """Build a model from a dataclass or a JSON-serializable configuration."""
    values = asdict(config) if isinstance(config, ModelConfig) else dict(config)
    for key, value in (("dynamic_dim", dynamic_dim), ("static_dim", static_dim), ("edge_dim", edge_dim)):
        if value is not None:
            values[key] = value
    values.update(overrides)
    return RiverForecaster(ModelConfig(**values))
