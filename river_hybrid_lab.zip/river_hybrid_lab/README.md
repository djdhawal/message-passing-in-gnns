# River Hybrid Lab

An end-to-end experiment for testing when river forecasting benefits from local message passing, upstream global attention, or a mixture of both. It downloads LamaH-CE, prepares gauge trees, trains the models and baselines, retrains upstream-input ablations, and writes metrics, figures, and a validation-trained selector of the attention coefficient.

**Start with `START_HERE.ipynb` in Colab, or follow the terminal instructions below.** The package uses PyTorch directly; it does not require PyTorch Geometric. The included synthetic demo verifies the workflow. Its scores are not results on LamaH-CE.

## 1. Install and check your environment

Extract `river_hybrid_lab.zip`, enter the extracted folder containing `pyproject.toml`, and use Python 3.10 or newer:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .
python -m river_hybrid doctor
```

On Windows, activate the environment with `.venv\Scripts\activate` instead. For GPU training, install the PyTorch build appropriate to your machine using the [official installation selector](https://pytorch.org/get-started/locally/), then run `pip install -e .`. Colab normally already supplies PyTorch. The default `training.device="auto"` uses CUDA when available and otherwise uses the CPU.

The dependency bounds are in `pyproject.toml`; this is not a fully locked environment. Save the resolved versions with `python -m pip freeze > environment.txt` when running a research experiment.

Ready-made configurations are included in `configs/`: `default.json` is the full protocol, `smoke.json` is for the artificial fixture, and `real_smoke.json` is a one-epoch capped real-data plumbing check. The capped configuration is not a research result.

Run the small, synthetic file-format demo:

```bash
python -m river_hybrid demo --work demo_output
```

It creates an artificial LamaH-shaped dataset, runs a reduced training grid and baselines, chooses context ablations using validation results, and writes plots. It is useful for checking installation and code flow. It does not simulate realistic hydrology or demonstrate the research hypothesis.

## 2. Run the real-data experiment

The downloader fetches the original LamaH-CE v1.0 daily archive from the [official Zenodo record](https://zenodo.org/records/5153305), checks its published MD5, and safely extracts it. Budget approximately 1.5 GB for the archive and 5 GB for extracted data, plus prepared arrays, predictions, and checkpoints. The full experiment is substantially larger than the demo; time one training run before scheduling the full grid.

Create an editable configuration and preview the main run plan:

```bash
python -m river_hybrid init-config --output experiment.json
python -m river_hybrid sweep --config experiment.json --include-baselines --dry-run
```

The complete workflow is one command:

```bash
python -m river_hybrid run-all --config experiment.json --work river_experiment
```

This downloads if needed, audits the source, prepares data, executes 30 main hybrid fits plus 12 learned baseline fits and one persistence evaluation, retrains 24–36 context ablations, then analyzes the outputs. Those counts describe the default configuration. The ablation count depends on whether the validation-selected alpha is an endpoint or an interior value. Use `--skip-ablations` to complete the main comparison first.

If you already have extracted LamaH-CE data:

```bash
python -m river_hybrid run-all --raw /path/to/extracted/LamaH-CE --config experiment.json --work river_experiment
```

Do not point the reader to Extended LamaH-CE or LamaH-Ice: their schemas differ. The audit expects the original daily release and reports missing columns rather than guessing replacements.

## 3. Run each stage separately

This is the recommended route for your first real experiment. The audit and preparation outputs show which graphs are actually available before expensive training starts.

```bash
python -m river_hybrid download --destination data/raw
python -m river_hybrid audit --raw data/raw --output data/audit.json
python -m river_hybrid prepare --raw data/raw --processed data/processed --config experiment.json
```

Inspect `data/audit.json`, `data/processed/manifest.json`, and `data/processed/graphs.csv`. Check the number of graphs, distinct spatial groups, depth and branching range, missing data, impact flags, and development/held-out split. The default selects at most 32 complete upstream subtrees with 5–64 nodes and depth at most eight; availability can yield fewer. Candidate selection never truncates tributaries just to meet a size cap.

Time one fit before launching the sweep:

```bash
python -m river_hybrid train --processed data/processed --runs results/runs --config experiment.json --model hybrid --alpha 0.5 --input-regime weather_flow --seed 42
```

Then run the planned comparison, context ablations, and analysis:

```bash
python -m river_hybrid sweep --processed data/processed --runs results/runs --config experiment.json --include-baselines
python -m river_hybrid ablate --processed data/processed --runs results/runs --config experiment.json --dry-run
python -m river_hybrid ablate --processed data/processed --runs results/runs --config experiment.json
python -m river_hybrid analyze --processed data/processed --runs results/runs --config experiment.json --output results/analysis
```

The sweep reuses the completed first fit when its configuration and prepared data match. `ablate --dry-run` reads completed development-validation predictions and saves its choices before showing the proposed runs. `analyze` also works before ablations, and retains descriptive metrics when there is insufficient spatial support to fit a selector.

## 4. What the code tests

| Component | Default implementation |
|---|---|
| Data | Daily LamaH-CE, intermediate catchments B |
| Graph | Outlet gauge plus its complete upstream gauge tree; selected trees share no gauges |
| Weather inputs | Precipitation and mean 2 m temperature, previous 90 complete days |
| Additional input setting | Past observed discharge at every node, with availability masks |
| Static inputs | Intermediate catchment area, mean elevation, mean slope |
| Edge inputs | Between-gauge river length and stream slope |
| Targets | Outlet discharge 1, 3, and 7 days ahead, predicted jointly |
| Temporal encoder | Shared-design node GRU, hidden dimension 64 |
| Spatial model | Eight residual hybrid layers, four attention heads |
| Alpha grid | 0, 0.25, 0.5, 0.75, 1; one fixed coefficient for all layers in each fit |
| Training | AdamW, up to 50 epochs, validation early stopping with patience 8 |
| Windows | Training issue dates every seven days; validation/test issue dates daily |
| Seeds | 42, 43, 44 |

At each hybrid layer the code separately normalizes the local and attention updates using affine-free LayerNorm, mixes them as `(1-alpha)*local + alpha*attention`, and adds a residual update. Alpha 0 executes only the message-passing branch; alpha 1 executes only attention. Alpha is a model coefficient, not a measured percentage of causal contribution or compute. Interior mixtures have more active parameters than either endpoint; parameter counts and training costs are logged.

Local messages travel downstream along direct gauge connections. A node's global attention can see itself and its upstream ancestors; downstream nodes and unrelated branches are masked. Attention has hop-distance and river-path attribute biases. Thus "global" means global within the node's upstream ancestry, not unconstrained attention over the entire basin. Local edges use direct distance/slope features; attention uses cumulative path distance and distance-weighted path slope.

The learned baselines have the same temporal-encoder design:

- `--model local`: an outlet-only GRU with no spatial communication. This name does **not** mean the local MPNN; use `hybrid --alpha 0` for that endpoint.
- `--model pooled`: concatenate the outlet encoding with the mean of all node encodings; no river-edge message passing.
- `--model persistence`: forecast the latest valid discharge in the history window at every horizon; it is available only for `weather_flow`. If the entire history lacks discharge, use the area-scaled global development-training mean so candidate models are compared on the same target dates. The fallback count is logged.

Context ablations retrain alpha 0, alpha 1, and the best development-validation alpha in each input setting. They supply dynamic observations only at the outlet (`radius=0`) or within two upstream hops (`radius=2`). Full-context runs are reused. The topology and static attributes remain available, so this tests the value of distant **observations**, not graph removal. The chosen alpha and all ablation run specifications are saved before retraining.

## 5. Splits, quality control, and metric interpretation

Training targets are in 1981–1999, validation targets in 2000–2005, and temporal-test targets in 2006–2017. All three targets in a training window must stay in its designated time split. Histories may cross a split boundary because those past observations would be available at forecast time. Forecasts are issued after the complete issue day's weather/flow measurements have arrived; the experiment uses no observed future weather.

The spatial split unions parent river groups connected by documented cross-basin transfers, then holds out whole groups. It targets approximately 20% of selected graphs while keeping at least two held-out and three development groups when at least five groups exist; exact proportions depend on group sizes. No gauge appears in two selected graphs. This is a spatial group split, not proof that the physical systems are independent: regulation, undocumented transfers, and correlated weather remain possible confounders.

Quality control converts the source missing-value code `-999` to missing observations. The default `quality="checked"` requires `ckhs=1` and nonnegative finite discharge. It retains statistical `qceq`/`qcol` warning days because they can include true extremes; `quality="strict"` also excludes those warnings. Missing dynamic inputs are imputed to normalized zero with an explicit observation mask, never interpolated from the future. Missing static attributes are imputed to normalized zero; their stored masks are not model inputs. Missing targets are omitted. Review the resulting loss of coverage.

Weather, static, edge, and target scalers use development-training data only. Discharge is first converted to specific discharge using upstream drainage area. One global development-training mean and standard deviation then scale all targets; predictions are converted back to m³/s. NRMSE uses this frozen specific-discharge reference scaled to each outlet's area. It is **not** normalized by each outlet's own historical standard deviation.

The high-flow threshold is the global development-training 90th percentile of specific discharge, also area-scaled to each outlet. It is **not** a per-gauge top-decile threshold. The package reports NRMSE, RMSE, MAE, NSE, high-flow RMSE, and high-flow MAE. Inspect `high_flow_n` before interpreting extreme-event errors.

The default static inputs exclude supplied full-record climatic and hydrological signatures. Land-cover features are not in the default three-feature list; adding source land-cover attributes uses a retrospective CORINE-2012 snapshot and requires a separate sensitivity check.

## 6. Read the outputs

| Output | What to use it for |
|---|---|
| `processed/manifest.json`, `graphs.csv` | Exact graph selection, splits, preprocessing, quality notes, and source identity |
| `runs/sweep_plan.json`, `ablation_plan.json`, `ablation_choices.json` | Planned comparisons and validation-selected ablations |
| Each run's `config.json` | Full configuration and data fingerprint |
| Each run's `checkpoint.pt`, `last.pt`, `learningcurve.csv` | Selected model, resumable training state, and learning curves |
| Each run's `predictions.csv`, `runtime.json` | Per-date discharge predictions and recorded compute cost |
| `analysis/metrics.csv`, `macro_scores_by_seed.csv` | Per-outlet/task metrics and equal-outlet summaries |
| `analysis/alpha_curves.csv`, `plots/alpha_curves_*.png` | Error versus alpha, separately by graph, input setting, split, and horizon |
| `analysis/near_optimal_alpha.csv` | Alphas within a declared 2% validation tolerance; not an equivalence test |
| `analysis/context_and_baseline_scores.csv` | Context ablations and baseline comparison |
| `analysis/selector*.json`, `selector*.csv` | Structure-based choice, held-out comparison, and support status |
| `analysis/plots/costs.png` | Measured training time and active model size versus alpha |

The plotted training-time total sums epoch durations, including each epoch's validation pass. It excludes final prediction export and is distinct from total run wall time in the runtime log.

The selector predicts validation loss at each alpha using a shallow decision tree, with graph depth, branching, node count, river length, drainage area, input setting, and horizon as features. Its hyperparameters are chosen using grouped cross-validation on development river groups. The fixed comparator chooses one uniform alpha **per input setting and horizon** using development validation. Held-out test labels evaluate the frozen decisions and never select alpha.

The selector requires at least three development spatial groups. Paired uncertainty estimates also require adequate held-out groups and years. If support is insufficient, `selector_status.json` records the reason and descriptive metrics/plots still remain available. Do not present an unavailable selector result as evidence of successful generalization. The selector bootstrap resamples spatial groups and calendar-year blocks; alpha-curve bars only show seed variability.

## 7. Reproducibility and limits

Prepared datasets are immutable. Reuse the same directory only for the same data configuration. To change graph caps, dates, input attributes, or quality rules, create a new prepared-data directory and new run directory. Completed fits are reused only when configuration, manifest, and graph hashes match. Interrupted training resumes from the last saved state; changing the experiment configuration requires a new run directory. Do not edit graph files after starting the sweep.

This is a predefined controlled comparison, not a completed hyperparameter search. Before making an architectural superiority claim, run equal-budget validation tuning for all candidates, particularly both endpoints, using separate run directories. The package is inspired by local/global graph hybrids; it is not an exact GraphGPS reproduction.

Daily observations cannot establish subdaily travel times. Gauge-level trees simplify river hydraulics; reservoirs, snow processes, abstraction, ungauged tributaries, and transfers can affect predictions. Structural associations on real data do not prove oversquashing or attention dilution. Longer forecast horizons also need not imply greater spatial range. Use the observation-radius ablations and the weather-versus-flow comparison to test those assumptions.

The default 32-graph cap is for feasibility and may leave too few river groups or too narrow a structure range. Inspect the selection before increasing the budget. If preparation cannot form a valid spatial split, it stops with `preparation_failure.json`; revising the selection must precede training. Set `data.excluded_impact_classes` to `["s"]` in a new configuration to reject whole upstream trees containing a strongly impacted gauge; the default is `[]`. Drainage area is included in the selector, but that does not establish causal adjustment; climate and regulation can still confound structural associations.

Code checks and the exact locally executed validation are recorded in `TESTING.md` when supplied with this package. No real-data performance is claimed by the code bundle.

See [DATA_SOURCES.md](DATA_SOURCES.md) for source URLs, archive identity, attribution, and field mappings.
